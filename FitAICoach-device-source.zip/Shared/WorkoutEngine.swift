import Foundation

public enum WorkoutPhase: String, Codable, Sendable { case ready, exercise, rest, paused, finished }
/// Timestamp driven; UI timers only redraw. Persist this entire value after every mutation.
public struct WorkoutEngine: Codable, Sendable {
    public private(set) var plan: WorkoutPlan
    public private(set) var state: WorkoutPhase = .ready
    public private(set) var record: WorkoutRecord
    public private(set) var exerciseIndex = 0
    public private(set) var setNumber = 1
    private var phaseStartedAt: Date
    private var phasePausedSeconds: TimeInterval = 0
    private var totalPausedSeconds: TimeInterval = 0
    private var pausedAt: Date?
    private var pauseIntervals: [DateInterval] = []
    private var resumeState: WorkoutPhase = .ready
    private var restSeconds: Int = 30
    public var currentExercise: ExercisePlan? { plan.exercises.indices.contains(exerciseIndex) ? plan.exercises[exerciseIndex] : nil }
    public var nextExercise: ExercisePlan? {
        guard let current=currentExercise else { return nil }
        if setNumber < max(1,current.sets) { return current }
        return plan.exercises.indices.contains(exerciseIndex+1) ? plan.exercises[exerciseIndex+1] : nil
    }
    public init(plan: WorkoutPlan, now: Date = Date()) {
        self.plan=plan; self.phaseStartedAt=now
        self.record=WorkoutRecord(planName:plan.name,startedAt:now,isLight:plan.isLight)
        self.record.controlTestKind = plan.controlTestKind
        if plan.exercises.isEmpty { state = .finished; record.endedAt=now }
    }
    public func elapsed(at now:Date=Date()) -> TimeInterval {
        let end=record.endedAt ?? pausedAt ?? now
        return max(0,end.timeIntervalSince(record.startedAt)-totalPausedSeconds)
    }
    public func phaseElapsed(at now:Date=Date()) -> TimeInterval {
        max(0,(pausedAt ?? now).timeIntervalSince(phaseStartedAt)-phasePausedSeconds)
    }
    public func restRemaining(at now:Date=Date()) -> Int {
        guard state == .rest || (state == .paused && resumeState == .rest) else { return 0 }
        return max(0,Int(ceil(Double(restSeconds)-phaseElapsed(at:now))))
    }
    public mutating func startExercise(now:Date=Date()) {
        guard state == .ready, currentExercise != nil else { return }
        state = .exercise; phaseStartedAt=now; phasePausedSeconds=0
    }
    public mutating func finishExercise(actualRepetitions:Int?, skipped:Bool=false, now:Date=Date()) {
        guard state == .exercise, let item=currentExercise else { return }
        let duration=phaseElapsed(at:now)
        let samples=record.heartRate.filter { $0.date >= phaseStartedAt && $0.date < now }
        record.exercises.append(ExerciseRecord(exercise:item.exercise,setNumber:setNumber,startedAt:phaseStartedAt,endedAt:now,duration:duration,plannedRepetitions:item.repetitions,actualRepetitions:actualRepetitions.map { max(0,$0) },plannedDurationSeconds:item.durationSeconds,skipped:skipped,heartRate:samples))
        record.duration=elapsed(at:now)
        if nextExercise == nil { state = .ready; finish(now:now); return }
        state = .rest; phaseStartedAt=now; phasePausedSeconds=0; restSeconds=max(0,item.restSeconds)
        if restSeconds == 0 { startNext(now: now) }
    }
    public mutating func startNext(now:Date=Date()) {
        guard state == .rest, let item=currentExercise else { return }
        closeRest(now:now)
        if setNumber < max(1,item.sets) { setNumber += 1 } else { exerciseIndex += 1; setNumber=1 }
        state = currentExercise == nil ? .finished : .ready
        phaseStartedAt=now; phasePausedSeconds=0
        if state == .finished { finish(now:now) }
    }
    public mutating func extendRest(seconds:Int=30) {
        guard state == .rest || (state == .paused && resumeState == .rest) else { return }
        restSeconds += max(0,seconds)
    }
    public mutating func pause(now:Date=Date()) {
        guard state != .paused && state != .finished else { return }
        resumeState=state; state = .paused; pausedAt=now
    }
    public mutating func resume(now:Date=Date()) {
        guard state == .paused, let pausedAt else { return }
        let duration=max(0,now.timeIntervalSince(pausedAt))
        pauseIntervals.append(DateInterval(start:pausedAt,end:max(pausedAt,now)))
        totalPausedSeconds += duration; phasePausedSeconds += duration
        self.pausedAt=nil; state=resumeState
    }
    public mutating func finish(now:Date=Date()) {
        guard record.endedAt == nil else { return }
        if state == .paused { resume(now:now) }
        if state == .exercise, let item=currentExercise {
            record.exercises.append(ExerciseRecord(exercise:item.exercise,setNumber:setNumber,startedAt:phaseStartedAt,endedAt:now,duration:phaseElapsed(at:now),plannedRepetitions:item.repetitions,actualRepetitions:nil,plannedDurationSeconds:item.durationSeconds,skipped:true,heartRate:record.heartRate.filter { $0.date >= phaseStartedAt && $0.date < now }))
            record.interrupted=true
        } else if state == .rest { closeRest(now:now) }
        record.duration=elapsed(at:now); record.endedAt=now; state = .finished
    }
    private mutating func closeRest(now:Date) {
        record.rests.append(RestRecord(startedAt:phaseStartedAt,endedAt:now,duration:phaseElapsed(at:now),heartRate:record.heartRate.filter { $0.date >= phaseStartedAt && $0.date < now }))
    }
    public mutating func addHeartRate(_ sample:HeartRateSample) {
        guard state != .finished, sample.bpm.isFinite, sample.bpm > 0, sample.date >= record.startedAt, !(pausedAt.map { sample.date >= $0 } ?? false), !pauseIntervals.contains(where: { $0.start <= sample.date && sample.date < $0.end }), !record.heartRate.contains(where: { $0.id == sample.id || ($0.date == sample.date && $0.bpm == sample.bpm) }) else { return }
        record.heartRate.append(sample); record.heartRate.sort { $0.date < $1.date }
        // HealthKit callbacks may arrive after the user moves to the next phase.
        // Attribute by observation time, not delivery time.
        for index in record.exercises.indices where record.exercises[index].startedAt <= sample.date && sample.date < record.exercises[index].endedAt {
            record.exercises[index].heartRate.append(sample)
            record.exercises[index].heartRate.sort { $0.date < $1.date }
        }
        for index in record.rests.indices where record.rests[index].startedAt <= sample.date && sample.date < record.rests[index].endedAt {
            record.rests[index].heartRate.append(sample)
            record.rests[index].heartRate.sort { $0.date < $1.date }
        }
    }
    public mutating func markInterrupted(now:Date=Date()) { record.interrupted=true; finish(now:now) }
    public mutating func setFatigue(_ fatigue:Int) { record.fatigue=min(10,max(0,fatigue)) }
    public mutating func setActiveCalories(_ calories:Double?) { record.activeCalories=calories.flatMap { $0.isFinite && $0 >= 0 ? $0 : nil } }
    public mutating func setHealthWorkoutID(_ id:UUID) { record.healthWorkoutID=id }
}

