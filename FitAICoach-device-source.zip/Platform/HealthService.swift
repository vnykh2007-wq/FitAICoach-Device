import Foundation
import Combine
import HealthKit

/// Only watchOS constructs the primary builder and writes a workout to Apple Health.
@MainActor
final class HealthService: NSObject, ObservableObject {
    @Published private(set) var heartRate: Double?
    @Published private(set) var lastSampleDate: Date?
    @Published private(set) var activeEnergy: Double?
    @Published private(set) var status = "Пульс: нет данных"
    @Published private(set) var isRunning = false
    @Published private(set) var isPaused = false
    @Published private(set) var lastSavedWorkoutID: UUID?
    var onHeartSample: ((Date, Double) -> Void)?
    var onRemoteData: ((Data) -> Void)?
    var onInterrupted: ((String) -> Void)?
    var onStateChange: ((Bool, Bool) -> Void)?
    var onRecoveryUnavailable: (() -> Void)?
    #if os(watchOS)
    @Published private(set) var isRecovering = true
    #else
    @Published private(set) var isRecovering = false
    #endif
    private var recoveryRequested = false
    let store = HKHealthStore()
    private var session: HKWorkoutSession?
    #if os(watchOS)
    private var builder: HKLiveWorkoutBuilder?
    #endif
    private var finishing = false
    private var expectedEnd = false
    private var lastEmittedDate: Date?
    private let heartType = HKQuantityType.quantityType(forIdentifier: .heartRate)!
    private let energyType = HKQuantityType.quantityType(forIdentifier: .activeEnergyBurned)!

    override init() {
        super.init()
        #if os(iOS)
        store.workoutSessionMirroringStartHandler = { [weak self] mirrored in
            Task { @MainActor in
                guard let self else { return }
                self.session = mirrored; mirrored.delegate = self
                self.isRunning = true; self.status = "Тренировка на Apple Watch"
            }
        }
        #endif
    }
    var currentHeartRate: Double? {
        guard let date = lastSampleDate, Date().timeIntervalSince(date) <= 30 else { return nil }
        return heartRate
    }
    var heartRateMessage: String {
        guard let lastSampleDate else { return "Нет измерений. Проверьте посадку часов и разрешения в «Здоровье»." }
        if Date().timeIntervalSince(lastSampleDate) > 30 { return "Измерения временно не поступают. Проверьте контакт часов с кожей." }
        return "Последнее измерение: \(Int(heartRate ?? 0)) уд/мин"
    }
    func requestAuthorization() async throws {
        guard HKHealthStore.isHealthDataAvailable() else {
            throw HealthServiceError.unavailable
        }
        // Authorization completion does not reveal whether reading heart rate was allowed.
        #if os(watchOS)
        try await store.requestAuthorization(toShare: [HKObjectType.workoutType(), energyType], read: [heartType, energyType, HKObjectType.workoutType()])
        #else
        try await store.requestAuthorization(toShare: [], read: [HKObjectType.workoutType(), heartType, energyType])
        #endif
        status = "Запрос разрешений завершён. Ожидаем реальные измерения."
    }
    func prepareForNewWorkout() throws {
        guard !finishing, !isRecovering, session == nil || session?.state == .ended else {
            throw HealthServiceError.alreadyRunning
        }
        // Reset before authorization: a denied new session must not reuse the previous result.
        heartRate = nil; lastSampleDate = nil; activeEnergy = nil; lastEmittedDate = nil
        lastSavedWorkoutID = nil; expectedEnd = false
    }
    #if os(watchOS)
    func start() async throws {
        guard session == nil || session?.state == .ended else { throw HealthServiceError.alreadyRunning }
        guard store.authorizationStatus(for: HKObjectType.workoutType()) == .sharingAuthorized else {
            throw HealthServiceError.workoutPermission
        }
        let configuration = HKWorkoutConfiguration()
        configuration.activityType = .functionalStrengthTraining
        configuration.locationType = .indoor
        let workout = try HKWorkoutSession(healthStore: store, configuration: configuration)
        configure(workout, configuration: configuration)
        heartRate = nil; lastSampleDate = nil; activeEnergy = nil; lastEmittedDate = nil
        lastSavedWorkoutID = nil; expectedEnd = false
        let now = Date()
        workout.startActivity(with: now)
        do {
            try await builder!.beginCollection(at: now)
            isRunning = true; status = "Ожидаем измерения пульса"
            workout.startMirroringToCompanionDevice { [weak self] success, error in
                if !success { Task { @MainActor in self?.status = "Тренировка идёт на часах; iPhone пока недоступен" } }
            }
        } catch {
            expectedEnd = true; workout.end(); builder?.discardWorkout()
            session = nil; builder = nil
            throw error
        }
    }
    private func configure(_ workout: HKWorkoutSession, configuration: HKWorkoutConfiguration) {
        session = workout; workout.delegate = self
        let live = workout.associatedWorkoutBuilder()
        builder = live; live.delegate = self
        live.dataSource = HKLiveWorkoutDataSource(healthStore: store, workoutConfiguration: configuration)
    }
    func recover() async {
        guard !recoveryRequested else { return }
        recoveryRequested = true; isRecovering = true
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
        store.recoverActiveWorkoutSession { [weak self] recovered, error in
            Task { @MainActor in
                defer { continuation.resume() }
                guard let self else { return }
                self.isRecovering = false; self.recoveryRequested = false
                if let recovered {
                    self.expectedEnd = false; self.finishing = false; self.lastSavedWorkoutID = nil
                    self.configure(recovered, configuration: recovered.workoutConfiguration)
                    self.isRunning = recovered.state == .running || recovered.state == .paused
                    self.isPaused = recovered.state == .paused
                    self.status = "Тренировочная сессия восстановлена"
                    recovered.startMirroringToCompanionDevice { _, _ in }
                    self.onStateChange?(self.isRunning, self.isPaused)
                } else if let error {
                    self.status = "Не удалось восстановить HealthKit: \(error.localizedDescription)"
                    self.onRecoveryUnavailable?()
                } else {
                    self.onRecoveryUnavailable?()
                }
            }
        }
        }
    }
    /// End and save once. iPhone never calls finishWorkout.
    func finish() async throws -> UUID? {
        if let lastSavedWorkoutID { return lastSavedWorkoutID }
        guard !finishing, let session, let builder else { return nil }
        finishing = true; expectedEnd = true
        defer { finishing = false }
        session.end()
        do {
            try await builder.endCollection(at: Date())
            let workout = try await builder.finishWorkout()
            lastSavedWorkoutID = workout?.uuid
            isRunning = false; isPaused = false
            status = workout == nil ? "HealthKit не вернул запись; локальная история сохранена" : "Тренировка сохранена в «Здоровье»"
            self.session = nil; self.builder = nil
            return workout?.uuid
        } catch {
            // Never construct a second HKWorkout as a fallback: that could create duplicates.
            isRunning = false; isPaused = false
            status = "Ошибка сохранения в «Здоровье»: \(error.localizedDescription). Локальные результаты сохранены."
            self.session = nil; self.builder = nil
            throw error
        }
    }
    #else
    func start() async throws { throw HealthServiceError.watchRequired }
    func recover() async {}
    func finish() async throws -> UUID? { nil }
    #endif
    func pause() { session?.pause() }
    func discard() {
        #if os(watchOS)
        expectedEnd = true
        session?.end(); builder?.discardWorkout()
        builder = nil; session = nil
        lastSavedWorkoutID = nil; isRunning = false; isPaused = false
        heartRate = nil; lastSampleDate = nil; activeEnergy = nil
        status = "Тренировка отменена без сохранения"
        #endif
    }
    func resume() { session?.resume() }
    func sendMirrored(_ data: Data) {
        session?.sendToRemoteWorkoutSession(data: data) { _, _ in /* WCSession supplies durable fallback */ }
    }
}

extension HealthService: HKWorkoutSessionDelegate {
    nonisolated func workoutSession(_ workoutSession: HKWorkoutSession, didChangeTo toState: HKWorkoutSessionState, from fromState: HKWorkoutSessionState, date: Date) {
        Task { @MainActor in
            self.isRunning = toState == .running || toState == .paused
            self.isPaused = toState == .paused
            self.onStateChange?(self.isRunning, self.isPaused)
            #if os(watchOS)
            if toState == .ended && !self.expectedEnd {
                self.onInterrupted?("Сессия HealthKit завершена системой. Результаты сохранены локально.")
                do { _ = try await self.finish() } catch { self.status = error.localizedDescription }
            }
            #endif
        }
    }
    nonisolated func workoutSession(_ workoutSession: HKWorkoutSession, didFailWithError error: Error) {
        Task { @MainActor in
            self.status = "HealthKit: \(error.localizedDescription)"
            self.isRunning = false; self.onInterrupted?(self.status)
        }
    }
    nonisolated func workoutSession(_ workoutSession: HKWorkoutSession, didReceiveDataFromRemoteWorkoutSession data: [Data]) {
        Task { @MainActor in data.forEach { self.onRemoteData?($0) } }
    }
    nonisolated func workoutSession(_ workoutSession: HKWorkoutSession, didDisconnectFromRemoteDeviceWithError error: Error?) {
        Task { @MainActor in self.status = "Связь с другим устройством потеряна. Тренировка на часах продолжается." }
    }
}

#if os(watchOS)
extension HealthService: HKLiveWorkoutBuilderDelegate {
    nonisolated func workoutBuilderDidCollectEvent(_ workoutBuilder: HKLiveWorkoutBuilder) {}
    nonisolated func workoutBuilder(_ workoutBuilder: HKLiveWorkoutBuilder, didCollectDataOf collectedTypes: Set<HKSampleType>) {
        // Quantity/date come from the sensor-backed live builder, never from a timer.
        let heart = HKQuantityType.quantityType(forIdentifier: .heartRate)!
        let energy = HKQuantityType.quantityType(forIdentifier: .activeEnergyBurned)!
        let statistics = collectedTypes.contains(heart) ? workoutBuilder.statistics(for: heart) : nil
        let bpm = statistics?.mostRecentQuantity()?.doubleValue(for: HKUnit.count().unitDivided(by: .minute()))
        let date = statistics?.mostRecentQuantityDateInterval()?.end
        let calories = collectedTypes.contains(energy) ? workoutBuilder.statistics(for: energy)?.sumQuantity()?.doubleValue(for: .kilocalorie()) : nil
        Task { @MainActor in
            if let calories { self.activeEnergy = calories }
            if let bpm, let date, bpm.isFinite, bpm > 0, self.lastEmittedDate != date {
                self.lastEmittedDate = date; self.heartRate = bpm; self.lastSampleDate = date
                self.status = "Пульс обновлён"
                self.onHeartSample?(date, bpm)
            }
        }
    }
}
#endif

enum HealthServiceError: LocalizedError {
    case unavailable, alreadyRunning, workoutPermission, watchRequired
    var errorDescription: String? {
        switch self {
        case .unavailable: return "HealthKit недоступен на этом устройстве. Используйте локальный режим без пульса."
        case .alreadyRunning: return "Тренировка уже запущена."
        case .workoutPermission: return "Нет разрешения сохранять тренировки. Предоставьте его в «Здоровье» или выберите локальный режим."
        case .watchRequired: return "Запустите тренировку на Apple Watch."
        }
    }
}

