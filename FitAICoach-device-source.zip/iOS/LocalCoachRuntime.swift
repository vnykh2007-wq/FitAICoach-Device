import Foundation
import CryptoKit
import NativeLlama

enum LocalCoachError: LocalizedError {
    case missingModel, invalidModel, loadFailed, contextTooLong, inferenceFailed, overheated
    var errorDescription: String? {
        switch self {
        case .missingModel: return "Сначала скачайте модель тренера по Wi-Fi."
        case .invalidModel: return "Файл модели не прошёл проверку. Скачайте его заново."
        case .loadFailed: return "Не удалось загрузить модель в память. Закройте другие тяжёлые приложения и повторите."
        case .contextTooLong: return "Слишком длинный контекст. Сократите вопрос."
        case .inferenceFailed: return "Модель не смогла сформировать ответ. План не изменён."
        case .overheated: return "Телефон нагрелся. Дайте ему остыть перед следующим ответом тренера."
        }
    }
}

actor LocalCoachRuntime {
    static let shared = LocalCoachRuntime()
    static let modelBytes: Int64 = 639446688
    static let modelSHA = "9465e63a22add5354d9bb4b99e90117043c7124007664907259bd16d043bb031"
    static let modelURL = URL(string: "https://huggingface.co/Qwen/Qwen3-0.6B-GGUF/resolve/23749fefcc72300e3a2ad315e1317431b06b590a/Qwen3-0.6B-Q8_0.gguf")!
    static var modelPath: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("LocalAI/Qwen3-0.6B-Q8_0.gguf")
    }
    static var hasModel: Bool {
        (try? FileManager.default.attributesOfItem(atPath: modelPath.path)[.size] as? NSNumber)?.int64Value == modelBytes
    }
    private func verify(_ path: URL) throws {
        guard let size = try FileManager.default.attributesOfItem(atPath: path.path)[.size] as? NSNumber, size.int64Value == Self.modelBytes else { throw LocalCoachError.invalidModel }
        let file = try FileHandle(forReadingFrom: path); defer { try? file.close() }
        var hash = SHA256()
        while let data = try file.read(upToCount: 1_048_576), !data.isEmpty {
            try Task.checkCancellation(); hash.update(data: data)
        }
        guard hash.finalize().map({ String(format: "%02x", $0) }).joined() == Self.modelSHA else { throw LocalCoachError.invalidModel }
    }
    func download() async throws {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.allowsCellularAccess = false
        configuration.timeoutIntervalForResource = 1800
        let session = URLSession(configuration: configuration); defer { session.invalidateAndCancel() }
        let (temporary, response) = try await session.download(from: Self.modelURL)
        defer { try? FileManager.default.removeItem(at: temporary) }
        guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw LocalCoachError.invalidModel }
        try verify(temporary); try Task.checkCancellation()
        let directory = Self.modelPath.deletingLastPathComponent()
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        var noBackup = URLResourceValues(); noBackup.isExcludedFromBackup = true
        var mutableDirectory = directory; try mutableDirectory.setResourceValues(noBackup)
        if FileManager.default.fileExists(atPath: Self.modelPath.path) { _ = try FileManager.default.replaceItemAt(Self.modelPath, withItemAt: temporary) }
        else { try FileManager.default.moveItem(at: temporary, to: Self.modelPath) }
    }
    func generate(prompt: String, maxTokens: Int) throws -> String {
        try Task.checkCancellation()
        guard Self.hasModel else { throw LocalCoachError.missingModel }
        guard ProcessInfo.processInfo.thermalState != .serious, ProcessInfo.processInfo.thermalState != .critical else { throw LocalCoachError.overheated }
        try verify(Self.modelPath)
        llama_backend_init(); defer { llama_backend_free() }
        var parameters = llama_model_default_params()
        parameters.n_gpu_layers = 99
        #if os(macOS) || targetEnvironment(simulator)
        parameters.n_gpu_layers = 0
        #endif
        guard let model = llama_model_load_from_file(Self.modelPath.path, parameters) else { throw LocalCoachError.loadFailed }
        defer { llama_model_free(model) }
        var settings = llama_context_default_params()
        settings.n_ctx = 4096; settings.n_batch = 128; settings.n_ubatch = 128
        settings.n_threads = 3; settings.n_threads_batch = 3
        guard let context = llama_init_from_model(model, settings) else { throw LocalCoachError.loadFailed }
        defer { llama_free(context) }
        guard let vocab = llama_model_get_vocab(model), let sampler = llama_sampler_chain_init(llama_sampler_chain_default_params()) else { throw LocalCoachError.loadFailed }
        defer { llama_sampler_free(sampler) }
        llama_sampler_chain_add(sampler, llama_sampler_init_top_k(40))
        llama_sampler_chain_add(sampler, llama_sampler_init_top_p(0.9, 1))
        llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.4))
        llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED))
        let capacity = prompt.utf8.count + 16
        var tokens = [llama_token](repeating: 0, count: capacity)
        let count = tokens.withUnsafeMutableBufferPointer { buffer in
            llama_tokenize(vocab, prompt, Int32(prompt.utf8.count), buffer.baseAddress, Int32(capacity), true, true)
        }
        guard count > 0, Int(count) + maxTokens < 4096 else { throw LocalCoachError.contextTooLong }
        var batch = llama_batch_init(128, 0, 1); defer { llama_batch_free(batch) }
        func add(_ token: llama_token, position: Int32, logits: Bool) {
            let i = Int(batch.n_tokens)
            batch.token[i] = token; batch.pos[i] = position
            batch.n_seq_id[i] = 1; batch.seq_id[i]![0] = 0; batch.logits[i] = logits ? 1 : 0
            batch.n_tokens += 1
        }
        let started = Date()
        func check() throws {
            try Task.checkCancellation()
            if Date().timeIntervalSince(started) > 120 { throw LocalCoachError.inferenceFailed }
        }
        for offset in stride(from: 0, to: Int(count), by: 128) {
            try check(); batch.n_tokens = 0
            for index in offset..<min(offset + 128, Int(count)) { add(tokens[index], position: Int32(index), logits: index == Int(count) - 1) }
            guard llama_decode(context, batch) == 0 else { throw LocalCoachError.inferenceFailed }
        }
        var bytes = [UInt8](), reachedEnd = false
        for index in 0..<maxTokens {
            try check()
            let token = llama_sampler_sample(sampler, context, batch.n_tokens - 1)
            if llama_vocab_is_eog(vocab, token) { reachedEnd = true; break }
            var piece = [CChar](repeating: 0, count: 256)
            let length = piece.withUnsafeMutableBufferPointer { llama_token_to_piece(vocab, token, $0.baseAddress, 256, 0, false) }
            guard length >= 0, length <= 256 else { throw LocalCoachError.inferenceFailed }
            bytes.append(contentsOf: piece.prefix(Int(length)).map { UInt8(bitPattern: $0) })
            batch.n_tokens = 0; add(token, position: count + Int32(index), logits: true)
            guard llama_decode(context, batch) == 0 else { throw LocalCoachError.inferenceFailed }
        }
        let answer = String(decoding: bytes, as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)
        guard !answer.isEmpty else { throw LocalCoachError.inferenceFailed }
        return answer + (reachedEnd ? "" : "\n[Достигнут предел длины ответа]")
    }
}
