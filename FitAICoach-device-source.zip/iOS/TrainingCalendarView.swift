import SwiftUI

struct CalendarViewScreen: View {
    @EnvironmentObject var model: AppModel
    @State private var month = Date()
    @State private var selected = Date()
    private var calendar: Calendar { var value = Calendar(identifier: .gregorian); value.firstWeekday = 2; return value }
    private var monthStart: Date { calendar.date(from: calendar.dateComponents([.year, .month], from: month))! }
    private var cells: [Date?] {
        let leading = (calendar.component(.weekday, from: monthStart) + 5) % 7
        let count = calendar.range(of: .day, in: .month, for: monthStart)!.count
        return Array<Date?>(repeating: nil, count: leading) + (0..<count).map { calendar.date(byAdding: .day, value: $0, to: monthStart) }
    }
    private var title: String {
        let formatter = DateFormatter(); formatter.locale = Locale(identifier: "ru_RU"); formatter.dateFormat = "LLLL yyyy"
        return formatter.string(from: month).capitalized
    }
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                HStack {
                    Button { shift(-1) } label: { Image(systemName: "chevron.left") }.accessibilityLabel("Предыдущий месяц")
                    Spacer(); Text(title).font(.title.bold()).foregroundStyle(.red); Spacer()
                    Button { shift(1) } label: { Image(systemName: "chevron.right") }.accessibilityLabel("Следующий месяц")
                }
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 7), spacing: 18) {
                    ForEach(["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"], id: \.self) { Text($0).font(.caption).foregroundStyle(.secondary) }
                    ForEach(cells.indices, id: \.self) { index in
                        if let date = cells[index] { dayCell(date) } else { Color.clear.frame(height: 48) }
                    }
                }
                HStack { Label("Тренировка", systemImage: "circle.fill").foregroundStyle(.green); Label("Нет тренировки", systemImage: "circle.fill").foregroundStyle(.red) }.font(.caption)
                Label("Контрольный день / результат теста", systemImage: "flag.fill").font(.caption).foregroundStyle(.blue)
                selectedDay
                NavigationLink { ControlTestsScreen() } label: { Label("Контрольные дни и тесты", systemImage: "flag.checkered") }.buttonStyle(.bordered)
                Button("Сегодня") { month = Date(); selected = Date(); model.refreshDay() }
            }.padding()
        }.navigationTitle("Календарь").onAppear { model.refreshDay() }
    }
    private func shift(_ value: Int) { month = calendar.date(byAdding: .month, value: value, to: month) ?? month }
    private func dayCell(_ date: Date) -> some View {
        let state = TrainingCalendar.status(on: date, archive: model.archive, calendar: calendar)
        let scheduled = model.archive.controlSchedule?.isScheduled(date, calendar: calendar) ?? false
        let tested = model.archive.testResults.contains { calendar.isDate($0.date, inSameDayAs: date) }
        return Button { selected = date } label: {
            ZStack(alignment: .bottomTrailing) {
                Text("\(calendar.component(.day, from: date))").font(.headline).frame(maxWidth: .infinity).frame(height: 44)
                    .foregroundStyle(state == .trained || state == .missed ? Color.white : (state == .future || state == .unknown ? Color.secondary : Color.primary))
                    .background { Circle().fill(state == .trained ? Color.green : state == .missed ? Color.red : Color.clear) }
                    .overlay { Circle().stroke(calendar.isDate(date, inSameDayAs: selected) ? Color.fitAccent : Color.clear, lineWidth: 2) }
                if scheduled || tested { Image(systemName: "flag.fill").font(.system(size: 10)).foregroundStyle(.blue) }
            }
        }.buttonStyle(.plain).accessibilityLabel(date.formatted(date: .complete, time: .omitted) + ", " + description(state) + (scheduled || tested ? ", контрольный день" : ""))
    }
    private var selectedDay: some View {
        FitCard {
            Text(selected.formatted(date: .complete, time: .omitted)).font(.headline)
            Text(description(TrainingCalendar.status(on: selected, archive: model.archive, calendar: calendar)))
            ForEach(model.archive.history.filter { calendar.isDate($0.startedAt, inSameDayAs: selected) }) { record in
                NavigationLink { WorkoutDetail(record: record) } label: { Text(record.planName + " · " + clockString(record.duration)) }
            }
            ForEach((model.archive.externalWorkouts ?? []).filter { calendar.isDate($0.startedAt, inSameDayAs: selected) }) { activity in
                Text("Apple Health · \(activity.sourceName) · \(Int(activity.duration / 60)) мин").font(.caption)
            }
            ForEach(model.archive.testResults.filter { calendar.isDate($0.date, inSameDayAs: selected) }) { test in Text("\(test.kind.title): \(test.value) \(test.kind.unit)").font(.caption) }
            ForEach(model.archive.calendar.filter { calendar.isDate($0.date, inSameDayAs: selected) && !$0.reason.isEmpty }) { Text($0.reason).font(.caption).foregroundStyle(.secondary) }
        }
    }
    private func description(_ state: TrainingDay) -> String {
        switch state {
        case .trained: return "Тренировка записана"
        case .missed: return "Пропуск: в этот день нет записанной тренировки"
        case .pending: return "Сегодня тренировка ещё не записана. День пока не считается пропуском."
        case .future: return "Будущая дата"
        case .unknown: return "До начала отслеживания нет данных"
        }
    }
}
