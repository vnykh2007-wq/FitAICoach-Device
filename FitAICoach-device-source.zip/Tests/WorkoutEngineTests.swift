import XCTest
@testable import FitAICore

final class WorkoutEngineTests: XCTestCase {
    func testCalendarDetectsMissed24ButNotToday25OrFuture() {
        var calendar = Calendar(identifier: .gregorian); calendar.timeZone = TimeZone(secondsFromGMT: 7 * 3600)!
        func day(_ number: Int) -> Date { calendar.date(from: DateComponents(year: 2026, month: 10, day: number, hour: 12))! }
        var archive = AppArchive(plan: plan(), history: [WorkoutRecord(planName: "Тест", startedAt: day(23), endedAt: day(23).addingTimeInterval(600), duration: 600)])
        TrainingCalendar.reconcile(&archive, now: day(25), calendar: calendar)
        XCTAssertEqual(TrainingCalendar.status(on: day(23), archive: archive, now: day(25), calendar: calendar), .trained)
        XCTAssertEqual(TrainingCalendar.status(on: day(24), archive: archive, now: day(25), calendar: calendar), .missed)
        XCTAssertEqual(TrainingCalendar.status(on: day(25), archive: archive, now: day(25), calendar: calendar), .pending)
        XCTAssertEqual(TrainingCalendar.status(on: day(26), archive: archive, now: day(25), calendar: calendar), .future)
        XCTAssertEqual(TrainingCalendar.status(on: day(22), archive: archive, now: day(25), calendar: calendar), .unknown)
        let count = archive.calendar.count
        TrainingCalendar.reconcile(&archive, now: day(25), calendar: calendar)
        XCTAssertEqual(archive.calendar.count, count)
    }
    func testDailyStrengthAndRecoveryVaryWithoutChangingSameDay() {
        let tomorrow = Calendar.current.date(byAdding: .day, value: 1, to: zero)!
        XCTAssertEqual(DailyPlans.strength(on: zero).exercises.map { $0.exercise.id }, DailyPlans.strength(on: zero).exercises.map { $0.exercise.id })
        XCTAssertNotEqual(DailyPlans.strength(on: zero).exercises.map { $0.exercise.id }, DailyPlans.strength(on: tomorrow).exercises.map { $0.exercise.id })
        XCTAssertNotEqual(DailyPlans.recovery(on: zero, minutes: 30).exercises.map { $0.exercise.id }, DailyPlans.recovery(on: tomorrow, minutes: 30).exercises.map { $0.exercise.id })
    }
    func testAllControlProtocolsProduceSeparateResultsAndIgnoreInterrupted() {
        for kind in FitnessTestKind.allCases {
            var engine = WorkoutEngine(plan: kind.plan(), now: zero)
            XCTAssertEqual(engine.record.controlTestKind, kind)
            engine.startExercise(now: zero)
            engine.finishExercise(actualRepetitions: kind.countsRepetitions ? 12 : nil, now: zero.addingTimeInterval(65))
            let result = ControlTests.result(from: engine.record)
            XCTAssertEqual(result?.id, engine.record.id)
            XCTAssertEqual(result?.kind, kind)
            XCTAssertEqual(result?.value, kind.countsRepetitions ? 12 : 65)
            var interrupted = WorkoutEngine(plan: kind.plan(), now: zero)
            interrupted.startExercise(now: zero); interrupted.finish(now: zero.addingTimeInterval(10))
            XCTAssertNil(ControlTests.result(from: interrupted.record))
        }
        var short = WorkoutEngine(plan: FitnessTestKind.squats.plan(), now: zero)
        short.startExercise(now: zero); short.finishExercise(actualRepetitions: 4, now: zero.addingTimeInterval(20))
        XCTAssertNil(ControlTests.result(from: short.record))
        XCTAssertNil(ControlTests.result(from: WorkoutRecord(planName: "Обычная тренировка", startedAt: zero)))
    }
    func testControlScheduleAndLaunchExpiry() {
        let initial = ControlSchedule.initial(archive: AppArchive(plan: plan(), history: [WorkoutRecord(planName: "Первая", startedAt: zero)]), now: zero)
        XCTAssertEqual(initial.intervalDays, 7)
        XCTAssertTrue(Calendar.current.isDate(initial.nextDate, inSameDayAs: Calendar.current.date(byAdding: .day, value: 7, to: zero)!))
        let schedule = ControlSchedule(nextDate: zero, intervalDays: 14)
        XCTAssertTrue(schedule.isScheduled(zero))
        XCTAssertTrue(schedule.isScheduled(Calendar.current.date(byAdding: .day, value: 14, to: zero)!))
        XCTAssertFalse(schedule.isScheduled(Calendar.current.date(byAdding: .day, value: 1, to: zero)!))
        let request = WorkoutLaunchRequest(kind: .plank, now: zero)
        XCTAssertTrue(request.isFresh(now: zero.addingTimeInterval(2)))
        XCTAssertFalse(request.isFresh(now: zero.addingTimeInterval(200)))
    }
    func testPhoneExerciseCommandCannotCompleteAnotherSet() {
        var engine = WorkoutEngine(plan: plan(sets: 2), now: zero)
        engine.startExercise(now: zero)
        let command = RemoteCommand(workoutID: engine.record.id, kind: "completeExercise", exerciseID: engine.currentExercise?.id, setNumber: 1, expectedPhase: .exercise, repetitions: 6)
        XCTAssertTrue(command.matches(engine))
        engine.finishExercise(actualRepetitions: command.repetitions, now: zero.addingTimeInterval(20))
        XCTAssertFalse(command.matches(engine))
        engine.startNext(now: zero.addingTimeInterval(60)); engine.startExercise(now: zero.addingTimeInterval(60))
        XCTAssertFalse(command.matches(engine))
        XCTAssertEqual(engine.setNumber, 2)
    }
    func testMeasuredLoadUsesCoverageAndRejectsStaleReadings() {
        func recorded(_ bpm: Double, at start: Date) -> WorkoutRecord {
            WorkoutRecord(planName: "Синтетический тест", startedAt: start, endedAt: start.addingTimeInterval(100), duration: 100,
                          heartRate: (0...10).map { HeartRateSample(date: start.addingTimeInterval(Double($0) * 10), bpm: bpm) })
        }
        let prior = (1...3).map { recorded(100, at: zero.addingTimeInterval(Double(-$0) * 86400)) }
        let current = recorded(125, at: zero)
        let load = SensorLoad.assess(record: current, history: prior, now: zero.addingTimeInterval(100), live: true)
        XCTAssertEqual(load.average, 125)
        XCTAssertTrue(load.higherThanUsual)
        XCTAssertNil(SensorLoad.assess(record: current, history: prior, now: zero.addingTimeInterval(200), live: true).average)
        var sparse = current; sparse.heartRate = [current.heartRate[0], current.heartRate[10]]
        XCTAssertNil(SensorLoad.assess(record: sparse, history: prior).average)
        XCTAssertFalse(SensorLoad.assess(record: current, history: []).higherThanUsual)
    }
    func testExistingWalkReplacesOnlyMainWalkingAndDeduplicates() {
        let walk = ExternalWorkout(id: UUID(), startedAt: zero.addingTimeInterval(-1000), endedAt: zero.addingTimeInterval(-100), duration: 900, kind: "walking", outdoor: true, sourceName: "Тест")
        XCTAssertEqual(DailyActivity.walkingMinutes([walk, walk], now: zero), 15)
        let plan = SeedData.defaultPlan()
        let adapted = DailyActivity.adapt(plan, workouts: [walk], now: zero)
        XCTAssertFalse(adapted.exercises.contains { $0.exercise.id == "walk" })
        XCTAssertTrue(adapted.exercises.contains { $0.exercise.id == "mobility" })
        XCTAssertEqual(adapted.exercises.filter { $0.exercise.id == "pushups" }, plan.exercises.filter { $0.exercise.id == "pushups" })
        var recovery = plan; recovery.isLight = true
        XCTAssertEqual(DailyActivity.adapt(recovery, workouts: [walk], now: zero), recovery)
        XCTAssertEqual(DailyActivity.adapt(plan, workouts: [walk], now: zero.addingTimeInterval(86400)), plan)
    }
    func testPreUpgradeArchiveBackupIsExactAndNotOverwritten() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = JSONStore(directory: directory)
        var archive = AppArchive(plan: plan())
        var engine = WorkoutEngine(plan: plan(), now: zero)
        engine.startExercise(now: zero); engine.addHeartRate(HeartRateSample(date: zero.addingTimeInterval(5), bpm: 123))
        engine.finishExercise(actualRepetitions: 7, now: zero.addingTimeInterval(25))
        archive.history = [engine.record]
        try store.save(archive, name: "archive")
        let original = try Data(contentsOf: directory.appendingPathComponent("archive.json"))
        try store.backupArchiveBeforeUpgrade()
        archive.history = []; try store.save(archive, name: "archive")
        try store.backupArchiveBeforeUpgrade()
        XCTAssertEqual(try Data(contentsOf: directory.appendingPathComponent("archive-before-v2.json")), original)
        let backup = try XCTUnwrap(store.load(AppArchive.self, name: "archive-before-v2"))
        ArchiveRestore.merge(backup, into: &archive); ArchiveRestore.merge(backup, into: &archive)
        XCTAssertEqual(archive.history, [engine.record])
    }
    func testRestoreKeepsRicherHistoryAndHealthLink() {
        var engine = WorkoutEngine(plan: plan(), now: zero)
        engine.startExercise(now: zero); engine.addHeartRate(HeartRateSample(date: zero.addingTimeInterval(5), bpm: 120))
        engine.finishExercise(actualRepetitions: 7, now: zero.addingTimeInterval(20))
        let healthID = UUID(); engine.setHealthWorkoutID(healthID); engine.setActiveCalories(10)
        var local = AppArchive(plan: plan(), history: [engine.record])
        var stale = engine.record; stale.heartRate = []; stale.healthWorkoutID = nil; stale.activeCalories = nil
        ArchiveRestore.merge(AppArchive(plan: plan(), history: [stale]), into: &local)
        XCTAssertEqual(local.history, [engine.record])
    }
    func testWarmupExpansionIsIdempotentAndKeepsMainExercises() {
        let legacy = WorkoutPlan(name: "Старый план", exercises: [ExercisePlan(exercise: ExerciseLibrary.named("warmup")), ExercisePlan(exercise: ExerciseLibrary.named("pushups"))])
        let expanded = ExerciseLibrary.expandWarmup(in: legacy)
        XCTAssertEqual(expanded.exercises.count, 7)
        XCTAssertEqual(expanded.exercises.prefix(6).compactMap(\.durationSeconds), [60, 30, 60, 30, 60])
        XCTAssertEqual(expanded.exercises[4].repetitions, 15)
        XCTAssertEqual(expanded.exercises.last?.id, legacy.exercises.last?.id)
        XCTAssertEqual(ExerciseLibrary.expandWarmup(in: expanded), expanded)
    }
    func testWarmupDoesNotInsertRestAndPauseStillFreezesClock() {
        var engine = WorkoutEngine(plan: WorkoutPlan(name: "Разминка", exercises: ExerciseLibrary.warmupSteps()), now: zero)
        engine.startExercise(now: zero)
        engine.pause(now: zero.addingTimeInterval(20))
        engine.resume(now: zero.addingTimeInterval(40))
        engine.finishExercise(actualRepetitions: nil, now: zero.addingTimeInterval(80))
        XCTAssertEqual(engine.record.exercises.first?.duration, 60)
        XCTAssertEqual(engine.state, .ready)
        XCTAssertEqual(engine.currentExercise?.exercise.id, "warmupArms")
        XCTAssertEqual(engine.record.rests.count, 1)
        XCTAssertEqual(engine.record.rests.first?.duration, 0)
    }
    func testDeletedHistoryCannotReturnFromOfflineCopy() throws {
        let first = WorkoutRecord(planName: "Случайная", startedAt: zero, endedAt: zero.addingTimeInterval(5))
        let second = WorkoutRecord(planName: "Нужная", startedAt: zero, endedAt: zero.addingTimeInterval(600))
        var archive = AppArchive(plan: SeedData.defaultPlan(), history: [first, second], calendar: [CalendarEntry(date: zero, status: .completed, workoutID: first.id)])
        WorkoutHistory.delete(first.id, from: &archive)
        XCTAssertEqual(archive.history.map(\.id), [second.id])
        XCTAssertEqual(archive.calendar.first?.workoutID, second.id)
        let saved = try JSONEncoder().encode(archive)
        archive = try JSONDecoder().decode(AppArchive.self, from: saved)
        archive.history.append(first) // A stale peer still holds the deleted workout.
        WorkoutHistory.mergeDeleted([], into: &archive)
        XCTAssertEqual(archive.history.map(\.id), [second.id])
        WorkoutHistory.delete(second.id, from: &archive)
        XCTAssertTrue(archive.history.isEmpty)
        XCTAssertTrue(archive.calendar.isEmpty)
    }
    func testOldArchiveDecodesAndManualCalendarSurvivesDeletion() throws {
        var archive = AppArchive(plan: SeedData.defaultPlan())
        let record = WorkoutRecord(planName: "Удалить", startedAt: zero)
        archive.history = [record]
        archive.calendar = [CalendarEntry(date: zero, status: .rest, reason: "Моя отметка")]
        var old = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(archive)) as? [String: Any])
        old.removeValue(forKey: "deletedWorkoutIDs")
        archive = try JSONDecoder().decode(AppArchive.self, from: JSONSerialization.data(withJSONObject: old))
        XCTAssertNil(archive.deletedWorkoutIDs)
        WorkoutHistory.delete(record.id, from: &archive)
        XCTAssertEqual(archive.calendar.first?.reason, "Моя отметка")
    }
    let zero=Date(timeIntervalSince1970:1_700_000_000)
    func plan(sets:Int=1,two:Bool=false) -> WorkoutPlan {
        let entry=ExercisePlan(exercise:ExerciseLibrary.named("pushups"),repetitions:8,sets:sets,restSeconds:30)
        return WorkoutPlan(name:"Тест",exercises:two ? [entry,ExercisePlan(exercise:ExerciseLibrary.named("squats"))] : [entry])
    }
    func testStartFinishAndActualRepetitions() {
        var engine=WorkoutEngine(plan:plan(),now:zero)
        XCTAssertEqual(engine.state,.ready)
        engine.startExercise(now:zero)
        engine.finishExercise(actualRepetitions:6,now:zero.addingTimeInterval(20))
        XCTAssertEqual(engine.state,.finished)
        XCTAssertEqual(engine.record.exercises.count,1)
        XCTAssertEqual(engine.record.exercises[0].actualRepetitions,6)
        XCTAssertEqual(engine.record.exercises[0].plannedRepetitions,8)
        XCTAssertEqual(engine.record.duration,20)
        XCTAssertFalse(engine.record.interrupted)
        engine.finish(now:zero.addingTimeInterval(100))
        XCTAssertEqual(engine.record.duration,20)
    }
    func testPauseExcludesTimeInExerciseAndWorkout() {
        var engine=WorkoutEngine(plan:plan(),now:zero)
        engine.startExercise(now:zero)
        engine.pause(now:zero.addingTimeInterval(10))
        XCTAssertEqual(engine.elapsed(at:zero.addingTimeInterval(90)),10)
        engine.resume(now:zero.addingTimeInterval(40))
        engine.finishExercise(actualRepetitions:8,now:zero.addingTimeInterval(50))
        XCTAssertEqual(engine.record.duration,20)
        XCTAssertEqual(engine.record.exercises.first?.duration,20)
    }
    func testSetsRestAndExtension() {
        var engine=WorkoutEngine(plan:plan(sets:2),now:zero)
        engine.startExercise(now:zero)
        engine.finishExercise(actualRepetitions:8,now:zero.addingTimeInterval(10))
        XCTAssertEqual(engine.state,.rest)
        XCTAssertEqual(engine.restRemaining(at:zero.addingTimeInterval(15)),25)
        engine.extendRest()
        XCTAssertEqual(engine.restRemaining(at:zero.addingTimeInterval(15)),55)
        engine.pause(now:zero.addingTimeInterval(15))
        XCTAssertEqual(engine.restRemaining(at:zero.addingTimeInterval(100)),55)
        engine.resume(now:zero.addingTimeInterval(100))
        engine.startNext(now:zero.addingTimeInterval(110))
        XCTAssertEqual(engine.setNumber,2)
        XCTAssertEqual(engine.state,.ready)
        XCTAssertEqual(engine.record.rests.first?.duration,15)
        engine.startExercise(now:zero.addingTimeInterval(110))
        engine.finishExercise(actualRepetitions:7,now:zero.addingTimeInterval(130))
        XCTAssertEqual(engine.record.exercises.map(\.setNumber),[1,2])
    }
    func testRealSamplesOnlyAndDeduplication() {
        var engine=WorkoutEngine(plan:plan(),now:zero)
        XCTAssertNil(engine.record.statistics.average)
        engine.startExercise(now:zero)
        let sample=HeartRateSample(date:zero.addingTimeInterval(5),bpm:100)
        engine.addHeartRate(sample); engine.addHeartRate(sample)
        engine.addHeartRate(HeartRateSample(date:zero.addingTimeInterval(8),bpm:140))
        engine.addHeartRate(HeartRateSample(date:zero.addingTimeInterval(9),bpm:-1))
        engine.finishExercise(actualRepetitions:8,now:zero.addingTimeInterval(10))
        XCTAssertEqual(engine.record.statistics.average,120)
        XCTAssertEqual(engine.record.statistics.maximum,140)
        XCTAssertEqual(engine.record.exercises[0].statistics.count,2)
    }
    func testCommandDuplicateAndWrongWorkout() {
        var engine=WorkoutEngine(plan:plan(two:true),now:zero)
        engine.startExercise(now:zero)
        var ledger=CommandLedger()
        let finish=WorkoutCommand(workoutID:engine.record.id,action:.finishExercise,repetitions:6)
        XCTAssertTrue(ledger.apply(finish,to:&engine,now:zero.addingTimeInterval(10)))
        XCTAssertFalse(ledger.apply(finish,to:&engine,now:zero.addingTimeInterval(20)))
        XCTAssertEqual(engine.record.exercises.count,1)
        XCTAssertFalse(ledger.apply(WorkoutCommand(workoutID:UUID(),action:.finish),to:&engine))
        XCTAssertEqual(engine.state,.rest)
    }
    func testInterruptedExercisePreserved() {
        var engine=WorkoutEngine(plan:plan(),now:zero)
        engine.startExercise(now:zero)
        engine.finish(now:zero.addingTimeInterval(10))
        XCTAssertTrue(engine.record.interrupted)
        XCTAssertTrue(engine.record.exercises[0].skipped)
        XCTAssertNil(engine.record.exercises[0].actualRepetitions)
    }
    func testAtomicSaveAndRecovery() throws {
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at:directory) }
        let store=JSONStore(directory:directory)
        var engine=WorkoutEngine(plan:plan(sets:2),now:zero)
        engine.startExercise(now:zero)
        engine.addHeartRate(HeartRateSample(date:zero.addingTimeInterval(2),bpm:105))
        engine.pause(now:zero.addingTimeInterval(10))
        try store.save(engine,name:"active")
        var recovered=try XCTUnwrap(store.load(WorkoutEngine.self,name:"active"))
        XCTAssertEqual(recovered.state,.paused)
        XCTAssertEqual(recovered.record.id,engine.record.id)
        recovered.resume(now:zero.addingTimeInterval(30))
        recovered.finishExercise(actualRepetitions:6,now:zero.addingTimeInterval(40))
        XCTAssertEqual(recovered.record.exercises[0].duration,20)
        XCTAssertEqual(recovered.record.statistics.average,105)
        try store.save(SeedData.archive(),name:"archive")
        XCTAssertEqual(try store.load(AppArchive.self,name:"archive")?.history.count,0)
    }
    func testCorruptionIsNotSilentlyReplaced() throws {
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at:directory) }
        try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
        try Data("invalid json".utf8).write(to:directory.appendingPathComponent("archive.json"))
        XCTAssertThrowsError(try JSONStore(directory:directory).load(AppArchive.self,name:"archive"))
    }
    func testSeedNeverFabricatesMeasurements() {
        let archive = SeedData.archive()
        XCTAssertTrue(archive.history.isEmpty)
        XCTAssertTrue(archive.calendar.isEmpty)
        XCTAssertTrue(archive.testResults.isEmpty)
        XCTAssertEqual(archive.profile.age, 0)
        XCTAssertEqual(archive.profile.weightKG, 0)
    }
    func testCoachRecoveryAndHonestChat() {
        let archive=SeedData.archive()
        XCTAssertTrue(CoachEngine.makePlan(archive:archive,fatigue:8,now:zero).isLight)
        XCTAssertTrue(CoachEngine.makePlan(archive:archive,sleepHours:4,now:zero).isLight)
        XCTAssertTrue(CoachEngine.reply(to:"болит плечо",archive:archive).contains("Прекрати"))
        XCTAssertTrue(CoachEngine.reply(to:"непонятный запрос",archive:archive).contains("правил"))
    }
    func testEmptyPlanFinishesSafely() {
        let engine=WorkoutEngine(plan:WorkoutPlan(name:"Пустой",exercises:[]),now:zero)
        XCTAssertEqual(engine.state,.finished)
        XCTAssertNil(engine.currentExercise)
    }
    func testDelayedSamplesAttributedToObservationPhaseAndPauseExcluded() {
        var engine=WorkoutEngine(plan:plan(two:true),now:zero)
        engine.startExercise(now:zero)
        engine.pause(now:zero.addingTimeInterval(3))
        engine.resume(now:zero.addingTimeInterval(7))
        engine.finishExercise(actualRepetitions:8,now:zero.addingTimeInterval(10))
        engine.addHeartRate(HeartRateSample(date:zero.addingTimeInterval(2),bpm:100))
        engine.addHeartRate(HeartRateSample(date:zero.addingTimeInterval(5),bpm:190))
        engine.addHeartRate(HeartRateSample(date:zero.addingTimeInterval(12),bpm:120))
        XCTAssertEqual(engine.record.exercises[0].statistics.average,100)
        XCTAssertEqual(engine.record.statistics.average,110)
    }
    func testCoachProgressionUsesPreviousPlannedRepetitions() {
        var archive=SeedData.archive()
        archive.settings.dailyVariationEnabled = false
        var engine=WorkoutEngine(plan:WorkoutPlan(name:"Программа",exercises:[ExercisePlan(exercise:ExerciseLibrary.named("pushups"),repetitions:7)]),now:zero)
        engine.startExercise(now:zero)
        engine.finishExercise(actualRepetitions:7,now:zero.addingTimeInterval(10))
        engine.setFatigue(4)
        archive.history=[engine.record]
        let plan=CoachEngine.makePlan(archive:archive,now:zero.addingTimeInterval(72*3600))
        XCTAssertEqual(plan.exercises.first { $0.exercise.id == "pushups" }?.repetitions,7)
    }

    func testDatedTestResultsSurviveExportRoundTrip() throws {
        var archive=SeedData.archive()
        XCTAssertTrue(archive.testResults.isEmpty)
        archive.testResults.append(FitnessTestRecord(date:zero,kind:.pushups,value:17,note:"Отдельный тест"))
        let encoder=JSONEncoder(); encoder.dateEncodingStrategy = .iso8601
        let decoder=JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
        let restored=try decoder.decode(AppArchive.self,from:encoder.encode(archive))
        XCTAssertEqual(restored.testResults.count,1)
        XCTAssertEqual(restored.testResults.last?.date,zero)
        XCTAssertEqual(restored.testResults.last?.value,17)
    }

}
