import SwiftUI
import Combine

private struct DeviceSnapshot: Codable {
    var engine: WorkoutEngine?
    var history: [WorkoutRecord]
    var plan: WorkoutPlan
    var settings: AppSettings
    var profile: Profile
    var calendar: [CalendarEntry]
    var testResults: [FitnessTestRecord]
    var revision: UInt64
}

@MainActor final class AppModel: ObservableObject {
    @Published var archive: AppArchive
    @Published var engine: WorkoutEngine?
    @Published var message = ""
    @Published var fatigue = 5
    @Published var sleepHours = 8.0
    @Published var useSleep = false
    @Published var busy = false
    let health = HealthService()
    let connectivity = ConnectivityService()
    private let storage = JSONStore()
    private var subscriptions = Set<AnyCancellable>()
    private var localRevision: UInt64 = 0
    private var receivedRevision: UInt64 = 0
    private var storageReadable = true
    init() {
        archive = SeedData.archive()
        do {
            archive = try storage.load(AppArchive.self, name: "archive") ?? SeedData.archive()
            engine = try storage.load(WorkoutEngine.self, name: "active-workout")
            localRevision = try storage.load(UInt64.self, name: "local-revision") ?? 0
            receivedRevision = try storage.load(UInt64.self, name: "received-revision") ?? 0
        } catch {
            storageReadable = false
            message = "Не удалось прочитать локальные данные. Сохранение отключено, чтобы не перезаписать исходные файлы. \(error.localizedDescription)"
        }
        health.objectWillChange.sink { [weak self] _ in self?.objectWillChange.send() }.store(in: &subscriptions)
        connectivity.objectWillChange.sink { [weak self] _ in self?.objectWillChange.send() }.store(in: &subscriptions)
        health.onHeartSample = { [weak self] date, bpm in
            guard let self else { return }
            self.engine?.addHeartRate(HeartRateSample(date: date, bpm: bpm))
            self.persist(); self.broadcast()
        }
        health.onInterrupted = { [weak self] text in
            guard let self else { return }; self.message = text
            #if os(watchOS)
            self.engine?.markInterrupted(); self.saveCurrentRecord()
            #endif
            self.persist(); self.broadcast()
        }
        health.onRecoveryUnavailable = { [weak self] in
            #if os(watchOS)
            guard let self, let engine = self.engine, engine.state != .finished else { return }
            self.engine?.pause(); self.persist(); self.broadcast()
            self.message = "Подходы восстановлены локально, но активной сессии HealthKit нет. Можно завершить тренировку или продолжить локальный учёт без пульса."
            #endif
        }
        connectivity.onReconnect = { [weak self] in self?.broadcast() }
        health.onStateChange = { [weak self] running, paused in
            #if os(watchOS)
            guard let self, running else { return }
            if self.engine?.state == .finished { Task { await self.stop() }; return }
            if paused { self.engine?.pause() }
            else if self.engine?.state == .paused { self.engine?.resume() }
            self.persist(); self.broadcast()
            #endif
        }
        health.onRemoteData = { [weak self] data in self?.receive(data) }
        connectivity.onSnapshot = { [weak self] data in self?.receive(data) }
        connectivity.onCommand = { [weak self] command in
            guard let self, self.engine?.record.id == command.workoutID else { return }
            #if os(watchOS)
            if command.kind == "pause" { self.pause() }
            if command.kind == "resume" { self.resume() }
            if command.kind == "stop" { self.engine?.finish(); self.saveCurrentRecord(); self.persist(); Task { await self.stop() } }
            #endif
        }
        persist()
        #if os(watchOS)
        Task { await health.recover() }
        #endif
    }
    func persist() {
        guard storageReadable else { return }
        do { try storage.save(archive, name: "archive"); if let engine { try storage.save(engine, name: "active-workout") } else { try storage.remove(name: "active-workout") } }
        catch { message = "Не удалось сохранить данные: \(error.localizedDescription)" }
    }
    func broadcast() {
        guard storageReadable else { return }
        localRevision += 1
        try? storage.save(localRevision, name: "local-revision")
        let packet = DeviceSnapshot(engine: engine, history: archive.history, plan: archive.plan, settings: archive.settings, profile: archive.profile, calendar: archive.calendar, testResults: archive.testResults, revision: localRevision)
        guard let data = try? JSONEncoder().encode(packet) else { return }
        connectivity.sendSnapshot(data)
        health.sendMirrored(data)
    }
    private func receive(_ data: Data) {
        guard let packet = try? JSONDecoder().decode(DeviceSnapshot.self, from: data), packet.revision > receivedRevision else { return }
        receivedRevision = packet.revision
        try? storage.save(receivedRevision, name: "received-revision")
        #if os(iOS)
        engine = packet.engine
        for record in packet.history {
            archive.history.removeAll { $0.id == record.id }; archive.history.append(record)
            markCalendar(record) 
        }
        #else
        archive.plan = packet.plan; archive.settings = packet.settings; archive.profile = packet.profile
        archive.calendar = packet.calendar; archive.testResults = packet.testResults
        // The current engine owns an immutable copy of its starting plan.
        // Reapply watch results after phone calendar edits so an old phone copy
        // cannot erase today's locally completed session while offline.
        for record in archive.history where !record.dateOnly { markCalendar(record) }
        #endif
        persist()
    }
    func preparePlan() {
        archive.plan = CoachEngine.makePlan(archive: archive, fatigue: fatigue, sleepHours: useSleep ? sleepHours : nil)
        persist(); broadcast()
    }
    func start() async {
        #if os(watchOS)
        guard storageReadable else { message = "Нельзя начать тренировку: локальное хранилище недоступно. Сначала восстановите сохранение данных."; return }
        guard !health.isRecovering else { message = "Проверяем восстановление сессии. Повторите запуск через несколько секунд."; return }
        guard !busy, engine == nil || engine?.state == .finished else { return }
        busy = true; defer { busy = false }
        do { try health.prepareForNewWorkout() }
        catch { message = "Предыдущая сессия HealthKit ещё активна. Сначала завершите её."; return }
        let recoveryPlan = CoachEngine.makePlan(archive: archive, fatigue: fatigue, sleepHours: useSleep ? sleepHours : nil)
        let sessionPlan = recoveryPlan.isLight ? recoveryPlan : archive.plan
        engine = WorkoutEngine(plan: sessionPlan)
        persist()
        do { try await health.requestAuthorization(); try await health.start() }
        catch { message = "HealthKit недоступен: \(error.localizedDescription). Учёт упражнений доступен без пульса." }
        broadcast()
        #else
        message = "Откройте FitAI Coach на Apple Watch и начните тренировку там. Часы управляют сессией."
        #endif
    }
    func beginExercise() { engine?.startExercise(); changed() }
    func complete(reps: Int?, skipped: Bool = false) { engine?.finishExercise(actualRepetitions: reps, skipped: skipped); changed() }
    func next() { engine?.startNext(); changed() }
    func extendRest() { engine?.extendRest(); changed() }
    func pause() {
        #if os(watchOS)
        engine?.pause(); health.pause(); changed()
        #else
        if let id = engine?.record.id { connectivity.sendCommand(kind: "pause", workoutID: id) }
        #endif
    }
    func resume() {
        #if os(watchOS)
        engine?.resume(); health.resume(); changed()
        #else
        if let id = engine?.record.id { connectivity.sendCommand(kind: "resume", workoutID: id) }
        #endif
    }
    func stop() async {
        #if os(watchOS)
        guard !busy, engine != nil else { return }; busy = true; defer { busy = false }
        engine?.finish()
        saveCurrentRecord(); persist(); broadcast()
        if engine?.record.healthWorkoutID == nil {
            do { if let id = try await health.finish() { engine?.setHealthWorkoutID(id) }; engine?.setActiveCalories(health.activeEnergy) }
            catch { message = "История сохранена локально. Apple Health: \(error.localizedDescription)" }
        }
        saveCurrentRecord(); persist(); broadcast()
        #else
        if let id = engine?.record.id { connectivity.sendCommand(kind: "stop", workoutID: id) }
        #endif
    }
    private func saveCurrentRecord() {
        guard let record = engine?.record else { return }
        archive.history.removeAll { $0.id == record.id }; archive.history.append(record); markCalendar(record)
    }
    private func markCalendar(_ record: WorkoutRecord) {
        guard record.endedAt != nil else { return }
        archive.calendar.removeAll { Calendar.current.isDate($0.date, inSameDayAs: record.startedAt) }
        archive.calendar.append(CalendarEntry(date: record.startedAt, status: record.isLight ? .light : .completed, reason: record.interrupted ? "Тренировка прервана; сохранены доступные результаты" : ""))
    }
    func saveFatigueReport() { engine?.setFatigue(fatigue); saveCurrentRecord(); persist(); broadcast(); message = "Отчёт сохранён" }
    func changed() { persist(); broadcast() }
    var currentHeartRate: String {
        #if os(iOS)
        guard let sample = engine?.record.heartRate.last, Date().timeIntervalSince(sample.date) < 30 else { return "Нет данных" }
        return "\(Int(sample.bpm)) уд/мин"
        #else
        guard let value = health.currentHeartRate else { return "Нет данных" }
        return "\(Int(value)) уд/мин"
        #endif
    }
    func deleteLocalData() {
        storageReadable = true
        archive = AppArchive(plan: WorkoutPlan(name: "Новая программа", exercises: [])); archive.profile.pushUpMaximum = 0; archive.profile.plankMaximumSeconds = 0
        archive.profile.age = 0; archive.profile.heightCM = 0; archive.profile.weightKG = 0
        connectivity.clearLocalData(); try? storage.remove(name: "chat")
        for name in ["FitAI-history.json", "FitAI-exercises.csv"] {
            try? FileManager.default.removeItem(at: FileManager.default.temporaryDirectory.appendingPathComponent(name))
        }
        engine = nil; persist()
        message = "Локальная история удалена. Записи Apple Health и данные другого устройства не удалены."
    }
    func exportCSV() -> URL? {
        func cell(_ value: String) -> String { "\"" + value.replacingOccurrences(of: "\"", with: "\"\"") + "\"" }
        var rows = ["workout_id,start,exercise,set,planned_reps,actual_reps,duration_seconds,average_hr,max_hr"]
        for workout in archive.history {
            for exercise in workout.exercises {
                let statistics = exercise.statistics
                var fields: [String] = []
                fields.append(workout.id.uuidString)
                fields.append(ISO8601DateFormatter().string(from: exercise.startedAt))
                fields.append(exercise.exercise.name)
                fields.append(String(exercise.setNumber))
                fields.append(exercise.plannedRepetitions.map { String($0) } ?? "")
                fields.append(exercise.actualRepetitions.map { String($0) } ?? "")
                fields.append(String(exercise.duration))
                fields.append(statistics.average.map { String($0) } ?? "")
                fields.append(statistics.maximum.map { String($0) } ?? "")
                rows.append(fields.map(cell).joined(separator: ","))
            }
        }
        do { let url = FileManager.default.temporaryDirectory.appendingPathComponent("FitAI-exercises.csv"); try rows.joined(separator: "\n").write(to: url, atomically: true, encoding: .utf8); return url }
        catch { message = error.localizedDescription; return nil }
    }
    func exportJSON() -> URL? {
        do {
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("FitAI-history.json")
            let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]; encoder.dateEncodingStrategy = .iso8601
            try encoder.encode(archive).write(to: url, options: .atomic); return url
        } catch { message = error.localizedDescription; return nil }
    }
}
