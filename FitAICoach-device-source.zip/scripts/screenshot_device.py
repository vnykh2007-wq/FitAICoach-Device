"""Prepare an iPhone simulator for interactive XCTest screenshots on macOS."""
import json
from pathlib import Path
import subprocess

def call(*args):
    return subprocess.check_output(['xcrun', 'simctl', *args], text=True)

inventory = json.loads(call('list', 'devices', 'available', '--json'))['devices']
runtime = next(key for key in inventory if key.endswith('iOS-26-2'))
device = next((d for d in inventory[runtime] if d['name'] == 'iPhone 15 Plus'), None)
if device:
    udid = device['udid']
else:
    types = json.loads(call('list', 'devicetypes', '--json'))['devicetypes']
    kind = next(d['identifier'] for d in types if d['name'] == 'iPhone 15 Plus')
    udid = call('create', 'iPhone 15 Plus', kind, runtime).strip()
if not device or device['state'] != 'Booted':
    call('boot', udid)
subprocess.run(['xcrun', 'simctl', 'bootstatus', udid, '-b'], check=True)
Path('build/screenshot-device.txt').write_text(udid)
