import Foundation

public struct SensorLoad: Equatable, Sendable {
    public var average: Double?
    public var maximum: Double?
    public var measuredSeconds: TimeInterval
    public var higherThanUsual: Bool
    public var referenceAverage: Double?
    public var summary: String {
        guard let average else { return "Недостаточно непрерывных измерений пульса. Оценка нагрузки недоступна." }
        let values = "Средний пульс \(Int(average)), максимум \(Int(maximum ?? average)) уд/мин; измерений на \(Int(measuredSeconds / 60)) мин."
        guard let referenceAverage else { return values + " Накапливаем историю для сравнения с вашими тренировками." }
        return values + " Ваш ориентир: \(Int(referenceAverage)) уд/мин. " + (higherThanUsual ? "Пульсовая реакция выше обычной: можно снизить темп или продлить отдых." : "Средний пульс не превышает выбранный ориентир более чем на 15%. Это не оценка безопасности нагрузки.")
    }
    /// Compare only sensor-backed strength workouts with at least 60 seconds of coverage.
    /// This is a local descriptive heuristic, not a clinical intensity or recovery score.
    public static func assess(record: WorkoutRecord, history: [WorkoutRecord], now: Date = Date(), live: Bool = false) -> SensorLoad {
        let current = measurements(record.heartRate)
        let references = history.filter { $0.id != record.id && $0.controlTestKind == nil && !$0.isLight && !$0.interrupted && !$0.dateOnly && $0.startedAt < record.startedAt }
            .sorted { $0.startedAt > $1.startedAt }.prefix(5).compactMap { measurements($0.heartRate).average }.sorted()
        let reference = record.controlTestKind == nil && references.count >= 3 ? references[references.count / 2] : nil
        let fresh = !live || (record.heartRate.last.map { now.timeIntervalSince($0.date) >= 0 && now.timeIntervalSince($0.date) <= 30 } ?? false)
        let average = fresh ? current.average : nil
        return SensorLoad(average: average, maximum: fresh ? current.maximum : nil, measuredSeconds: current.seconds,
                          higherThanUsual: average.map { value in reference.map { value > $0 * 1.15 } ?? false } ?? false,
                          referenceAverage: reference)
    }
    private static func measurements(_ samples: [HeartRateSample]) -> (average: Double?, maximum: Double?, seconds: TimeInterval) {
        let sorted = samples.filter { $0.bpm.isFinite && $0.bpm > 0 }.sorted { $0.date < $1.date }
        guard sorted.count >= 6 else { return (nil, nil, 0) }
        var seconds = 0.0, weighted = 0.0
        for (first, second) in zip(sorted, sorted.dropFirst()) {
            let interval = second.date.timeIntervalSince(first.date)
            guard interval > 0 && interval <= 30 else { continue }
            seconds += interval; weighted += (first.bpm + second.bpm) / 2 * interval
        }
        guard seconds >= 60 else { return (nil, nil, seconds) }
        return (weighted / seconds, sorted.map(\.bpm).max(), seconds)
    }
}

public enum DailyActivity {
    public static func walkingMinutes(_ workouts: [ExternalWorkout], now: Date = Date(), calendar: Calendar = .current) -> Int {
        var seen = Set<UUID>()
        return Int(workouts.filter { seen.insert($0.id).inserted && $0.kind == "walking" && $0.endedAt <= now && calendar.isDate($0.startedAt, inSameDayAs: now) }.reduce(0) { $0 + max(0, $1.duration) } / 60)
    }
    public static func adapt(_ plan: WorkoutPlan, workouts: [ExternalWorkout], now: Date = Date()) -> WorkoutPlan {
        guard walkingMinutes(workouts, now: now) >= 10 else { return plan }
        var result = plan
        // Recovery walks remain recovery. A completed walk is never replaced with harder work.
        if !plan.isLight {
            result.exercises = plan.exercises.map { item in
                guard item.exercise.id == "walk" else { return item }
                return ExercisePlan(id: item.id, exercise: ExerciseLibrary.named("mobility"), repetitions: nil, durationSeconds: 120, restSeconds: 0)
            }
        }
        return result
    }
    public static func returnTask(archive: AppArchive, now: Date = Date()) -> String {
        let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: now) ?? now
        guard TrainingCalendar.status(on: yesterday, archive: archive, now: now) == .missed else {
            return "Занимайтесь по плану и отмечайте восстановление."
        }
        return "Задача возвращения: выберите время следующего занятия и отметьте причину пропуска. Пропущенные подходы не прибавляются к нагрузке."
    }
}
