"""Optional Windows source/config checks. NOT Swift typechecking or compilation.

Install once: python -m pip install tree-sitter tree-sitter-swift pyyaml
Run: python scripts/check_sources.py
"""
from pathlib import Path
import plistlib
import sys
import xml.etree.ElementTree as ET
from tree_sitter import Language, Parser
import tree_sitter_swift
import yaml

root = Path(__file__).resolve().parents[1]
parser = Parser(Language(tree_sitter_swift.language()))
errors = []
swift_files = [root / 'Package.swift']
for directory in ['Shared', 'Platform', 'UIShared', 'iOS', 'Watch', 'Tests', 'UITests']:
    swift_files.extend(sorted((root / directory).rglob('*.swift')))
for file in swift_files:
    if '.build' in file.parts:
        continue
    tree = parser.parse(file.read_bytes())
    stack = [tree.root_node]
    while stack:
        node = stack.pop()
        if node.type == 'ERROR' or node.is_missing:
            errors.append(f'{file.relative_to(root)}:{node.start_point.row+1}: {node.type}')
        stack.extend(node.children)
for file in list((root / 'Config').glob('*.plist')) + list((root / 'Config').glob('*.entitlements')):
    plistlib.loads(file.read_bytes())
for file in (root / 'FitAICoach.xcodeproj').rglob('*.xcscheme'):
    ET.parse(file)
spec = yaml.safe_load((root / 'project.yml').read_text(encoding='utf-8'))
assert set(spec['targets']) == {'FitAICoach', 'FitAICoachWatch', 'FitAICoachScreenshots'}
for file in (root / '.github/workflows').glob('*.yml'):
    yaml.safe_load(file.read_text(encoding='utf-8'))
workflow = yaml.safe_load((root / '.github/workflows/apple-build.yml').read_text(encoding='utf-8'))
assert workflow['jobs']['build']['runs-on'] in ('macos-15', 'macos-15-intel')
if errors:
    print('\n'.join(errors))
    sys.exit(1)
print(f'PASS: syntax parse of {len(swift_files)} Swift sources, YAML, plist, entitlements, scheme XML.')
print('This does NOT check Swift types, Apple API availability, linking, signing, or runtime behavior.')
