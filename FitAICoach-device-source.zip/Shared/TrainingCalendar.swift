import Foundation

public enum TrainingDay: String, Sendable { case trained, missed, pending, future, unknown }
public enum TrainingCalendar {
    public static func status(on day: Date, archive: AppArchive, now: Date = Date(), calendar: Calendar = .current) -> TrainingDay {
        let date = calendar.startOfDay(for: day), today = calendar.startOfDay(for: now)
        if date > today { return .future }
        if archive.history.contains(where: { $0.endedAt != nil && $0.duration > 0 && calendar.isDate($0.startedAt, inSameDayAs: date) }) ||
            (archive.externalWorkouts ?? []).contains(where: { $0.endedAt <= now && $0.duration > 0 && calendar.isDate($0.startedAt, inSameDayAs: date) }) ||
            archive.calendar.contains(where: { [.completed, .light].contains($0.status) && calendar.isDate($0.date, inSameDayAs: date) }) { return .trained }
        if date == today { return .pending }
        let starts = archive.history.map(\.startedAt) + archive.calendar.map(\.date) + (archive.externalWorkouts ?? []).map(\.startedAt)
        guard let start = starts.min(), date >= calendar.startOfDay(for: start) else { return .unknown }
        return .missed
    }
    public static func reconcile(_ archive: inout AppArchive, now: Date = Date(), calendar: Calendar = .current) {
        let dates = archive.history.map(\.startedAt) + archive.calendar.map(\.date) + (archive.externalWorkouts ?? []).map(\.startedAt)
        guard let first = dates.min() else { return }
        let today = calendar.startOfDay(for: now)
        var day = calendar.startOfDay(for: first)
        while day < today {
            if status(on: day, archive: archive, now: now, calendar: calendar) == .missed {
                if let index = archive.calendar.firstIndex(where: { calendar.isDate($0.date, inSameDayAs: day) }) { archive.calendar[index].status = .missed }
                else { archive.calendar.append(CalendarEntry(date: day, status: .missed, reason: "Автоматически: в этот день нет записанной тренировки")) }
            }
            guard let next = calendar.date(byAdding: .day, value: 1, to: day) else { break }; day = next
        }
    }
}

public struct ControlSchedule: Codable, Equatable, Sendable {
    public var nextDate: Date
    public var intervalDays: Int
    public init(nextDate: Date, intervalDays: Int = 7) { self.nextDate=nextDate; self.intervalDays=max(7, intervalDays) }
    public static func initial(archive: AppArchive, now: Date = Date()) -> ControlSchedule {
        let anchor = archive.testResults.map(\.date).max() ?? archive.history.map(\.startedAt).min() ?? now
        return ControlSchedule(nextDate: Calendar.current.date(byAdding: .day, value: 7, to: anchor) ?? now)
    }
    public func isScheduled(_ date: Date, calendar: Calendar = .current) -> Bool {
        let days = calendar.dateComponents([.day], from: calendar.startOfDay(for: nextDate), to: calendar.startOfDay(for: date)).day ?? -1
        return days >= 0 && days % max(7, intervalDays) == 0
    }
}

public enum DailyPlans {
    public static func index(on day: Date, calendar: Calendar = .current) -> Int {
        let anchor = calendar.date(from: DateComponents(year: 2020, month: 1, day: 1))!
        let days = calendar.dateComponents([.day], from: anchor, to: calendar.startOfDay(for: day)).day ?? 0
        return (days % 3 + 3) % 3
    }
    private static func reps(_ id: String, _ count: Int, sets: Int = 2) -> ExercisePlan {
        ExercisePlan(exercise: ExerciseLibrary.named(id), repetitions: count, sets: sets, restSeconds: 45)
    }
    private static func timed(_ id: String, _ seconds: Int) -> ExercisePlan {
        ExercisePlan(exercise: ExerciseLibrary.named(id), repetitions: nil, durationSeconds: seconds, restSeconds: 30)
    }
    public static func strength(on day: Date) -> WorkoutPlan {
        let variant = index(on: day)
        if variant == 0 { var plan = SeedData.defaultPlan(); plan.name = "Комплекс А · Базовая сила"; return plan }
        let main: [ExercisePlan] = variant == 1 ? [reps("pushups", 8), reps("reverseLunge", 8), reps("deadBug", 8), reps("bridge", 12), timed("walk", 240)] :
            [reps("squats", 12), reps("birdDog", 8), timed("plank", 25), reps("reverseCrunch", 8), reps("superman", 6), timed("walk", 240)]
        return WorkoutPlan(name: variant == 1 ? "Комплекс Б · Контроль движений" : "Комплекс В · Ноги и корпус", exercises: ExerciseLibrary.warmupSteps() + main + ExerciseLibrary.cooldownSteps())
    }
    public static func recovery(on day: Date, minutes: Int) -> WorkoutPlan {
        let variant = index(on: day)
        // A target session length must not turn one recovery exercise into filler.
        let walkingSeconds = min(300, max(180, minutes * 10))
        let main: [ExercisePlan]
        switch variant {
        case 0: main = [timed("walk", walkingSeconds), timed("mobility", 120)]
        case 1: main = [timed("mobility", 120), reps("birdDog", 6, sets: 1), timed("walk", walkingSeconds)]
        default: main = [timed("walk", walkingSeconds), reps("deadBug", 6, sets: 1), timed("mobility", 120)]
        }
        return WorkoutPlan(name: "Восстановление \(["А", "Б", "В"][variant]) · Спокойное движение", targetMinutes: minutes,
                           exercises: ExerciseLibrary.warmupSteps() + main + ExerciseLibrary.cooldownSteps(), isLight: true)
    }
}
