import SwiftUI
import Charts

@main struct FitAICoachApp: App {
    @StateObject private var model = AppModel()
    var body: some Scene {
        WindowGroup {
            PhoneRoot().environmentObject(model).preferredColorScheme(.dark).tint(.fitAccent)
        }
    }
}
struct PhoneRoot: View {
    @EnvironmentObject var model: AppModel
    @Environment(\.scenePhase) private var scenePhase
    @State private var selectedTab = 0
    var body: some View {
        TabView(selection: $selectedTab) {
            NavigationStack { HomeView() }.tabItem { Label("Главная", systemImage: "house.fill") }.tag(0)
            NavigationStack { PhoneWorkoutView() }.tabItem { Label("Тренировка", systemImage: "figure.strengthtraining.traditional") }.tag(1)
            NavigationStack { ProgressViewScreen() }.tabItem { Label("Прогресс", systemImage: "chart.xyaxis.line") }.tag(2)
            NavigationStack { CalendarViewScreen() }.tabItem { Label("Календарь", systemImage: "calendar") }.tag(3)
            NavigationStack { CoachChatView() }.tabItem { Label("AI COACH", systemImage: "bubble.left.fill") }.tag(4)
            NavigationStack { SettingsView() }.tabItem { Label("Настройки", systemImage: "gearshape.fill") }.tag(5)
        }
        .onChange(of: model.engine?.record.id) { _, _ in if let engine = model.engine, engine.state != .finished { selectedTab = 1 } }
        .onChange(of: scenePhase) { _, phase in if phase == .active { model.refreshDay() } }
        .onReceive(NotificationCenter.default.publisher(for: .NSCalendarDayChanged)) { _ in model.refreshDay() }
        .alert("FitAI Coach", isPresented: Binding(get: { !model.message.isEmpty }, set: { if !$0 { model.message = "" } })) {
            Button("Понятно") { model.message = "" }
        } message: { Text(model.message) }
    }
}
struct HomeView: View {
    @EnvironmentObject var model: AppModel
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("ТВОЯ ЦЕЛЬ.\nТВОЯ РАБОТА.").font(.largeTitle.bold())
                FitCard {
                    let weekStart = Calendar.current.date(byAdding: .day, value: -6, to: Calendar.current.startOfDay(for: Date()))!
                    let activeDays = Set(model.archive.calendar.filter { $0.status != .missed && $0.date >= weekStart && $0.date <= Date() }.map { Calendar.current.startOfDay(for: $0.date) }).count
                    HStack(spacing: 20) {
                        ZStack {
                            Circle().stroke(Color.fitAccent.opacity(0.15), lineWidth: 10)
                            Circle().trim(from: 0, to: min(1, Double(activeDays) / 7)).stroke(Color.fitAccent, style: StrokeStyle(lineWidth: 10, lineCap: .round)).rotationEffect(.degrees(-90))
                            Text("\(activeDays)/7").font(.title2.bold())
                        }.frame(width: 86, height: 86).padding(6).accessibilityLabel("Дней активности или запланированного отдыха за неделю: \(activeDays) из семи")
                        VStack(alignment: .leading) { Text("Регулярность").font(.headline); Text("Тренировки, облегчённые дни и запланированный отдых за последние 7 дней.").font(.caption).foregroundStyle(.secondary) }
                    }
                }
                FitCard {
                    Text("СЕГОДНЯ").font(.caption.bold()).foregroundStyle(Color.fitAccent)
                    Text(model.archive.plan.name).font(.title2.bold())
                    HStack { Metric(title: "План", value: "\(model.archive.plan.targetMinutes) мин", symbol: "clock"); Metric(title: "Подходы", value: "\(model.archive.plan.exercises.reduce(0) { $0 + $1.sets })", symbol: "repeat") }
                    Text("Длительность — ориентир. Не ускоряйте технику ради таймера.").font(.caption).foregroundStyle(.secondary)
                    Button(model.busy ? "Запускаем часы…" : "Начать на Apple Watch") { Task { await model.start() } }.buttonStyle(.borderedProminent).foregroundStyle(.black).disabled(model.busy)
                    if !model.controlStatus.isEmpty { Text(model.controlStatus).font(.caption).foregroundStyle(.secondary) }
                }
                FitCard {
                    Text("Нагрузка по измерениям").font(.headline)
                    Text(model.sensorSummary).font(.subheadline)
                    Toggle("Указать продолжительность сна", isOn: $model.useSleep)
                    if model.useSleep { Stepper("Сон: \(model.sleepHours, specifier: "%.1f") ч", value: $model.sleepHours, in: 0...14, step: 0.5) }
                    Button("Адаптировать план") { model.preparePlan() }.buttonStyle(.bordered)
                    Text("Локальный тренер на основе правил. При боли прекратите нагрузку.").font(.caption).foregroundStyle(.secondary)
                }
                NavigationLink { PlanEditor() } label: { Label("Программа и техника упражнений", systemImage: "list.bullet.clipboard") }.buttonStyle(.bordered)
                NavigationLink { ControlTestsScreen() } label: { Label("Контрольные тесты", systemImage: "flag.checkered") }.buttonStyle(.bordered)
                FitCard {
                    Text("РАЗМИНКА · ОКОЛО 5 МИНУТ").font(.headline)
                    ForEach(model.archive.plan.exercises.filter { $0.exercise.id.hasPrefix("warmup") }) { step in
                        HStack(alignment: .top) {
                            Text(step.exercise.name.replacingOccurrences(of: "Разминка · ", with: ""))
                            Spacer()
                            Text(step.durationSeconds.map { "\($0) сек" } ?? "\(step.repetitions ?? 0) раз").foregroundStyle(.secondary)
                        }.font(.subheadline)
                    }
                    Text("У каждого шага свой таймер или счёт повторений. Переходите дальше кнопкой «Закончил» на часах.").font(.caption).foregroundStyle(.secondary)
                }
                FitCard {
                    Text("Задача на регулярность").font(.headline)
                    Text(DailyActivity.returnTask(archive: model.archive))
                    Text("Связь: \(model.connectivity.status)").font(.caption).foregroundStyle(.secondary)
                }
                FitCard {
                    Text("ЗАМИНКА · 3 МИНУТЫ").font(.headline)
                    ForEach(model.archive.plan.exercises.filter { $0.exercise.id.hasPrefix("cooldown") }) { step in
                        HStack { Text(step.exercise.name.replacingOccurrences(of: "Заминка · ", with: "")); Spacer(); Text("\(step.durationSeconds ?? 0) сек").foregroundStyle(.secondary) }.font(.subheadline)
                    }
                }
                FitCard {
                    Text("Активность из Apple Health").font(.headline)
                    Text(model.activityStatus).font(.caption)
                    Button("Учесть сегодняшние тренировки") { Task { await model.refreshActivities(); model.preparePlan() } }
                    Text("Если сегодня уже есть не менее 10 минут ходьбы, ходьба основного плана заменяется мягкой подвижностью. Восстановительный день не усиливается.").font(.caption).foregroundStyle(.secondary)
                }
            }.padding()
        }.navigationTitle("FITAI COACH")
    }
}
struct PhoneWorkoutView: View {
    @EnvironmentObject var model: AppModel
    @State private var confirmDiscard = false
    @State private var actualRepetitions = 8
    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                if let engine = model.engine {
                    TimelineView(.periodic(from: .now, by: 1)) { context in
                        FitCard {
                            Text(phaseLabel(engine.state)).font(.caption.bold()).foregroundStyle(Color.fitAccent)
                            Text(engine.currentExercise?.exercise.name ?? "Тренировка завершена").font(.largeTitle.bold())
                            HStack { Metric(title: "Время", value: clockString(engine.elapsed(at: context.date)), symbol: "clock"); Metric(title: "Пульс", value: model.currentHeartRate, symbol: "heart.fill") }
                            if engine.state == .rest { Text("Отдых: \(clockString(engine.restRemaining(at: context.date)))").font(.title2) }
                            if engine.state == .exercise, let target = engine.currentExercise?.durationSeconds {
                                Text("Осталось: \(clockString(Int(ceil(max(0, Double(target) - engine.phaseElapsed(at: context.date))))))").font(.title2).monospacedDigit()
                            }
                            Text("Выполнено подходов: \(engine.record.exercises.count)")
                            if engine.state != .finished {
                            if engine.state == .ready {
                                Button("Начать упражнение") { model.beginExercise() }.buttonStyle(.borderedProminent)
                            }
                            if engine.state == .exercise {
                                if engine.currentExercise?.repetitions != nil { Stepper("Сделано: \(actualRepetitions)", value: $actualRepetitions, in: 0...200) }
                                if let kind = engine.record.controlTestKind { Text(kind.protocolDescription).font(.caption); Text("Время теста: \(clockString(engine.phaseElapsed(at: context.date)))").monospacedDigit() }
                                Button(engine.record.controlTestKind == nil ? "Закончить упражнение" : "Завершить тест") { model.complete(reps: engine.currentExercise?.repetitions == nil ? nil : actualRepetitions) }.buttonStyle(.borderedProminent)
                            }
                            if engine.state == .rest {
                                Text("Далее: \(engine.nextExercise?.exercise.name ?? "Завершение")")
                                Button("Начать следующее упражнение") { model.next() }.buttonStyle(.borderedProminent)
                                Button("+30 секунд отдыха") { model.extendRest() }
                            }
                            HStack {
                                Button(engine.state == .paused ? "Продолжить" : "Пауза") { engine.state == .paused ? model.resume() : model.pause() }.buttonStyle(.bordered)
                                Button(engine.record.controlTestKind == nil ? "Завершить тренировку" : "Прервать тест", role: .destructive) { Task { await model.stop() } }.buttonStyle(.bordered)
                            }
                            Button("Отменить без сохранения", role: .destructive) { confirmDiscard = true }.disabled(model.busy)
                            } else {
                                NavigationLink("Посмотреть результаты") { WorkoutDetail(record: engine.record) }
                            }
                        }
                    }
                    Text(model.controlStatus).font(.caption).foregroundStyle(.secondary)
                    Text("Можно управлять с телефона и часов. При отсутствии связи команды ожидают доставки. Старое завершение упражнения не применяется к следующему подходу.").font(.caption).foregroundStyle(.secondary)
                    FitCard { Text("Нагрузка по пульсу").font(.headline); Text(model.sensorSummary).font(.caption) }
                    HeartChart(samples: engine.record.heartRate)
                    ForEach(engine.record.exercises) { ExerciseRecordRow(record: $0) }
                } else {
                    EmptyState(title: "Часы готовы к работе", detail: "Начните тренировку на Apple Watch. После синхронизации здесь появятся подходы и пульс.")
                }
                Text(model.health.status).font(.caption).foregroundStyle(.secondary)
            }.padding()
        }.navigationTitle("Тренировка")
        .onAppear { actualRepetitions = model.engine?.currentExercise?.repetitions ?? 8 }
        .onChange(of: model.engine?.currentExercise?.id) { _, _ in actualRepetitions = model.engine?.currentExercise?.repetitions ?? 8 }
        .onChange(of: model.engine?.setNumber) { _, _ in actualRepetitions = model.engine?.currentExercise?.repetitions ?? 8 }
        .confirmationDialog("Отменить случайную тренировку?", isPresented: $confirmDiscard, titleVisibility: .visible) {
            Button("Отменить без сохранения", role: .destructive) { model.discardWorkout() }
            Button("Продолжить тренировку", role: .cancel) {}
        } message: { Text("Команда будет отправлена на часы. Тренировка завершится без записи в историю FitAI Coach и без сохранения тренировки в Apple Health.") }
    }
}
func phaseLabel(_ phase: WorkoutPhase) -> String {
    switch phase { case .ready: return "ГОТОВНОСТЬ"; case .exercise: return "УПРАЖНЕНИЕ"; case .rest: return "ОТДЫХ"; case .paused: return "ПАУЗА"; case .finished: return "РЕЗУЛЬТАТ" }
}
struct HeartChart: View {
    var samples: [HeartRateSample]
    var body: some View {
        FitCard {
            Text("Пульс · реальные измерения").font(.headline)
            if samples.isEmpty { Text("Нет данных. Доступ к чтению или измерения могут отсутствовать.").foregroundStyle(.secondary) }
            else {
                Chart(samples) { sample in LineMark(x: .value("Время", sample.date), y: .value("уд/мин", sample.bpm)).foregroundStyle(.pink) }.frame(height: 160)
                let stats = HeartRateStatistics(samples: samples)
                Text("Средний: \(stats.average.map { String(Int($0)) } ?? "Нет данных") · Максимум: \(stats.maximum.map { String(Int($0)) } ?? "Нет данных")").font(.caption)
            }
        }
    }
}
struct ExerciseRecordRow: View {
    var record: ExerciseRecord
    var body: some View {
        FitCard {
            Text("\(record.exercise.name) · подход \(record.setNumber)").font(.headline)
            Text(record.skipped ? "Пропущено" : "\(record.actualRepetitions.map(String.init) ?? "—") повторений · \(clockString(record.duration))")
            Text("План: \(record.plannedRepetitions.map(String.init) ?? "по времени") · \(record.startedAt.formatted(date: .omitted, time: .shortened))–\(record.endedAt.formatted(date: .omitted, time: .shortened))").font(.caption)
            Text("Пульс: средний \(record.statistics.average.map { String(Int($0)) } ?? "Нет данных"), максимум \(record.statistics.maximum.map { String(Int($0)) } ?? "Нет данных")").font(.caption).foregroundStyle(.secondary)
        }
    }
}
struct PlanEditor: View {
    @EnvironmentObject var model: AppModel
    @State private var showLibrary = false
    @State private var customName = ""
    var body: some View {
        List {
            Section("Программа") {
                Stepper("Ориентир: \(model.archive.plan.targetMinutes) мин", value: $model.archive.plan.targetMinutes, in: 5...90, step: 5)
                Text("Порядок и объём меняют следующую тренировку. Текущая сессия сохраняет начальный план.").font(.caption)
            }
            Section("Упражнения") {
                ForEach($model.archive.plan.exercises) { $item in
                    NavigationLink { ExerciseEditor(item: $item) } label: {
                        VStack(alignment: .leading) { Text(item.exercise.name); Text("\(item.sets) подх. · \(item.durationSeconds.map { "\($0) сек" } ?? "\(item.repetitions ?? 0) повт.") · отдых \(item.restSeconds) сек").font(.caption).foregroundStyle(.secondary) }
                    }
                }.onDelete { model.archive.plan.exercises.remove(atOffsets: $0) }.onMove { model.archive.plan.exercises.move(fromOffsets: $0, toOffset: $1) }
            }
            Section("Добавить") {
                Button("Из библиотеки") { showLibrary = true }
                TextField("Название своего упражнения", text: $customName)
                Button("Добавить своё") {
                    let name = customName.trimmingCharacters(in: .whitespacesAndNewlines)
                    guard !name.isEmpty else { return }
                    model.archive.plan.exercises.append(ExercisePlan(exercise: Exercise(name: name))); customName = ""
                }.disabled(customName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }.navigationTitle("Программа").toolbar { EditButton() }
        .onDisappear { model.changed() }
        .onChange(of: model.archive.plan) { _, _ in model.changed() }
        .sheet(isPresented: $showLibrary) {
            NavigationStack { List(ExerciseLibrary.all) { exercise in
                Button(exercise.name) { model.archive.plan.exercises.append(ExercisePlan(exercise: exercise)); showLibrary = false; model.changed() }
            }.navigationTitle("Библиотека").toolbar { Button("Закрыть") { showLibrary = false } } }
        }
    }
}
struct ExerciseEditor: View {
    @Binding var item: ExercisePlan
    var body: some View {
        Form {
            Section("Объём") {
                Toggle("По времени", isOn: Binding(get: { item.durationSeconds != nil }, set: { item.durationSeconds = $0 ? 30 : nil; item.repetitions = $0 ? nil : 8 }))
                if item.durationSeconds != nil { Stepper("Время: \(item.durationSeconds ?? 30) сек", value: Binding(get: { item.durationSeconds ?? 30 }, set: { item.durationSeconds = $0 }), in: 5...600, step: 5) }
                else { Stepper("Повторения: \(item.repetitions ?? 8)", value: Binding(get: { item.repetitions ?? 8 }, set: { item.repetitions = $0 }), in: 1...100) }
                Stepper("Подходы: \(item.sets)", value: $item.sets, in: 1...10)
                Stepper("Отдых: \(item.restSeconds) сек", value: $item.restSeconds, in: 0...300, step: 15)
            }
            Section("Техника") { TextField("Описание", text: $item.exercise.technique, axis: .vertical); Text("Мышцы: " + item.exercise.muscles.joined(separator: ", ")) }
            Section("Частые ошибки") { TextField("Ошибки", text: $item.exercise.mistakes, axis: .vertical) }
            Section("Упрощённый вариант") { TextField("Вариант", text: $item.exercise.easierVariant, axis: .vertical) }
        }.navigationTitle(item.exercise.name)
    }
}
