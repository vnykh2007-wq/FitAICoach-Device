import SwiftUI

struct ControlTestPicker: View {
    @EnvironmentObject var model: AppModel
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                Section("Какой контрольный тест хотите сдать?") {
                    ForEach(FitnessTestKind.allCases, id: \.self) { kind in
                        Button {
                            dismiss(); Task { await model.start(controlTest: kind) }
                        } label: {
                            VStack(alignment: .leading, spacing: 6) { Text(kind.title).font(.headline); Text(kind.protocolDescription).font(.caption).foregroundStyle(.secondary) }
                        }.disabled(model.busy || (model.engine != nil && model.engine?.state != .finished))
                    }
                }
                Section { Text("Перед тестом разомнитесь. Часы считают время и пульс; повторения вводятся вручную. Для планки и баланса слева/справа сохраняются отдельные результаты. Бёрпи — дополнительный вариант, выполнять его не обязательно.").font(.caption) }
            }.navigationTitle("Выбор теста").toolbar { Button("Закрыть") { dismiss() } }
        }
    }
}

struct ControlTestsScreen: View {
    @EnvironmentObject var model: AppModel
    @State private var showPicker = false
    private var schedule: ControlSchedule { model.archive.controlSchedule ?? ControlSchedule.initial(archive: model.archive) }
    var body: some View {
        List {
            Section("Сдать контрольный тест") {
                Button("Начать контрольный тест") { showPicker = true }.disabled(model.busy || (model.engine != nil && model.engine?.state != .finished))
                Text("Выберите упражнение — оно запустится на Apple Watch. Завершить и записать результат можно с часов или телефона.").font(.caption)
            }
            Section("Контрольные дни") {
                DatePicker("Следующий день", selection: Binding(get: { schedule.nextDate }, set: { date in var value = schedule; value.nextDate = date; model.archive.controlSchedule = value; model.changed() }), displayedComponents: .date)
                Picker("Повторять", selection: Binding(get: { schedule.intervalDays }, set: { days in var value = schedule; value.intervalDays = days; model.archive.controlSchedule = value; model.changed() })) {
                    Text("Раз в 7 дней").tag(7); Text("Раз в 14 дней").tag(14); Text("Раз в 28 дней").tag(28)
                }
                Text("Контрольные дни отмечены флажком в календаре. После завершённого теста следующий день переносится на выбранный интервал. Не обязательно сдавать все упражнения за одно занятие.").font(.caption)
            }
            Section("Результаты") {
                ForEach(model.archive.testResults.sorted { $0.date > $1.date }) { test in
                    VStack(alignment: .leading) { Text(test.kind.title); Text("\(test.date.formatted(date: .abbreviated, time: .shortened)) · \(test.value) \(test.kind.unit)").font(.caption).foregroundStyle(.secondary) }
                }
                if model.archive.testResults.isEmpty { Text("Пока нет завершённых тестов") }
            }
        }.navigationTitle("Контрольные тесты").sheet(isPresented: $showPicker) { ControlTestPicker().environmentObject(model) }
    }
}
