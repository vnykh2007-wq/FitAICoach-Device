import Foundation

public struct WorkoutLaunchRequest: Codable, Sendable {
    public var id: UUID
    public var kind: FitnessTestKind?
    public var issuedAt: Date
    public init(kind: FitnessTestKind?, now: Date = Date()) { self.id=UUID(); self.kind=kind; self.issuedAt=now }
    public func isFresh(now: Date = Date()) -> Bool { abs(now.timeIntervalSince(issuedAt)) < 180 }
}

extension FitnessTestKind {
    public var title: String {
        switch self {
        case .pushups: return "Отжимания"
        case .plank: return "Планка"
        case .squats: return "Приседания за минуту"
        case .crunch: return "Скручивания за минуту"
        case .wallSit: return "Стульчик у стены"
        case .sidePlankLeft: return "Боковая планка · левая"
        case .sidePlankRight: return "Боковая планка · правая"
        case .burpees: return "Бёрпи за минуту"
        case .balanceLeft: return "Баланс · левая нога"
        case .balanceRight: return "Баланс · правая нога"
        }
    }
    public var countsRepetitions: Bool { [.pushups, .squats, .crunch, .burpees].contains(self) }
    public var timedMinute: Bool { [.squats, .crunch, .burpees].contains(self) }
    public var unit: String { countsRepetitions ? "повт." : "сек" }
    public var protocolDescription: String {
        if timedMinute { return "Повторения за 60 секунд. Считайте повторения вручную; после сигнала укажите число и завершите тест." }
        return countsRepetitions ? "Выполните доступное число технически правильных повторений. Укажите число и завершите тест." : "Таймер считает время удержания. Завершите тест, когда перестаёте сохранять положение."
    }
    public func plan() -> WorkoutPlan {
        let exerciseID: String
        switch self {
        case .pushups: exerciseID = "pushups"
        case .plank: exerciseID = "plank"
        case .squats: exerciseID = "squats"
        case .crunch: exerciseID = "crunch"
        case .wallSit: exerciseID = "wallSit"
        case .sidePlankLeft: exerciseID = "sidePlankLeft"
        case .sidePlankRight: exerciseID = "sidePlankRight"
        case .burpees: exerciseID = "burpees"
        case .balanceLeft: exerciseID = "balanceLeft"
        case .balanceRight: exerciseID = "balanceRight"
        }
        var plan = WorkoutPlan(name: "Контрольный тест · " + title, exercises: [ExercisePlan(exercise: ExerciseLibrary.named(exerciseID), repetitions: countsRepetitions ? 0 : nil, durationSeconds: timedMinute ? 60 : nil, restSeconds: 0)])
        plan.controlTestKind = self; return plan
    }
}
public enum ControlTests {
    public static func result(from record: WorkoutRecord) -> FitnessTestRecord? {
        guard let kind = record.controlTestKind, record.endedAt != nil, !record.interrupted,
              let exercise = record.exercises.first, !exercise.skipped else { return nil }
        if kind.timedMinute && exercise.duration < 60 { return nil }
        let value: Int
        if kind.countsRepetitions { guard let repetitions = exercise.actualRepetitions else { return nil }; value = repetitions }
        else { value = Int(exercise.duration) }
        return FitnessTestRecord(id: record.id, date: record.startedAt, kind: kind, value: value, note: "Отдельная тестовая сессия с таймером Apple Watch; повторения введены вручную, если применимо")
    }
}
