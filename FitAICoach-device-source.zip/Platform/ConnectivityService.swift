import Foundation
import Combine
import WatchConnectivity

/// Watch owns workout state. Commands travel phone -> watch; snapshots travel watch -> phone.
/// WCSession queues survive disconnection; our outbox survives app termination until explicit ACK.
final class ConnectivityService: NSObject, ObservableObject, WCSessionDelegate {
    @Published private(set) var reachable = false
    @Published private(set) var status = "Ожидание соединения"
    @Published private(set) var persistenceError: String?
    var onSnapshot: ((Data) -> Void)? { didSet { deliverSnapshot() } }
    var onCommand: ((RemoteCommand) -> Void)? { didSet { deliverCommands() } }
    var onReconnect: (() -> Void)?
    private let session: WCSession?
    private let url: URL
    private var state: TransportState
    private struct TransportState: Codable {
        var pending: [RemoteCommand] = []
        var inbox: [RemoteCommand] = []
        var received: [UUID] = []
        var snapshot: Data?
        var receivedSnapshot: Data?
    }
    init(directory: URL? = nil) {
        let directory = directory ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        url = directory.appendingPathComponent("connectivity.json")
        state = (try? Data(contentsOf: url)).flatMap { try? JSONDecoder().decode(TransportState.self, from: $0) } ?? TransportState()
        session = WCSession.isSupported() ? .default : nil
        super.init()
        session?.delegate = self
        session?.activate()
    }
    private func persist() {
        do {
            try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            try JSONEncoder().encode(state).write(to: url, options: .atomic)
        } catch { persistenceError = "Не удалось сохранить очередь синхронизации: \(error.localizedDescription)" }
    }
    func sendSnapshot(_ data: Data) {
        state.snapshot = data; persist()
        guard let session, session.activationState == .activated else { return }
        if data.count > 40_000 { sendSnapshotFile(data); return }
        do { try session.updateApplicationContext(["snapshot": data]) }
        catch { status = "Снимок сохранён; отправка при подключении" }
        if session.isReachable { session.sendMessageData(encode(["snapshot": data]), replyHandler: nil, errorHandler: nil) }
    }
    func sendCommand(kind: String, workoutID: UUID, exerciseID: UUID? = nil, setNumber: Int? = nil, expectedPhase: WorkoutPhase? = nil, repetitions: Int? = nil) {
        let command = RemoteCommand(workoutID: workoutID, kind: kind, exerciseID: exerciseID, setNumber: setNumber, expectedPhase: expectedPhase, repetitions: repetitions)
        state.pending.append(command); persist(); transmit(command)
    }
    private func sendSnapshotFile(_ data: Data) {
        guard let session, !session.outstandingFileTransfers.contains(where: { ($0.file.metadata?["kind"] as? String) == "snapshot" }) else { return }
        do {
            let file = url.deletingLastPathComponent().appendingPathComponent("snapshot-\(UUID().uuidString).json")
            try data.write(to: file, options: .atomic)
            session.transferFile(file, metadata: ["kind": "snapshot"])
        } catch { persistenceError = "Не удалось подготовить историю для отправки: \(error.localizedDescription)" }
    }
    func session(_ session: WCSession, didReceive file: WCSessionFile) {
        // WCSession deletes its temporary URL after this delegate returns.
        guard (file.metadata?["kind"] as? String) == "snapshot", let data = try? Data(contentsOf: file.fileURL) else { return }
        DispatchQueue.main.async { self.receive(["snapshot": data]) }
    }
    func session(_ session: WCSession, didFinish fileTransfer: WCSessionFileTransfer, error: Error?) {
        let delivered = try? Data(contentsOf: fileTransfer.file.fileURL)
        try? FileManager.default.removeItem(at: fileTransfer.file.fileURL)
        DispatchQueue.main.async {
            if error == nil, let latest = self.state.snapshot, latest != delivered, latest.count > 40_000 { self.sendSnapshotFile(latest) }
            else if let error { self.status = "История сохранена; повторная отправка при подключении: \(error.localizedDescription)" }
        }
    }
    private func encode(_ dictionary: [String: Any]) -> Data {
        (try? PropertyListSerialization.data(fromPropertyList: dictionary, format: .binary, options: 0)) ?? Data()
    }
    private func transmit(_ command: RemoteCommand) {
        guard let session, session.activationState == .activated,
              let data = try? JSONEncoder().encode(command) else { return }
        let envelope: [String: Any] = ["command": data]
        // Avoid adding identical queued transfers each time reachability changes.
        if !session.outstandingUserInfoTransfers.contains(where: { ($0.userInfo["command"] as? Data) == data }) {
            session.transferUserInfo(envelope)
        }
        if session.isReachable {
            session.sendMessage(envelope, replyHandler: { [weak self] reply in
                DispatchQueue.main.async { self?.receive(reply) }
            }, errorHandler: { _ in /* queued userInfo remains authoritative fallback */ })
        }
    }
    private func receive(_ envelope: [String: Any]) {
        if let data = envelope["snapshot"] as? Data {
            state.receivedSnapshot = data; persist(); deliverSnapshot()
        }
        if let value = envelope["ack"] as? String, let id = UUID(uuidString: value) {
            state.pending.removeAll { $0.id == id }; persist()
        }
        if let data = envelope["command"] as? Data,
           let command = try? JSONDecoder().decode(RemoteCommand.self, from: data) {
            if !state.received.contains(command.id) && !state.inbox.contains(where: { $0.id == command.id }) {
                state.inbox.append(command); persist()
            }
            deliverCommands()
            if state.received.contains(command.id) { sendAck(command.id) }
        }
    }
    private func deliverSnapshot() { if let data = state.receivedSnapshot { onSnapshot?(data) } }
    private func deliverCommands() {
        guard let onCommand else { return }
        for command in state.inbox {
            onCommand(command)
            state.received.append(command.id)
            sendAck(command.id)
        }
        state.inbox.removeAll()
        // Deliberately retain IDs so old background transfers can never reapply a command.
        persist()
    }
    private func sendAck(_ id: UUID) {
        guard let session, session.activationState == .activated else { return }
        session.transferUserInfo(["ack": id.uuidString])
    }
    private func refresh() {
        reachable = session?.isReachable ?? false
        status = reachable ? "Устройства подключены" : "Нет связи; данные сохранены локально"
        state.pending.forEach(transmit)
        #if os(watchOS)
        if let data = state.snapshot { sendSnapshot(data) }
        #endif
        onReconnect?()
    }
    func clearLocalData() {
        session?.outstandingUserInfoTransfers.forEach { $0.cancel() }
        session?.outstandingFileTransfers.forEach { transfer in
            transfer.cancel()
            try? FileManager.default.removeItem(at: transfer.file.fileURL)
        }
        let localDirectory = url.deletingLastPathComponent()
        let localFiles = (try? FileManager.default.contentsOfDirectory(at: localDirectory, includingPropertiesForKeys: nil)) ?? []
        for file in localFiles where file.lastPathComponent.hasPrefix("snapshot-") && file.pathExtension == "json" {
            try? FileManager.default.removeItem(at: file)
        }
        state = TransportState(); persist()
        try? session?.updateApplicationContext([:])
    }
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        DispatchQueue.main.async { self.refresh() }
    }
    func sessionReachabilityDidChange(_ session: WCSession) { DispatchQueue.main.async { self.refresh() } }
    func session(_ session: WCSession, didReceiveApplicationContext applicationContext: [String: Any]) {
        DispatchQueue.main.async { self.receive(applicationContext) }
    }
    func session(_ session: WCSession, didReceiveUserInfo userInfo: [String: Any] = [:]) {
        DispatchQueue.main.async { self.receive(userInfo) }
    }
    func session(_ session: WCSession, didReceiveMessage message: [String: Any], replyHandler: @escaping ([String: Any]) -> Void) {
        DispatchQueue.main.async {
            self.receive(message)
            if let data = message["command"] as? Data, let command = try? JSONDecoder().decode(RemoteCommand.self, from: data), self.state.received.contains(command.id) {
                replyHandler(["ack": command.id.uuidString])
            } else { replyHandler([:]) }
        }
    }
    func session(_ session: WCSession, didReceiveMessageData messageData: Data) {
        guard let value = try? PropertyListSerialization.propertyList(from: messageData, options: [], format: nil),
              let envelope = value as? [String: Any] else { return }
        DispatchQueue.main.async { self.receive(envelope) }
    }
    #if os(iOS)
    func sessionDidBecomeInactive(_ session: WCSession) {}
    func sessionDidDeactivate(_ session: WCSession) { session.activate() }
    #endif
}


