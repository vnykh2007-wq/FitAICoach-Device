"""Run real native inference on a synthetic prompt on a macOS build runner."""
from pathlib import Path
import hashlib
import os
import subprocess
import urllib.request
import zipfile

root = Path(__file__).resolve().parents[1]
work = root / 'build/native-coach-smoke'
work.mkdir(parents=True, exist_ok=True)
archive = work / 'llama.zip'
urllib.request.urlretrieve('https://github.com/ggml-org/llama.cpp/releases/download/b11838/llama-b11838-xcframework.zip', archive)
assert hashlib.sha256(archive.read_bytes()).hexdigest() == '37cffab2499d4464defe050486f040c116156df6f840b63c9c44fd004f42807e'
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for entry in bundle.infolist():
        assert (work / entry.filename).resolve().is_relative_to(work.resolve())
    bundle.extractall(work)
framework = work / 'build-apple/llama.xcframework/macos-arm64_x86_64'
(work / 'Runtime.swift').write_text((root / 'iOS/LocalCoachRuntime.swift').read_text().replace('import NativeLlama', 'import llama'))
(work / 'Main.swift').write_text('''
import Foundation
@main struct NativeCoachSmoke {
    static func main() async throws {
        if !LocalCoachRuntime.hasModel { try await LocalCoachRuntime.shared.download() }
        let prompt = "<|im_start|>system\\nAnswer briefly in Russian. /no_think<|im_end|>\\n<|im_start|>user\\nСколько секунд в пяти минутах? Ответь одним числом.<|im_end|>\\n<|im_start|>assistant\\n<think>\\n\\n</think>\\n\\n"
        let answer = try await LocalCoachRuntime.shared.generate(prompt: prompt, maxTokens: 96)
        guard answer.contains("300") else { throw LocalCoachError.inferenceFailed }
        print("PASS: verified model download, actual token inference on a synthetic prompt; answer contains 300. No workout data used.")
    }
}
''')
binary = work / 'coach-smoke'
subprocess.run(['xcrun', 'swiftc', '-swift-version', '5', '-O', '-parse-as-library', '-F', str(framework), '-framework', 'llama', str(work / 'Runtime.swift'), str(work / 'Main.swift'), '-o', str(binary)], check=True)
env = dict(os.environ, DYLD_FRAMEWORK_PATH=str(framework))
subprocess.run([str(binary)], env=env, check=True, timeout=900)
