// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "LocalInference",
    platforms: [.iOS(.v17)],
    products: [.library(name: "NativeLlama", targets: ["NativeLlama"])],
    targets: [
        .target(name: "NativeLlama", dependencies: ["llama"]),
        .binaryTarget(name: "llama", url: "https://github.com/ggml-org/llama.cpp/releases/download/b11838/llama-b11838-xcframework.zip", checksum: "37cffab2499d4464defe050486f040c116156df6f840b63c9c44fd004f42807e")
    ]
)
