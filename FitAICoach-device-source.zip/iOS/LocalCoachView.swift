import SwiftUI

@MainActor
final class LocalCoachController: ObservableObject {
    @Published var ready = LocalCoachRuntime.hasModel
    @Published var busy = false
    @Published var status = ""
    @Published var proposal: WorkoutPlan?
    private var task: Task<Void, Never>?
    func cancel() { task?.cancel() }
    func download() {
        guard !busy else { return }; busy = true; status = "Скачивание 640 МБ по Wi-Fi, затем проверка файла…"
        task = Task {
            defer { busy = false; task = nil; ready = LocalCoachRuntime.hasModel }
            do { try await LocalCoachRuntime.shared.download(); status = "Модель готова. Ответы формируются на этом iPhone." }
            catch is CancellationError { status = "Скачивание отменено." }
            catch { status = error.localizedDescription }
        }
    }
    func ask(prompt: String, tokens: Int, completion: @escaping (String) throws -> Void) {
        guard !busy else { return }; busy = true; status = "Тренер думает на iPhone…"; proposal = nil
        task = Task {
            defer { busy = false; task = nil }
            do {
                let answer = try await LocalCoachRuntime.shared.generate(prompt: prompt, maxTokens: tokens)
                try Task.checkCancellation(); try completion(answer); status = ""
            } catch is CancellationError { status = "Ответ остановлен." }
            catch { status = error.localizedDescription }
        }
    }
}

struct CoachChatView: View {
    @EnvironmentObject var model: AppModel
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var coach = LocalCoachController()
    @State private var messages: [ChatMessage] = []
    @State private var text = ""
    private let store = JSONStore()
    private var training: Bool { model.engine != nil && model.engine?.state != .finished }
    var body: some View {
        VStack(spacing: 10) {
            Text("Локальная нейросеть Qwen · работает на iPhone").font(.caption).foregroundStyle(.secondary)
            if !coach.ready {
                Text("Один раз скачайте 640 МБ по Wi-Fi. Без подписки, API и включённого ПК. Сообщения и данные тренировок не отправляются на сервер модели.").font(.caption).padding(.horizontal)
                Button("Скачать модель тренера") { coach.download() }.disabled(coach.busy)
                Link("Модель Qwen · лицензия Apache 2.0", destination: URL(string: "https://huggingface.co/Qwen/Qwen3-0.6B-GGUF")!).font(.caption)
            }
            if training { Text("Во время тренировки нейросеть приостановлена, чтобы освободить ресурсы для сессии. Управление доступно во вкладке «Тренировка».").font(.caption).padding(.horizontal) }
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 12) {
                        ForEach(messages) { message in
                            Text(message.text).textSelection(.enabled).padding().background(message.fromUser ? Color.fitAccent.opacity(0.14) : Color.fitCard, in: RoundedRectangle(cornerRadius: 16)).frame(maxWidth: .infinity, alignment: message.fromUser ? .trailing : .leading).id(message.id)
                        }
                        if let plan = coach.proposal {
                            VStack(alignment: .leading, spacing: 8) {
                                Text(plan.name).font(.headline)
                                ForEach(plan.exercises) { item in
                                    Text("\(item.exercise.name) · \(item.sets) подх. · \(item.durationSeconds.map { "\($0) сек" } ?? "\(item.repetitions ?? 0) повт.")").font(.caption)
                                }
                                Button("Применить этот план на сегодня") {
                                    guard !training else { return }
                                    model.archive.plan = plan; model.archive.dailyPlanDate = Date(); model.changed()
                                    coach.proposal = nil; coach.status = "План применён и отправлен на часы. Проверьте связь перед запуском."
                                }.disabled(training || coach.busy)
                            }.padding().background(Color.fitCard, in: RoundedRectangle(cornerRadius: 16))
                        }
                    }.padding()
                }.onChange(of: messages.count) { _, _ in if let id = messages.last?.id { proxy.scrollTo(id, anchor: .bottom) } }
            }
            if !coach.status.isEmpty { Text(coach.status).font(.caption).padding(.horizontal).accessibilityIdentifier("local-coach-status") }
            if coach.busy { HStack { ProgressView(); Button("Остановить") { coach.cancel() } } }
            Button("Предложить новый комплекс") { proposePlan() }.disabled(!coach.ready || coach.busy || training)
            HStack {
                TextField("Спроси тренера о плане или прогрессе", text: $text, axis: .vertical).lineLimit(1...3).textFieldStyle(.roundedBorder)
                Button(action: send) { Image(systemName: "arrow.up.circle.fill").font(.title) }.disabled(!coach.ready || coach.busy || training || text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }.padding(.horizontal)
            Text("Небольшая модель может ошибаться. Она не ставит диагнозы и не управляет тренировкой сообщениями.").font(.caption2).foregroundStyle(.secondary).padding(.horizontal)
        }.padding(.bottom).navigationTitle("ИИ-тренер")
        .onAppear { messages = (try? store.load([ChatMessage].self, name: "chat")) ?? [ChatMessage(text: "Я локальный ИИ-тренер. После скачивания модели можем обсудить твой план и прогресс. Старые сообщения из версии с правилами сохранены в истории.", fromUser: false)] }
        .onDisappear { coach.cancel() }
        .onChange(of: scenePhase) { _, value in if value != .active { coach.cancel() } }
        .onChange(of: training) { _, value in if value { coach.cancel() } }
    }
    private func send() {
        let question = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !question.isEmpty, !training else { return }
        let prompt = LocalCoachPolicy.chatPrompt(question: question, history: messages.map { ($0.fromUser, $0.text) }, archive: model.archive)
        messages.append(ChatMessage(text: question, fromUser: true)); text = ""
        try? store.save(messages, name: "chat")
        coach.ask(prompt: prompt, tokens: 384) { answer in
            messages.append(ChatMessage(text: answer, fromUser: false)); try store.save(messages, name: "chat")
        }
    }
    private func proposePlan() {
        guard !training else { return }
        let archive = model.archive
        let latest = archive.history.sorted { $0.startedAt > $1.startedAt }.first
        let measuredFatigue = latest.map { SensorLoad.assess(record: $0, history: archive.history).higherThanUsual ? 7 : 5 } ?? 5
        let recovery = CoachEngine.makePlan(archive: archive, fatigue: measuredFatigue, sleepHours: model.useSleep ? model.sleepHours : nil).isLight
        coach.ask(prompt: LocalCoachPolicy.planPrompt(archive: archive, recovery: recovery), tokens: 640) { output in
            coach.proposal = try LocalCoachPolicy.validatedPlan(from: output, archive: archive, recovery: recovery)
        }
    }
}
