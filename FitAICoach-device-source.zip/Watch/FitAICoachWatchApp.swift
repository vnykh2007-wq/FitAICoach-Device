import SwiftUI
import WatchKit
import AVFoundation
import HealthKit

@main struct FitAICoachWatchApp: App {
    @WKApplicationDelegateAdaptor(WorkoutRecoveryDelegate.self) private var delegate
    @StateObject private var model = AppModel()
    var body: some Scene {
        WindowGroup { WatchRoot().environmentObject(model).environmentObject(WatchLaunchRouter.shared).tint(.fitAccent).onReceive(NotificationCenter.default.publisher(for: .fitWorkoutRecovery)) { _ in Task { await model.health.recover() } } }
    }
}
struct WatchRoot: View {
    @EnvironmentObject var model: AppModel
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject var launch: WatchLaunchRouter
    @State private var actualRepetitions = 8
    @State private var showStop = false
    @State private var showDiscard = false
    @State private var showDelete = false
    @State private var showTests = false
    @State private var notifiedExercise = false
    @State private var notifiedReady = false
    var body: some View {
        TimelineView(.periodic(from: .now, by: 1)) { context in
            ScrollView {
                VStack(spacing: 12) {
                    if let engine = model.engine, engine.state != .finished {
                        Text(phaseLabelWatch(engine.state)).font(.caption.bold()).foregroundStyle(Color.fitAccent)
                        Text(engine.currentExercise?.exercise.name ?? "Тренировка").font(.title3.bold()).multilineTextAlignment(.center)
                        HStack {
                            Text(clockString(engine.elapsed(at: context.date))).monospacedDigit()
                            Spacer()
                            Label(model.currentHeartRate, systemImage: "heart.fill").foregroundStyle(.pink).font(.caption)
                        }
                        switch engine.state {
                        case .ready:
                            Text("Подход \(engine.setNumber)").font(.caption)
                            if let kind = engine.record.controlTestKind { Text(kind.protocolDescription).font(.caption) }
                            else if let seconds = engine.currentExercise?.durationSeconds { Text("Цель: \(seconds) сек") }
                            else { Text("Цель: \(engine.currentExercise?.repetitions ?? 0) повторений") }
                            Button("Начать упражнение") { signal(.start); model.beginExercise() }.buttonStyle(.borderedProminent).foregroundStyle(.black)
                            if let exercise = engine.currentExercise?.exercise { Text(exercise.technique).font(.caption).foregroundStyle(.secondary) }
                        case .exercise:
                            if let target = engine.currentExercise?.durationSeconds {
                                Text(clockString(Int(ceil(max(0, Double(target) - engine.phaseElapsed(at: context.date)))))).font(.system(size: 36, weight: .bold, design: .rounded)).monospacedDigit()
                                Text(engine.phaseElapsed(at: context.date) >= Double(target) ? "Время вышло · нажмите «Закончил»" : "Осталось · цель \(target) сек").font(.caption2)
                            } else {
                                Text(clockString(engine.phaseElapsed(at: context.date))).font(.system(size: 36, weight: .bold, design: .rounded)).monospacedDigit()
                            }
                            if engine.currentExercise?.repetitions != nil { Stepper("Сделано: \(actualRepetitions)", value: $actualRepetitions, in: 0...200).font(.caption) }
                            Button(engine.record.controlTestKind == nil ? "Закончил" : "Завершить тест") {
                                signal(.success); model.complete(reps: engine.currentExercise?.repetitions == nil ? nil : actualRepetitions)
                                if model.engine?.state == .finished { Task { await model.stop() } }
                            }.buttonStyle(.borderedProminent).foregroundStyle(.black)
                            Button("Пропустить упражнение") {
                                model.complete(reps: nil, skipped: true)
                                if model.engine?.state == .finished { Task { await model.stop() } }
                            }.font(.caption)
                        case .rest:
                            Text(clockString(engine.restRemaining(at: context.date))).font(.system(size: 38, weight: .bold, design: .rounded)).monospacedDigit()
                            Text("Следующее: \(engine.nextExercise?.exercise.name ?? "завершение")").font(.caption)
                            Button("+30 секунд отдыха") { model.extendRest(); notifiedReady = false }
                            Button("Следующий подход") { signal(.start); model.next(); notifiedReady = false }.buttonStyle(.borderedProminent).foregroundStyle(.black)
                            Text("Продолжайте, когда восстановили дыхание и чувствуете готовность. Один пульс не определяет готовность.").font(.caption2).foregroundStyle(.secondary)
                        case .paused:
                            Button("Продолжить") { model.resume() }.buttonStyle(.borderedProminent).foregroundStyle(.black)
                            Text("Таймер остановлен").font(.caption)
                        case .finished: EmptyView()
                        }
                        if engine.state != .paused { Button("Пауза") { model.pause() } }
                        Button(engine.record.controlTestKind == nil ? "Завершить тренировку" : "Прервать тест", role: .destructive) { showStop = true }.font(.caption)
                        Button("Отменить без сохранения", role: .destructive) { showDiscard = true }.font(.caption).disabled(model.busy)
                        Text(model.health.heartRateMessage).font(.caption2).foregroundStyle(.secondary)
                        Text(model.sensorSummary).font(.caption2).foregroundStyle(.secondary)
                    } else if let record = model.engine?.record {
                        Text("ГОТОВО").font(.caption.bold()).foregroundStyle(Color.fitAccent)
                        Text(clockString(record.duration)).font(.largeTitle.bold())
                        Text("Подходов: \(record.exercises.count)")
                        Text("Средний пульс: \(record.statistics.average.map { String(Int($0)) } ?? "Нет данных")").font(.caption)
                        Text(model.sensorSummary).font(.caption2)
                        Button("Удалить тренировку", role: .destructive) { showDelete = true }.disabled(model.busy)
                        Button("Новая тренировка") { Task { await model.start() } }.disabled(model.busy || model.archive.plan.exercises.isEmpty)
                    } else {
                        Text("FITAI COACH").font(.headline).foregroundStyle(Color.fitAccent)
                        Text(model.archive.plan.name).font(.title3.bold()).multilineTextAlignment(.center)
                        Text("Ориентир: \(model.archive.plan.targetMinutes) мин").font(.caption)
                        Text("Пульс: Нет данных до начала сессии").font(.caption2).foregroundStyle(.secondary)
                        Button("Начать тренировку") { signal(.start); Task { await model.start() } }.buttonStyle(.borderedProminent).foregroundStyle(.black).disabled(model.busy || model.archive.plan.exercises.isEmpty)
                    }
                    if model.engine == nil || model.engine?.state == .finished { Button("Контрольные тесты") { showTests = true } }
                    if !model.message.isEmpty { Text(model.message).font(.caption2).foregroundStyle(.orange); Button("Скрыть сообщение") { model.message = "" }.font(.caption2) }
                    Text(model.connectivity.status).font(.caption2).foregroundStyle(.secondary)
                }.padding(.horizontal, 4)
            }
            .onChange(of: context.date) { _, date in
                if let engine = model.engine, engine.state == .exercise, let target = engine.currentExercise?.durationSeconds, engine.phaseElapsed(at: date) >= Double(target), !notifiedExercise {
                    signal(.notification); notifiedExercise = true
                }
                guard model.engine?.state == .rest, let remaining = model.engine?.restRemaining(at: date) else { return }
                if remaining <= 3 && !notifiedReady { signal(.notification); notifiedReady = true }
            }
        }
        .task { await launch.consume(model) }
        .onChange(of: scenePhase) { _, phase in if phase == .active { model.refreshDay() } }
        .onReceive(NotificationCenter.default.publisher(for: .NSCalendarDayChanged)) { _ in model.refreshDay() }
        .sheet(isPresented: $showTests) { WatchControlTestPicker().environmentObject(model) }
        .onChange(of: launch.requested) { _, _ in Task { await launch.consume(model) } }
        .onChange(of: model.engine?.state) { _, phase in
            if phase == .ready { actualRepetitions = model.engine?.currentExercise?.repetitions ?? 8; notifiedExercise = false }
        }
        .onChange(of: model.engine?.currentExercise?.id) { _, _ in actualRepetitions = model.engine?.currentExercise?.repetitions ?? 8; notifiedReady = false }
        .onChange(of: model.engine?.setNumber) { _, _ in actualRepetitions = model.engine?.currentExercise?.repetitions ?? 8; notifiedReady = false }
        .confirmationDialog("Завершить сейчас? При плохом самочувствии прекратите нагрузку.", isPresented: $showStop, titleVisibility: .visible) {
            Button("Завершить", role: .destructive) { Task { await model.stop() } }; Button("Отмена", role: .cancel) {}
        }
        .confirmationDialog("Отменить без сохранения?", isPresented: $showDiscard, titleVisibility: .visible) {
            Button("Отменить тренировку", role: .destructive) { model.discardWorkout() }
            Button("Продолжить", role: .cancel) {}
        }
        .confirmationDialog("Удалить из FitAI Coach? Запись Apple Health останется.", isPresented: $showDelete, titleVisibility: .visible) {
            Button("Удалить", role: .destructive) { if let id = model.engine?.record.id { model.deleteWorkout(id) } }
            Button("Отмена", role: .cancel) {}
        }
    }
    private func signal(_ type: WKHapticType) {
        if model.archive.settings.hapticsEnabled { WKInterfaceDevice.current().play(type) }
        if model.archive.settings.soundsEnabled { WatchCue.shared.play() }
    }
}
struct WatchControlTestPicker: View {
    @EnvironmentObject var model: AppModel
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        List(FitnessTestKind.allCases, id: \.self) { kind in
            Button(kind.title) { dismiss(); Task { await model.start(controlTest: kind) } }.disabled(model.busy)
        }
    }
}
private func phaseLabelWatch(_ phase: WorkoutPhase) -> String {
    switch phase { case .ready: return "ГОТОВНОСТЬ"; case .exercise: return "УПРАЖНЕНИЕ"; case .rest: return "ОТДЫХ"; case .paused: return "ПАУЗА"; case .finished: return "РЕЗУЛЬТАТ" }
}

extension Notification.Name { static let fitWorkoutRecovery = Notification.Name("FitWorkoutRecovery") }
final class WorkoutRecoveryDelegate: NSObject, WKApplicationDelegate {
    func handle(_ workoutConfiguration: HKWorkoutConfiguration) {
        Task { @MainActor in WatchLaunchRouter.shared.requested = true }
    }
    func handleActiveWorkoutRecovery() { NotificationCenter.default.post(name: .fitWorkoutRecovery, object: nil) }
}
@MainActor final class WatchLaunchRouter: ObservableObject {
    static let shared = WatchLaunchRouter()
    @Published var requested = false
    func consume(_ model: AppModel) async {
        guard requested else { return }; requested = false
        await model.startFromPhone()
    }
}
@MainActor final class WatchCue {
    static let shared = WatchCue()
    private var player: AVAudioPlayer?
    func play() {
        guard let url = Bundle.main.url(forResource: "cue", withExtension: "wav") else { return }
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try AVAudioSession.sharedInstance().setActive(true)
            player = try AVAudioPlayer(contentsOf: url); player?.volume = 0.3; player?.play()
        } catch { /* Haptics remain available when watchOS disallows audio output. */ }
    }
}
