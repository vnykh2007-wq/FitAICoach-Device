"""Guard against packaging ARM64 simulator binaries as device installers."""
import importlib.util
from pathlib import Path
import plistlib
import struct
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('device_package', Path(__file__).resolve().parents[1] / 'scripts/package_device.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class DevicePackageTests(unittest.TestCase):
    def check_bundle(self, platform_name, binary_platform, expected_name='iphoneos', expected_number=2):
        with tempfile.TemporaryDirectory() as directory:
            app = Path(directory) / 'Fixture.app'
            app.mkdir()
            (app / 'Info.plist').write_bytes(plistlib.dumps({'DTPlatformName': platform_name, 'CFBundleExecutable': 'Fixture'}))
            header = struct.pack('<8I', 0xFEEDFACF, 0x0100000C, 0, 2, 1, 24, 0, 0)
            command = struct.pack('<6I', 0x32, 24, binary_platform, 0, 0, 0)
            (app / 'Fixture').write_bytes(header + command)
            return module.verify_app(app, expected_name, expected_number)

    def test_accepts_physical_phone_and_watch(self):
        self.check_bundle('iphoneos', 2)
        self.check_bundle('watchos', 4, 'watchos', 4)

    def test_rejects_simulator_even_with_arm64_and_forged_plist(self):
        with self.assertRaises(ValueError):
            self.check_bundle('iphoneos', 7)
        with self.assertRaises(ValueError):
            self.check_bundle('watchos', 9, 'watchos', 4)

    def test_rejects_simulator_plist_even_with_device_binary(self):
        with self.assertRaises(ValueError):
            self.check_bundle('iphonesimulator', 2)

    def test_watch_universal_binary_validates_every_slice(self):
        def thin(cpu, platform):
            header = struct.pack('<7I', 0xFEEDFACE, cpu, 0, 2, 1, 24, 0) if cpu == 0x0200000C else struct.pack('<8I', 0xFEEDFACF, cpu, 0, 2, 1, 24, 0, 0)
            return header + struct.pack('<6I', 0x32, 24, platform, 0, 0, 0)
        def universal(platform):
            first = thin(0x0200000C, 4)
            second = thin(0x0100000C, platform)
            return (struct.pack('>II', 0xCAFEBABE, 2)
                    + struct.pack('>iiIII', 0x0200000C, 0, 48, len(first), 0)
                    + struct.pack('>iiIII', 0x0100000C, 0, 48 + len(first), len(second), 0)
                    + first + second)
        module.verify_binary(universal(4), 4)
        with self.assertRaises(ValueError):
            module.verify_binary(universal(9), 4)

    def test_existing_simulator_artifact_is_rejected(self):
        app = Path(__file__).resolve().parents[1] / 'build/validated-run23/build/iOS/Build/Products/Debug-iphonesimulator/FitAICoach.app'
        if not app.exists():
            self.skipTest('Previously downloaded simulator artifact not present')
        with self.assertRaises(ValueError):
            module.verify_app(app, 'iphoneos', 2)


if __name__ == '__main__':
    unittest.main()
