// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "FitAICore", platforms: [.macOS(.v13), .iOS(.v17), .watchOS(.v10)], products: [.library(name: "FitAICore", targets: ["FitAICore"])], targets: [.target(name: "FitAICore", path: "Shared"), .testTarget(name: "FitAICoreTests", dependencies: ["FitAICore"], path: "Tests")])
