import Foundation
import HealthKit

extension HealthService {
    /// Optional, separate permission: no sleep data is requested until the user chooses this feature.
    func requestSleepAccess() async throws {
        guard HKHealthStore.isHealthDataAvailable(), let type = HKCategoryType.categoryType(forIdentifier: .sleepAnalysis) else {
            throw HealthServiceError.unavailable
        }
        try await store.requestAuthorization(toShare: [], read: [type])
    }
    /// Missing permission and missing data intentionally produce nil, never a made-up sleep estimate.
    func recentSleepHours(now: Date = Date()) async throws -> Double? {
        guard let type = HKCategoryType.categoryType(forIdentifier: .sleepAnalysis) else { return nil }
        let start = now.addingTimeInterval(-24 * 3600)
        let predicate = HKQuery.predicateForSamples(withStart: start, end: now, options: [])
        let samples: [HKCategorySample] = try await withCheckedThrowingContinuation { continuation in
            let query = HKSampleQuery(sampleType: type, predicate: predicate, limit: HKObjectQueryNoLimit, sortDescriptors: nil) { _, samples, error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: samples as? [HKCategorySample] ?? []) }
            }
            self.store.execute(query)
        }
        let asleepValues: Set<Int> = [HKCategoryValueSleepAnalysis.asleepUnspecified.rawValue,
                                     HKCategoryValueSleepAnalysis.asleepCore.rawValue,
                                     HKCategoryValueSleepAnalysis.asleepDeep.rawValue,
                                     HKCategoryValueSleepAnalysis.asleepREM.rawValue]
        let intervals = samples.filter { asleepValues.contains($0.value) }
            .map { (max(start, $0.startDate), min(now, $0.endDate)) }
            .filter { $0.1 > $0.0 }.sorted { $0.0 < $1.0 }
        guard var current = intervals.first else { return nil }
        var seconds: TimeInterval = 0
        for interval in intervals.dropFirst() {
            if interval.0 <= current.1 { current.1 = max(current.1, interval.1) }
            else { seconds += current.1.timeIntervalSince(current.0); current = interval }
        }
        seconds += current.1.timeIntervalSince(current.0)
        return seconds / 3600
    }
}
