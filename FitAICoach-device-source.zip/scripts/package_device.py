"""Package a physical-device build for subsequent Apple signing, never a simulator.

Run on macOS after an unsigned Release build. The IPA is NOT installable until
signed with valid device provisioning. No account or signing secrets are used.
"""
from pathlib import Path
import argparse
import plistlib
import struct
import subprocess
import tempfile
import shutil


def verify_binary(data, platform_number):
    if len(data) < 28:
        raise ValueError('Truncated Mach-O header')
    fat_magic, slices = struct.unpack_from('>II', data)
    if fat_magic in (0xCAFEBABE, 0xCAFEBABF):
        layout = '>iiIII' if fat_magic == 0xCAFEBABE else '>iiQQII'
        width = struct.calcsize(layout)
        if not 1 <= slices <= 32 or 8 + slices * width > len(data):
            raise ValueError('Invalid universal binary')
        for index in range(slices):
            entry = struct.unpack_from(layout, data, 8 + index * width)
            offset, length = entry[2:4]
            if offset < 8 + slices * width or length < 28 or offset + length > len(data):
                raise ValueError('Invalid universal binary slice')
            verify_binary(data[offset:offset + length], platform_number)
        return
    magic, cpu, subtype, filetype, count, size, flags = struct.unpack_from('<7I', data)
    header_size = {0xFEEDFACE: 28, 0xFEEDFACF: 32}.get(magic)
    allowed_cpus = (0x0100000C,) if platform_number == 2 else (0x0100000C, 0x0200000C)
    if header_size is None or cpu not in allowed_cpus or filetype != 2:
        raise ValueError('Expected ARM64 device executable (ARM64_32 also allowed on Watch)')
    end = header_size + size
    if end > len(data):
        raise ValueError('Truncated Mach-O commands')
    offset = header_size
    platforms = []
    for _ in range(count):
        if offset + 8 > end:
            raise ValueError('Missing Mach-O command')
        command, length = struct.unpack_from('<II', data, offset)
        if length < 8 or offset + length > end:
            raise ValueError('Invalid Mach-O command length')
        if command == 0x32:  # LC_BUILD_VERSION: differentiates ARM64 simulator/device.
            if length < 24:
                raise ValueError('Truncated build-version command')
            platforms.append(struct.unpack_from('<I', data, offset + 8)[0])
        offset += length
    if offset != end or platforms != [platform_number]:
        raise ValueError(f'Wrong Mach-O platform {platforms}')


def verify_app(app, platform_name, platform_number):
    with (app / 'Info.plist').open('rb') as stream:
        info = plistlib.load(stream)
    if info.get('DTPlatformName') != platform_name:
        raise ValueError(f'{app.name}: expected {platform_name}, got {info.get("DTPlatformName")}')
    executable = info.get('CFBundleExecutable', '')
    if not executable or Path(executable).name != executable:
        raise ValueError('Invalid bundle executable')
    verify_binary((app / executable).read_bytes(), platform_number)
    return info


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('app', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    phone = verify_app(args.app, 'iphoneos', 2)
    watches = list((args.app / 'Watch').glob('*.app'))
    if len(watches) != 1:
        raise ValueError('Expected the embedded Apple Watch companion')
    watch = verify_app(watches[0], 'watchos', 4)
    if watch.get('WKCompanionAppBundleIdentifier') != phone.get('CFBundleIdentifier'):
        raise ValueError('Watch companion identifier does not match iPhone')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='fitai-device-') as directory:
        payload = Path(directory) / 'Payload'
        payload.mkdir()
        shutil.copytree(args.app, payload / args.app.name, symlinks=True)
        subprocess.run(['ditto', '-c', '-k', '--sequesterRsrc', '--keepParent', str(payload), str(args.output.resolve())], check=True)
    print(f'Verified physical iOS/watchOS ARM64 build: {args.output}')
    print('UNSIGNED: valid Apple signing and provisioning are still required before installation.')


if __name__ == '__main__':
    main()
