import Foundation

public struct Profile: Codable, Equatable, Sendable {
    public var age = 0
    public var heightCM = 0
    public var weightKG = 0.0
    public var pushUpMaximum = 0
    public var plankMaximumSeconds = 0
    public init() {}
}
public struct Exercise: Identifiable, Codable, Equatable, Sendable {
    public var id: String
    public var name: String
    public var technique: String
    public var muscles: [String]
    public var mistakes: String
    public var easierVariant: String
    public init(id: String = UUID().uuidString, name: String, technique: String = "Выполняйте движение медленно и без боли.", muscles: [String] = [], mistakes: String = "Не задерживайте дыхание.", easierVariant: String = "Уменьшите амплитуду и нагрузку.") {
        self.id=id; self.name=name; self.technique=technique; self.muscles=muscles; self.mistakes=mistakes; self.easierVariant=easierVariant
    }
}
public struct ExercisePlan: Identifiable, Codable, Equatable, Sendable {
    public var id: UUID
    public var exercise: Exercise
    public var repetitions: Int?
    public var durationSeconds: Int?
    public var sets: Int
    public var restSeconds: Int
    public init(id: UUID = UUID(), exercise: Exercise, repetitions: Int? = 8, durationSeconds: Int? = nil, sets: Int = 1, restSeconds: Int = 30) {
        self.id=id; self.exercise=exercise; self.repetitions=repetitions.map { max(0,$0) }; self.durationSeconds=durationSeconds.map { max(1,$0) }; self.sets=max(1,sets); self.restSeconds=max(0,restSeconds)
    }
}
public struct WorkoutPlan: Identifiable, Codable, Equatable, Sendable {
    public var id: UUID
    public var name: String
    public var targetMinutes: Int
    public var exercises: [ExercisePlan]
    public var isLight: Bool
    public init(id: UUID = UUID(), name: String, targetMinutes: Int = 30, exercises: [ExercisePlan], isLight: Bool = false) {
        self.id=id; self.name=name; self.targetMinutes=max(5,targetMinutes); self.exercises=exercises; self.isLight=isLight
    }
}
public struct HeartRateSample: Identifiable, Codable, Equatable, Sendable {
    public var id: UUID
    public var date: Date
    public var bpm: Double
    public init(id: UUID = UUID(), date: Date, bpm: Double) { self.id=id; self.date=date; self.bpm=bpm }
}
public struct HeartRateStatistics: Codable, Equatable, Sendable {
    public var count: Int
    public var average: Double?
    public var maximum: Double?
    public init(samples: [HeartRateSample]) {
        let values=samples.map(\.bpm).filter { $0.isFinite && $0 > 0 }
        count=values.count; average=values.isEmpty ? nil : values.reduce(0,+)/Double(values.count); maximum=values.max()
    }
}
public struct ExerciseRecord: Identifiable, Codable, Equatable, Sendable {
    public var id = UUID()
    public var exercise: Exercise
    public var setNumber: Int
    public var startedAt: Date
    public var endedAt: Date
    public var duration: TimeInterval
    public var plannedRepetitions: Int?
    public var actualRepetitions: Int?
    public var plannedDurationSeconds: Int?
    public var skipped: Bool
    public var heartRate: [HeartRateSample]
    public var statistics: HeartRateStatistics { HeartRateStatistics(samples: heartRate) }
}
public struct RestRecord: Identifiable, Codable, Equatable, Sendable {
    public var id = UUID()
    public var startedAt: Date
    public var endedAt: Date
    public var duration: TimeInterval
    public var heartRate: [HeartRateSample]
    public var statistics: HeartRateStatistics { HeartRateStatistics(samples: heartRate) }
}
public struct WorkoutRecord: Identifiable, Codable, Equatable, Sendable {
    public var id: UUID
    public var planName: String
    public var startedAt: Date
    public var endedAt: Date?
    public var duration: TimeInterval
    public var exercises: [ExerciseRecord]
    public var rests: [RestRecord]
    public var heartRate: [HeartRateSample]
    public var activeCalories: Double?
    public var fatigue: Int?
    public var isLight: Bool
    public var interrupted: Bool
    public var reportedAverageHeartRate: Double?
    public var healthWorkoutID: UUID?
    /// Historical baseline has a known calendar date, not an observed start time.
    public var dateOnly: Bool = false
    public var statistics: HeartRateStatistics { HeartRateStatistics(samples: heartRate) }
    public init(id:UUID=UUID(), planName:String, startedAt:Date, endedAt:Date?=nil, duration:TimeInterval=0, exercises:[ExerciseRecord]=[], rests:[RestRecord]=[], heartRate:[HeartRateSample]=[], activeCalories:Double?=nil, fatigue:Int?=nil, isLight:Bool=false, interrupted:Bool=false, reportedAverageHeartRate:Double?=nil, healthWorkoutID:UUID?=nil) {
        self.id=id; self.planName=planName; self.startedAt=startedAt; self.endedAt=endedAt; self.duration=duration; self.exercises=exercises; self.rests=rests; self.heartRate=heartRate; self.activeCalories=activeCalories; self.fatigue=fatigue; self.isLight=isLight; self.interrupted=interrupted; self.reportedAverageHeartRate=reportedAverageHeartRate; self.healthWorkoutID=healthWorkoutID
    }
}
public enum CalendarStatus: String, CaseIterable, Codable, Sendable { case completed, rest, missed, light }
public struct CalendarEntry: Identifiable, Codable, Equatable, Sendable {
    public var id: UUID
    public var date: Date
    public var status: CalendarStatus
    public var reason: String
    public init(id:UUID=UUID(), date:Date, status:CalendarStatus, reason:String="") { self.id=id; self.date=date; self.status=status; self.reason=reason }
}
public struct AppSettings: Codable, Equatable, Sendable {
    public var hapticsEnabled=true
    public var soundsEnabled=true
    public var workoutMinutes=30
    public init() {}
}
public enum FitnessTestKind: String, CaseIterable, Codable, Sendable { case pushups, plank }
public struct FitnessTestRecord: Identifiable, Codable, Equatable, Sendable {
    public var id: UUID
    public var date: Date
    public var kind: FitnessTestKind
    public var value: Int
    public var note: String
    public init(id:UUID=UUID(),date:Date=Date(),kind:FitnessTestKind,value:Int,note:String="") {
        self.id=id; self.date=date; self.kind=kind; self.value=max(0,value); self.note=note
    }
}
public struct AppArchive: Codable, Equatable, Sendable {
    public var schemaVersion=1
    public var testResults: [FitnessTestRecord] = []
    public var profile: Profile
    public var plan: WorkoutPlan
    public var history: [WorkoutRecord]
    public var calendar: [CalendarEntry]
    public var settings: AppSettings
    public init(profile:Profile=Profile(), plan:WorkoutPlan, history:[WorkoutRecord]=[], calendar:[CalendarEntry]=[], settings:AppSettings=AppSettings(), testResults:[FitnessTestRecord]=[]) { self.profile=profile; self.plan=plan; self.history=history; self.calendar=calendar; self.settings=settings; self.testResults=testResults }
}
