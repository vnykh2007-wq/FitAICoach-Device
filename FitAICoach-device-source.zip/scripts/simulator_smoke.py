"""macOS-only launch smoke test; never uses a real device or health measurements."""
from pathlib import Path
import json
import subprocess
import time
import shutil
import traceback

root = Path(__file__).resolve().parents[1]
output = root / 'build' / 'screenshots'
output.mkdir(parents=True, exist_ok=True)

def call(*args, capture=False):
    result = subprocess.run(['xcrun', 'simctl', *args], check=True, text=True,
                            stdout=subprocess.PIPE if capture else None)
    return result.stdout if capture else None

inventory = json.loads(call('list', 'devices', 'available', '--json', capture=True))['devices']

def select(platform, name_prefix, preferred_name=None):
    for runtime in sorted(inventory, reverse=True):
        if platform not in runtime:
            continue
        if preferred_name:
            for device in inventory[runtime]:
                if device.get('isAvailable') and device['name'] == preferred_name:
                    print(f'Selected {device["name"]}, runtime {runtime}', flush=True)
                    return device
            types = json.loads(call('list', 'devicetypes', '--json', capture=True))['devicetypes']
            preferred = next((item for item in types if item['name'] == preferred_name), None)
            if preferred:
                udid = call('create', preferred_name, preferred['identifier'], runtime, capture=True).strip()
                print(f'Created {preferred_name}, runtime {runtime}', flush=True)
                return {'udid': udid, 'state': 'Shutdown', 'name': preferred_name}
            raise RuntimeError(f'Device type {preferred_name} unavailable')
        for device in inventory[runtime]:
            if device.get('isAvailable') and device['name'].startswith(name_prefix):
                print(f'Selected {device["name"]}, runtime {runtime}', flush=True)
                return device
    raise RuntimeError(f'No available {platform} simulator runtime/device')

def launch_and_capture(device, product, bundle, name):
    udid = device['udid']
    if device['state'] != 'Booted':
        call('boot', udid)
    try:
        call('bootstatus', udid, '-b')
        # Keep Xcode's simulator signature, including its platform-specific entitlements.
        subprocess.run(['codesign', '--verify', '--deep', '--strict', str(product)], check=True)
        subprocess.run(['codesign', '-d', '--entitlements', ':-', str(product)], check=True)
        call('install', udid, str(product))
        result = None
        for attempt in range(3):
            try:
                launched = subprocess.run(['xcrun', 'simctl', 'launch', udid, bundle], text=True, capture_output=True, timeout=90)
            except subprocess.TimeoutExpired:
                print(f'{name} launch attempt {attempt + 1} timed out; retry after LaunchServices registration settles', flush=True)
                time.sleep(10)
                continue
            if launched.returncode == 0:
                result = launched.stdout
                break
            print(f'{name} launch attempt {attempt + 1}: {launched.stderr}', flush=True)
            time.sleep(10)
        if result is None:
            raise RuntimeError(f'{name} did not launch after SpringBoard readiness retries')
        print(f'{name} launch: {result.strip()}', flush=True)
        time.sleep(4)
        call('io', udid, 'screenshot', str(output / f'{name}.png'))
        services = call('spawn', udid, 'launchctl', 'list', capture=True)
        if bundle not in services:
            raise RuntimeError(f'{name} app process did not remain running')
    except Exception:
        # Keep actual system evidence, even when launch itself is refused.
        with (root / 'build' / f'simulator-{name}-host.log').open('w') as log:
            subprocess.run(['log', 'show', '--last', '5m', '--style', 'compact', '--predicate', 'eventMessage CONTAINS "FitAICoach" OR eventMessage CONTAINS "AMFI"'], stdout=log, stderr=subprocess.STDOUT, timeout=45)
        subprocess.run(['xcrun', 'simctl', 'io', udid, 'screenshot', str(output / f'{name}-failure.png')], timeout=30)
        with (root / 'build' / f'simulator-{name}-system.log').open('w') as log:
            subprocess.run(['xcrun', 'simctl', 'spawn', udid, 'log', 'show', '--last', '5m', '--style', 'compact', '--predicate', f'eventMessage CONTAINS "{bundle}" OR process == "FitAICoach" OR process == "SpringBoard" OR process == "runningboardd"'], stdout=log, stderr=subprocess.STDOUT, timeout=45)
        crashes = Path.home() / 'Library' / 'Logs' / 'DiagnosticReports'
        for crash in crashes.glob('FitAICoach*'):
            if crash.is_file():
                shutil.copy2(crash, root / 'build' / crash.name)
        raise
    finally:
        call('shutdown', udid)

phone = select('iOS-', 'iPhone', 'iPhone 15 Plus')
watch = select('watchOS-', 'Apple Watch', 'Apple Watch Series 10 (42mm)')
failures = []
for device, product, bundle, name in [
    (phone, root / 'build/iOS/Build/Products/Debug-iphonesimulator/FitAICoach.app', 'local.fitai.coach', 'iPhone'),
    (watch, root / 'build/watchOS/Build/Products/Debug-watchsimulator/FitAICoachWatch.app', 'local.fitai.coach.watchkitapp', 'Watch'),
]:
    try:
        launch_and_capture(device, product, bundle, name)
    except Exception as error:
        traceback.print_exc()
        failures.append(f'{name}: {error}')
if failures:
    raise RuntimeError('; '.join(failures))
print('Both simulator apps launched and remained running. This is not real-device validation.')

