import XCTest
@testable import FitAICore

final class WorkoutEngineTests: XCTestCase {
    func testWarmupExpansionIsIdempotentAndKeepsMainExercises() {
        let legacy = WorkoutPlan(name: "Старый план", exercises: [ExercisePlan(exercise: ExerciseLibrary.named("warmup")), ExercisePlan(exercise: ExerciseLibrary.named("pushups"))])
        let expanded = ExerciseLibrary.expandWarmup(in: legacy)
        XCTAssertEqual(expanded.exercises.count, 7)
        XCTAssertEqual(expanded.exercises.prefix(6).compactMap(\.durationSeconds), [60, 30, 60, 30, 60])
        XCTAssertEqual(expanded.exercises[4].repetitions, 15)
        XCTAssertEqual(expanded.exercises.last?.id, legacy.exercises.last?.id)
        XCTAssertEqual(ExerciseLibrary.expandWarmup(in: expanded), expanded)
    }
    func testWarmupDoesNotInsertRestAndPauseStillFreezesClock() {
        var engine = WorkoutEngine(plan: WorkoutPlan(name: "Разминка", exercises: ExerciseLibrary.warmupSteps()), now: zero)
        engine.startExercise(now: zero)
        engine.pause(now: zero.addingTimeInterval(20))
        engine.resume(now: zero.addingTimeInterval(40))
        engine.finishExercise(actualRepetitions: nil, now: zero.addingTimeInterval(80))
        XCTAssertEqual(engine.record.exercises.first?.duration, 60)
        XCTAssertEqual(engine.state, .ready)
        XCTAssertEqual(engine.currentExercise?.exercise.id, "warmupArms")
        XCTAssertEqual(engine.record.rests.count, 1)
        XCTAssertEqual(engine.record.rests.first?.duration, 0)
    }
    func testDeletedHistoryCannotReturnFromOfflineCopy() throws {
        let first = WorkoutRecord(planName: "Случайная", startedAt: zero, endedAt: zero.addingTimeInterval(5))
        let second = WorkoutRecord(planName: "Нужная", startedAt: zero, endedAt: zero.addingTimeInterval(600))
        var archive = AppArchive(plan: SeedData.defaultPlan(), history: [first, second], calendar: [CalendarEntry(date: zero, status: .completed, workoutID: first.id)])
        WorkoutHistory.delete(first.id, from: &archive)
        XCTAssertEqual(archive.history.map(\.id), [second.id])
        XCTAssertEqual(archive.calendar.first?.workoutID, second.id)
        let saved = try JSONEncoder().encode(archive)
        archive = try JSONDecoder().decode(AppArchive.self, from: saved)
        archive.history.append(first) // A stale peer still holds the deleted workout.
        WorkoutHistory.mergeDeleted([], into: &archive)
        XCTAssertEqual(archive.history.map(\.id), [second.id])
        WorkoutHistory.delete(second.id, from: &archive)
        XCTAssertTrue(archive.history.isEmpty)
        XCTAssertTrue(archive.calendar.isEmpty)
    }
    func testOldArchiveDecodesAndManualCalendarSurvivesDeletion() throws {
        var archive = AppArchive(plan: SeedData.defaultPlan())
        let record = WorkoutRecord(planName: "Удалить", startedAt: zero)
        archive.history = [record]
        archive.calendar = [CalendarEntry(date: zero, status: .rest, reason: "Моя отметка")]
        var old = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(archive)) as? [String: Any])
        old.removeValue(forKey: "deletedWorkoutIDs")
        archive = try JSONDecoder().decode(AppArchive.self, from: JSONSerialization.data(withJSONObject: old))
        XCTAssertNil(archive.deletedWorkoutIDs)
        WorkoutHistory.delete(record.id, from: &archive)
        XCTAssertEqual(archive.calendar.first?.reason, "Моя отметка")
    }
    let zero=Date(timeIntervalSince1970:1_700_000_000)
    func plan(sets:Int=1,two:Bool=false) -> WorkoutPlan {
        let entry=ExercisePlan(exercise:ExerciseLibrary.named("pushups"),repetitions:8,sets:sets,restSeconds:30)
        return WorkoutPlan(name:"Тест",exercises:two ? [entry,ExercisePlan(exercise:ExerciseLibrary.named("squats"))] : [entry])
    }
    func testStartFinishAndActualRepetitions() {
        var engine=WorkoutEngine(plan:plan(),now:zero)
        XCTAssertEqual(engine.state,.ready)
        engine.startExercise(now:zero)
        engine.finishExercise(actualRepetitions:6,now:zero.addingTimeInterval(20))
        XCTAssertEqual(engine.state,.finished)
        XCTAssertEqual(engine.record.exercises.count,1)
        XCTAssertEqual(engine.record.exercises[0].actualRepetitions,6)
        XCTAssertEqual(engine.record.exercises[0].plannedRepetitions,8)
        XCTAssertEqual(engine.record.duration,20)
        XCTAssertFalse(engine.record.interrupted)
        engine.finish(now:zero.addingTimeInterval(100))
        XCTAssertEqual(engine.record.duration,20)
    }
    func testPauseExcludesTimeInExerciseAndWorkout() {
        var engine=WorkoutEngine(plan:plan(),now:zero)
        engine.startExercise(now:zero)
        engine.pause(now:zero.addingTimeInterval(10))
        XCTAssertEqual(engine.elapsed(at:zero.addingTimeInterval(90)),10)
        engine.resume(now:zero.addingTimeInterval(40))
        engine.finishExercise(actualRepetitions:8,now:zero.addingTimeInterval(50))
        XCTAssertEqual(engine.record.duration,20)
        XCTAssertEqual(engine.record.exercises.first?.duration,20)
    }
    func testSetsRestAndExtension() {
        var engine=WorkoutEngine(plan:plan(sets:2),now:zero)
        engine.startExercise(now:zero)
        engine.finishExercise(actualRepetitions:8,now:zero.addingTimeInterval(10))
        XCTAssertEqual(engine.state,.rest)
        XCTAssertEqual(engine.restRemaining(at:zero.addingTimeInterval(15)),25)
        engine.extendRest()
        XCTAssertEqual(engine.restRemaining(at:zero.addingTimeInterval(15)),55)
        engine.pause(now:zero.addingTimeInterval(15))
        XCTAssertEqual(engine.restRemaining(at:zero.addingTimeInterval(100)),55)
        engine.resume(now:zero.addingTimeInterval(100))
        engine.startNext(now:zero.addingTimeInterval(110))
        XCTAssertEqual(engine.setNumber,2)
        XCTAssertEqual(engine.state,.ready)
        XCTAssertEqual(engine.record.rests.first?.duration,15)
        engine.startExercise(now:zero.addingTimeInterval(110))
        engine.finishExercise(actualRepetitions:7,now:zero.addingTimeInterval(130))
        XCTAssertEqual(engine.record.exercises.map(\.setNumber),[1,2])
    }
    func testRealSamplesOnlyAndDeduplication() {
        var engine=WorkoutEngine(plan:plan(),now:zero)
        XCTAssertNil(engine.record.statistics.average)
        engine.startExercise(now:zero)
        let sample=HeartRateSample(date:zero.addingTimeInterval(5),bpm:100)
        engine.addHeartRate(sample); engine.addHeartRate(sample)
        engine.addHeartRate(HeartRateSample(date:zero.addingTimeInterval(8),bpm:140))
        engine.addHeartRate(HeartRateSample(date:zero.addingTimeInterval(9),bpm:-1))
        engine.finishExercise(actualRepetitions:8,now:zero.addingTimeInterval(10))
        XCTAssertEqual(engine.record.statistics.average,120)
        XCTAssertEqual(engine.record.statistics.maximum,140)
        XCTAssertEqual(engine.record.exercises[0].statistics.count,2)
    }
    func testCommandDuplicateAndWrongWorkout() {
        var engine=WorkoutEngine(plan:plan(two:true),now:zero)
        engine.startExercise(now:zero)
        var ledger=CommandLedger()
        let finish=WorkoutCommand(workoutID:engine.record.id,action:.finishExercise,repetitions:6)
        XCTAssertTrue(ledger.apply(finish,to:&engine,now:zero.addingTimeInterval(10)))
        XCTAssertFalse(ledger.apply(finish,to:&engine,now:zero.addingTimeInterval(20)))
        XCTAssertEqual(engine.record.exercises.count,1)
        XCTAssertFalse(ledger.apply(WorkoutCommand(workoutID:UUID(),action:.finish),to:&engine))
        XCTAssertEqual(engine.state,.rest)
    }
    func testInterruptedExercisePreserved() {
        var engine=WorkoutEngine(plan:plan(),now:zero)
        engine.startExercise(now:zero)
        engine.finish(now:zero.addingTimeInterval(10))
        XCTAssertTrue(engine.record.interrupted)
        XCTAssertTrue(engine.record.exercises[0].skipped)
        XCTAssertNil(engine.record.exercises[0].actualRepetitions)
    }
    func testAtomicSaveAndRecovery() throws {
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at:directory) }
        let store=JSONStore(directory:directory)
        var engine=WorkoutEngine(plan:plan(sets:2),now:zero)
        engine.startExercise(now:zero)
        engine.addHeartRate(HeartRateSample(date:zero.addingTimeInterval(2),bpm:105))
        engine.pause(now:zero.addingTimeInterval(10))
        try store.save(engine,name:"active")
        var recovered=try XCTUnwrap(store.load(WorkoutEngine.self,name:"active"))
        XCTAssertEqual(recovered.state,.paused)
        XCTAssertEqual(recovered.record.id,engine.record.id)
        recovered.resume(now:zero.addingTimeInterval(30))
        recovered.finishExercise(actualRepetitions:6,now:zero.addingTimeInterval(40))
        XCTAssertEqual(recovered.record.exercises[0].duration,20)
        XCTAssertEqual(recovered.record.statistics.average,105)
        try store.save(SeedData.archive(),name:"archive")
        XCTAssertEqual(try store.load(AppArchive.self,name:"archive")?.history.count,0)
    }
    func testCorruptionIsNotSilentlyReplaced() throws {
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at:directory) }
        try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
        try Data("invalid json".utf8).write(to:directory.appendingPathComponent("archive.json"))
        XCTAssertThrowsError(try JSONStore(directory:directory).load(AppArchive.self,name:"archive"))
    }
    func testSeedNeverFabricatesMeasurements() {
        let archive = SeedData.archive()
        XCTAssertTrue(archive.history.isEmpty)
        XCTAssertTrue(archive.calendar.isEmpty)
        XCTAssertTrue(archive.testResults.isEmpty)
        XCTAssertEqual(archive.profile.age, 0)
        XCTAssertEqual(archive.profile.weightKG, 0)
    }
    func testCoachRecoveryAndHonestChat() {
        let archive=SeedData.archive()
        XCTAssertTrue(CoachEngine.makePlan(archive:archive,fatigue:8,now:zero).isLight)
        XCTAssertTrue(CoachEngine.makePlan(archive:archive,sleepHours:4,now:zero).isLight)
        XCTAssertTrue(CoachEngine.reply(to:"болит плечо",archive:archive).contains("Прекрати"))
        XCTAssertTrue(CoachEngine.reply(to:"непонятный запрос",archive:archive).contains("правил"))
    }
    func testEmptyPlanFinishesSafely() {
        let engine=WorkoutEngine(plan:WorkoutPlan(name:"Пустой",exercises:[]),now:zero)
        XCTAssertEqual(engine.state,.finished)
        XCTAssertNil(engine.currentExercise)
    }
    func testDelayedSamplesAttributedToObservationPhaseAndPauseExcluded() {
        var engine=WorkoutEngine(plan:plan(two:true),now:zero)
        engine.startExercise(now:zero)
        engine.pause(now:zero.addingTimeInterval(3))
        engine.resume(now:zero.addingTimeInterval(7))
        engine.finishExercise(actualRepetitions:8,now:zero.addingTimeInterval(10))
        engine.addHeartRate(HeartRateSample(date:zero.addingTimeInterval(2),bpm:100))
        engine.addHeartRate(HeartRateSample(date:zero.addingTimeInterval(5),bpm:190))
        engine.addHeartRate(HeartRateSample(date:zero.addingTimeInterval(12),bpm:120))
        XCTAssertEqual(engine.record.exercises[0].statistics.average,100)
        XCTAssertEqual(engine.record.statistics.average,110)
    }
    func testCoachProgressionUsesPreviousPlannedRepetitions() {
        var archive=SeedData.archive()
        var engine=WorkoutEngine(plan:WorkoutPlan(name:"Программа",exercises:[ExercisePlan(exercise:ExerciseLibrary.named("pushups"),repetitions:7)]),now:zero)
        engine.startExercise(now:zero)
        engine.finishExercise(actualRepetitions:7,now:zero.addingTimeInterval(10))
        engine.setFatigue(4)
        archive.history=[engine.record]
        let plan=CoachEngine.makePlan(archive:archive,now:zero.addingTimeInterval(72*3600))
        XCTAssertEqual(plan.exercises.first { $0.exercise.id == "pushups" }?.repetitions,8)
    }

    func testDatedTestResultsSurviveExportRoundTrip() throws {
        var archive=SeedData.archive()
        XCTAssertTrue(archive.testResults.isEmpty)
        archive.testResults.append(FitnessTestRecord(date:zero,kind:.pushups,value:17,note:"Отдельный тест"))
        let encoder=JSONEncoder(); encoder.dateEncodingStrategy = .iso8601
        let decoder=JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
        let restored=try decoder.decode(AppArchive.self,from:encoder.encode(archive))
        XCTAssertEqual(restored.testResults.count,1)
        XCTAssertEqual(restored.testResults.last?.date,zero)
        XCTAssertEqual(restored.testResults.last?.value,17)
    }

}
