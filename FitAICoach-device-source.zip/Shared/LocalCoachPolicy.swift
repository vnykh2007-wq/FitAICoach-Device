import Foundation

/// Model output is a proposal, never a command to an active workout or HealthKit.
public enum LocalCoachPolicy {
    public static let allowedIDs = ["pushups", "squats", "birdDog", "deadBug", "bridge", "plank", "reverseCrunch", "superman", "walk", "mobility"]
    public static func context(archive: AppArchive, now: Date = Date()) -> String {
        let dates = DateFormatter(); dates.dateFormat = "dd.MM.yyyy"
        let latest = archive.history.filter { $0.endedAt != nil }.sorted { $0.startedAt > $1.startedAt }.prefix(3)
        let history = latest.map { record in
            let sets = record.exercises.filter { !$0.exercise.id.hasPrefix("warmup") && !$0.exercise.id.hasPrefix("cooldown") }.prefix(12).map { set in
                let result = set.actualRepetitions.map { "\($0) повторений" } ?? "повторения не указаны"
                return "\(set.exercise.id), подход \(set.setNumber): \(result), \(Int(set.duration)) сек\(set.skipped ? ", пропущен" : "")"
            }.joined(separator: "; ")
            return "\(dates.string(from: record.startedAt)) \(record.planName): \(Int(record.duration / 60)) мин; \(record.interrupted ? "прервано" : "завершено"); \(sets). " + SensorLoad.assess(record: record, history: archive.history).summary
        }.joined(separator: "\n")
        let plan = archive.plan.exercises.map { step in
            "\(step.exercise.id): \(step.sets) подход.; \(step.durationSeconds.map { "\($0) сек" } ?? "\(step.repetitions ?? 0) повт.")"
        }.joined(separator: "; ")
        let tests = archive.testResults.sorted { $0.date > $1.date }.prefix(4).map { "\($0.kind.title): \($0.value) \($0.kind.unit), \(dates.string(from: $0.date))" }.joined(separator: "; ")
        return String("Сегодня \(dates.string(from: now)). План: \(plan). Облегчённый: \(archive.plan.isLight). Последние записи (до 12 основных подходов каждой): \(history.isEmpty ? "нет измеренных тренировок" : history). Контрольные результаты: \(tests.isEmpty ? "не записаны" : tests). Ходьба сегодня: \(DailyActivity.walkingMinutes(archive.externalWorkouts ?? [], now: now)) мин.".prefix(6000))
    }
    public static func chatPrompt(question: String, history: [(user: Bool, text: String)], archive: AppArchive) -> String {
        let instruction = "Ты персональный тренер FitAI. Отвечай по-русски, кратко и конкретно, до 6 предложений. Учитывай только приведённые факты. Не выдумывай измерения, диагнозы, результаты или выполненные действия. Пульс сам по себе не определяет готовность. Не назначай наказание нагрузкой за пропуск. При боли и головокружении предложи прекратить занятие. Ты можешь обсуждать план, но не изменяешь его сообщением. /no_think"
        var prompt = turn("system", instruction + "\nФакты: " + context(archive: archive))
        for message in history.suffix(4) { prompt += turn(message.user ? "user" : "assistant", String(message.text.prefix(400))) }
        return prompt + turn("user", String(question.prefix(600))) + "<|im_start|>assistant\n<think>\n\n</think>\n\n"
    }
    public static func planPrompt(archive: AppArchive, recovery: Bool) -> String {
        let rules = recovery ? "Облегчённый день: только walk,mobility,birdDog,deadBug; 2-4 упражнения; 1 подход; 3-6 повторений." : "Обычный день: 4-6 разных упражнений; 1-2 подхода; 3-15 повторений."
        return turn("system", "Выбери упражнения из каталога. Верни только JSON без markdown: {\"exercises\":[{\"id\":\"squats\",\"sets\":1,\"repetitions\":8,\"durationSeconds\":null,\"restSeconds\":45}]}. \(rules) Каталог: \(allowedIDs.joined(separator: ",")). walk 180-300 секунд; mobility 60-120; plank 10-30. Для этих трёх repetitions:null; для остальных durationSeconds:null. Отдых 30-90 секунд. Разминку и заминку не включай. /no_think") + turn("user", "Предложи основной комплекс с учётом фактов: " + context(archive: archive)) + "<|im_start|>assistant\n<think>\n\n</think>\n\n"
    }
    private static func turn(_ role: String, _ text: String) -> String {
        "<|im_start|>\(role)\n" + text.replacingOccurrences(of: "<|", with: "‹").replacingOccurrences(of: "|>", with: "›") + "<|im_end|>\n"
    }
    /// Constrain the native decoder to distinct exercise groups and typed JSON.
    public static func planGrammar(archive: AppArchive, recovery: Bool) -> String {
        func literal(_ value: String) -> String { String(data: try! JSONEncoder().encode(value), encoding: .utf8)! }
        func alternatives(_ values: [Int]) -> String { values.map { literal(String($0)) }.joined(separator: " | ") }
        let groups = recovery ? [["walk", "mobility"], ["birdDog", "deadBug"]] : [["pushups", "bridge"], ["squats", "birdDog"], ["deadBug", "reverseCrunch", "plank"], ["walk", "mobility"]]
        var rules = ["root ::= " + literal("{\"exercises\":[") + " " + groups.indices.map { "group\($0)" }.joined(separator: " " + literal(",") + " ") + " " + literal("]}")]
        rules.append("sets ::= " + alternatives(recovery ? [1] : [1, 2]))
        rules.append("rest ::= " + alternatives([30, 45, 60, 90]))
        for (index, group) in groups.enumerated() {
            rules.append("group\(index) ::= " + group.map { "step-\($0)" }.joined(separator: " | "))
            for id in group {
                let volume: String
                if ["walk", "mobility", "plank"].contains(id) {
                    let durations = id == "walk" ? [180, 240, 300] : id == "mobility" ? [60, 90, 120] : [10, 15, 20, 25, 30]
                    rules.append("volume-\(id) ::= " + alternatives(durations))
                    volume = literal(",\"repetitions\":null,\"durationSeconds\":") + " volume-\(id) "
                } else {
                    let maximum = id == "pushups" && archive.profile.pushUpMaximum > 0 ? min(15, max(3, archive.profile.pushUpMaximum * 2 / 3)) : recovery ? 6 : 15
                    rules.append("volume-\(id) ::= " + alternatives(Array(3...maximum)))
                    volume = literal(",\"repetitions\":") + " volume-\(id) " + literal(",\"durationSeconds\":null") + " "
                }
                rules.append("step-\(id) ::= " + literal("{\"id\":\"\(id)\",\"sets\":") + " sets " + volume + literal(",\"restSeconds\":") + " rest " + literal("}"))
            }
        }
        return rules.joined(separator: "\n")
    }
    private struct Proposal: Decodable { var exercises: [Step] }
    private struct Step: Decodable { var id: String; var sets: Int; var repetitions: Int?; var durationSeconds: Int?; var restSeconds: Int }
    public static func validatedPlan(from output: String, archive: AppArchive, recovery: Bool) throws -> WorkoutPlan {
        guard let start = output.firstIndex(of: "{"), let end = output.lastIndex(of: "}"), start <= end,
              let data = String(output[start...end]).data(using: .utf8), data.count < 12_000,
              let proposal = try? JSONDecoder().decode(Proposal.self, from: data),
              (recovery ? 2...4 : 4...6).contains(proposal.exercises.count) else { throw ProposalError.invalid }
        var seen = Set<String>(), steps: [ExercisePlan] = []
        let recoveryIDs = ["walk", "mobility", "birdDog", "deadBug"]
        for step in proposal.exercises {
            guard allowedIDs.contains(step.id), seen.insert(step.id).inserted,
                  (!recovery || recoveryIDs.contains(step.id)),
                  (1...(recovery ? 1 : 2)).contains(step.sets), (30...90).contains(step.restSeconds) else { throw ProposalError.invalid }
            if ["walk", "mobility", "plank"].contains(step.id) {
                let range = step.id == "walk" ? 180...300 : step.id == "mobility" ? 60...120 : 10...30
                guard step.repetitions == nil, let seconds = step.durationSeconds, range.contains(seconds) else { throw ProposalError.invalid }
            } else {
                guard step.durationSeconds == nil, let reps = step.repetitions, (3...(recovery ? 6 : 15)).contains(reps) else { throw ProposalError.invalid }
                if step.id == "pushups", archive.profile.pushUpMaximum > 0, reps > max(3, archive.profile.pushUpMaximum * 2 / 3) { throw ProposalError.invalid }
            }
            steps.append(ExercisePlan(exercise: ExerciseLibrary.named(step.id), repetitions: step.repetitions, durationSeconds: step.durationSeconds, sets: step.sets, restSeconds: step.restSeconds))
        }
        let plan = WorkoutPlan(name: recovery ? "ИИ · Облегчённый комплекс" : "ИИ · Предложенный комплекс", targetMinutes: archive.settings.workoutMinutes, exercises: ExerciseLibrary.warmupSteps() + steps + ExerciseLibrary.cooldownSteps(), isLight: recovery)
        return DailyActivity.adapt(plan, workouts: archive.externalWorkouts ?? [])
    }
    public enum ProposalError: LocalizedError {
        case invalid
        public var errorDescription: String? { "Предложение модели не прошло проверку упражнений и объёма. Текущий план сохранён. Можно повторить запрос." }
    }
}
