import Foundation
import HealthKit

extension HealthService {
    func requestActivityAccess() async throws {
        guard HKHealthStore.isHealthDataAvailable() else { throw HealthServiceError.unavailable }
        try await store.requestAuthorization(toShare: [], read: [HKObjectType.workoutType()])
    }
    /// Fitness workouts are read from the local HealthKit store, never scraped from Fitness.
    func todayActivities(now: Date = Date()) async throws -> [ExternalWorkout] {
        let predicate = HKQuery.predicateForSamples(withStart: Calendar.current.startOfDay(for: now), end: now, options: [.strictStartDate])
        let workouts: [HKWorkout] = try await withCheckedThrowingContinuation { continuation in
            store.execute(HKSampleQuery(sampleType: HKObjectType.workoutType(), predicate: predicate, limit: HKObjectQueryNoLimit, sortDescriptors: nil) { _, samples, error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: samples as? [HKWorkout] ?? []) }
            })
        }
        let ownBundle = (Bundle.main.bundleIdentifier ?? "local.fitai.coach").replacingOccurrences(of: ".watchkitapp", with: "")
        return workouts.filter { $0.endDate <= now && $0.sourceRevision.source.bundleIdentifier != ownBundle && $0.sourceRevision.source.bundleIdentifier != ownBundle + ".watchkitapp" }.map { workout in
            let kind: String
            switch workout.workoutActivityType {
            case .walking: kind = "walking"
            case .running: kind = "running"
            case .cycling: kind = "cycling"
            default: kind = "other"
            }
            let indoor = (workout.metadata?[HKMetadataKeyIndoorWorkout] as? NSNumber)?.boolValue
            return ExternalWorkout(id: workout.uuid, startedAt: workout.startDate, endedAt: workout.endDate, duration: workout.duration, kind: kind, outdoor: indoor.map { !$0 }, sourceName: workout.sourceRevision.source.name)
        }
    }
    #if os(iOS)
    func launchWatchWorkout() async throws {
        let configuration = HKWorkoutConfiguration()
        configuration.activityType = .functionalStrengthTraining; configuration.locationType = .indoor
        try await store.startWatchApp(toHandle: configuration)
    }
    #endif
}
