import XCTest

final class Screenshots: XCTestCase {
    func testExistingScreens() throws {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launch()
        XCTAssertTrue(app.tabBars.buttons["Главная"].waitForExistence(timeout: 120))
        capture(app, "iPhone-Home")
        for (tab, title, file) in [
            ("Тренировка", "Тренировка", "iPhone-Workout"),
            ("Прогресс", "Мой прогресс", "iPhone-Progress")
        ] {
            app.tabBars.buttons[tab].tap()
            XCTAssertTrue(app.navigationBars[title].waitForExistence(timeout: 45))
            capture(app, file)
        }
        for (title, file) in [("AI COACH", "iPhone-Coach"), ("Настройки", "iPhone-Settings")] {
            let moreLabel = NSPredicate(format: "label == %@ OR label == %@", "Еще", "Ещё")
            let back = app.navigationBars.buttons.matching(moreLabel).firstMatch
            if back.exists { back.tap() }
            app.tabBars.buttons.matching(moreLabel).firstMatch.tap()
            let row = app.tables.staticTexts[title]
            XCTAssertTrue(row.waitForExistence(timeout: 30))
            row.tap()
            XCTAssertTrue(app.navigationBars[title].waitForExistence(timeout: 45))
            capture(app, file)
        }
        app.tabBars.buttons["Календарь"].tap()
        XCTAssertTrue(app.navigationBars["Календарь"].waitForExistence(timeout: 45))
        capture(app, "iPhone-Calendar")
    }

    private func capture(_ app: XCUIApplication, _ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
