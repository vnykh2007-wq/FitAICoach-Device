import SwiftUI
import WatchKit
import AVFoundation

@main struct FitAICoachWatchApp: App {
    @WKApplicationDelegateAdaptor(WorkoutRecoveryDelegate.self) private var delegate
    @StateObject private var model = AppModel()
    var body: some Scene {
        WindowGroup { WatchRoot().environmentObject(model).tint(.fitAccent).onReceive(NotificationCenter.default.publisher(for: .fitWorkoutRecovery)) { _ in Task { await model.health.recover() } } }
    }
}
struct WatchRoot: View {
    @EnvironmentObject var model: AppModel
    @State private var actualRepetitions = 8
    @State private var showStop = false
    @State private var notifiedReady = false
    var body: some View {
        TimelineView(.periodic(from: .now, by: 1)) { context in
            ScrollView {
                VStack(spacing: 12) {
                    if let engine = model.engine, engine.state != .finished {
                        Text(phaseLabelWatch(engine.state)).font(.caption.bold()).foregroundStyle(Color.fitAccent)
                        Text(engine.currentExercise?.exercise.name ?? "Тренировка").font(.title3.bold()).multilineTextAlignment(.center)
                        HStack {
                            Text(clockString(engine.elapsed(at: context.date))).monospacedDigit()
                            Spacer()
                            Label(model.currentHeartRate, systemImage: "heart.fill").foregroundStyle(.pink).font(.caption)
                        }
                        switch engine.state {
                        case .ready:
                            Text("Подход \(engine.setNumber)").font(.caption)
                            if let seconds = engine.currentExercise?.durationSeconds { Text("Цель: \(seconds) сек") }
                            else { Text("Цель: \(engine.currentExercise?.repetitions ?? 0) повторений") }
                            Button("Начать упражнение") { signal(.start); model.beginExercise() }.buttonStyle(.borderedProminent).foregroundStyle(.black)
                            if let exercise = engine.currentExercise?.exercise { Text(exercise.technique).font(.caption).foregroundStyle(.secondary) }
                        case .exercise:
                            Text(clockString(engine.phaseElapsed(at: context.date))).font(.system(size: 36, weight: .bold, design: .rounded)).monospacedDigit()
                            if engine.currentExercise?.repetitions != nil { Stepper("Сделано: \(actualRepetitions)", value: $actualRepetitions, in: 0...200).font(.caption) }
                            Button("Закончил") {
                                signal(.success); model.complete(reps: engine.currentExercise?.repetitions == nil ? nil : actualRepetitions)
                                if model.engine?.state == .finished { Task { await model.stop() } }
                            }.buttonStyle(.borderedProminent).foregroundStyle(.black)
                            Button("Пропустить упражнение") {
                                model.complete(reps: nil, skipped: true)
                                if model.engine?.state == .finished { Task { await model.stop() } }
                            }.font(.caption)
                        case .rest:
                            Text(clockString(engine.restRemaining(at: context.date))).font(.system(size: 38, weight: .bold, design: .rounded)).monospacedDigit()
                            Text("Следующее: \(engine.nextExercise?.exercise.name ?? "завершение")").font(.caption)
                            Button("+30 секунд отдыха") { model.extendRest(); notifiedReady = false }
                            Button("Следующий подход") { signal(.start); model.next(); notifiedReady = false }.buttonStyle(.borderedProminent).foregroundStyle(.black)
                            Text("Продолжайте, когда восстановили дыхание и чувствуете готовность. Один пульс не определяет готовность.").font(.caption2).foregroundStyle(.secondary)
                        case .paused:
                            Button("Продолжить") { model.resume() }.buttonStyle(.borderedProminent).foregroundStyle(.black)
                            Text("Таймер остановлен").font(.caption)
                        case .finished: EmptyView()
                        }
                        if engine.state != .paused { Button("Пауза") { model.pause() } }
                        Button("Завершить тренировку", role: .destructive) { showStop = true }.font(.caption)
                        Text(model.health.heartRateMessage).font(.caption2).foregroundStyle(.secondary)
                    } else if let record = model.engine?.record {
                        Text("ГОТОВО").font(.caption.bold()).foregroundStyle(Color.fitAccent)
                        Text(clockString(record.duration)).font(.largeTitle.bold())
                        Text("Подходов: \(record.exercises.count)")
                        Text("Средний пульс: \(record.statistics.average.map { String(Int($0)) } ?? "Нет данных")").font(.caption)
                        Stepper("Нагрузка: \(model.fatigue)/10", value: $model.fatigue, in: 1...10)
                        Button("Сохранить отчёт") { model.saveFatigueReport() }
                        Button("Новая тренировка") { Task { await model.start() } }.disabled(model.busy || model.archive.plan.exercises.isEmpty)
                    } else {
                        Text("FITAI COACH").font(.headline).foregroundStyle(Color.fitAccent)
                        Text(model.archive.plan.name).font(.title3.bold()).multilineTextAlignment(.center)
                        Text("Ориентир: \(model.archive.plan.targetMinutes) мин").font(.caption)
                        Text("Пульс: Нет данных до начала сессии").font(.caption2).foregroundStyle(.secondary)
                        Button("Начать тренировку") { signal(.start); Task { await model.start() } }.buttonStyle(.borderedProminent).foregroundStyle(.black).disabled(model.busy || model.archive.plan.exercises.isEmpty)
                    }
                    if !model.message.isEmpty { Text(model.message).font(.caption2).foregroundStyle(.orange); Button("Скрыть сообщение") { model.message = "" }.font(.caption2) }
                    Text(model.connectivity.status).font(.caption2).foregroundStyle(.secondary)
                }.padding(.horizontal, 4)
            }
            .onChange(of: context.date) { _, date in
                guard model.engine?.state == .rest, let remaining = model.engine?.restRemaining(at: date) else { return }
                if remaining <= 3 && !notifiedReady { signal(.notification); notifiedReady = true }
            }
        }
        .onChange(of: model.engine?.state) { _, phase in if phase == .ready { actualRepetitions = model.engine?.currentExercise?.repetitions ?? 8 } }
        .onChange(of: model.engine?.currentExercise?.id) { _, _ in actualRepetitions = model.engine?.currentExercise?.repetitions ?? 8; notifiedReady = false }
        .onChange(of: model.engine?.setNumber) { _, _ in actualRepetitions = model.engine?.currentExercise?.repetitions ?? 8; notifiedReady = false }
        .confirmationDialog("Завершить сейчас? При плохом самочувствии прекратите нагрузку.", isPresented: $showStop, titleVisibility: .visible) {
            Button("Завершить", role: .destructive) { Task { await model.stop() } }; Button("Отмена", role: .cancel) {}
        }
    }
    private func signal(_ type: WKHapticType) {
        if model.archive.settings.hapticsEnabled { WKInterfaceDevice.current().play(type) }
        if model.archive.settings.soundsEnabled { WatchCue.shared.play() }
    }
}
private func phaseLabelWatch(_ phase: WorkoutPhase) -> String {
    switch phase { case .ready: return "ГОТОВНОСТЬ"; case .exercise: return "УПРАЖНЕНИЕ"; case .rest: return "ОТДЫХ"; case .paused: return "ПАУЗА"; case .finished: return "РЕЗУЛЬТАТ" }
}

extension Notification.Name { static let fitWorkoutRecovery = Notification.Name("FitWorkoutRecovery") }
final class WorkoutRecoveryDelegate: NSObject, WKApplicationDelegate {
    func handleActiveWorkoutRecovery() { NotificationCenter.default.post(name: .fitWorkoutRecovery, object: nil) }
}
@MainActor final class WatchCue {
    static let shared = WatchCue()
    private var player: AVAudioPlayer?
    func play() {
        guard let url = Bundle.main.url(forResource: "cue", withExtension: "wav") else { return }
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try AVAudioSession.sharedInstance().setActive(true)
            player = try AVAudioPlayer(contentsOf: url); player?.volume = 0.3; player?.play()
        } catch { /* Haptics remain available when watchOS disallows audio output. */ }
    }
}
