import SwiftUI
import Combine

private struct DeviceSnapshot: Codable {
    var launchRequest: WorkoutLaunchRequest?
    var controlSchedule: ControlSchedule?
    var sourceID: UUID?
    var externalWorkouts: [ExternalWorkout]?
    var deletedWorkoutIDs: Set<UUID>?
    var engine: WorkoutEngine?
    var history: [WorkoutRecord]
    var plan: WorkoutPlan
    var settings: AppSettings
    var profile: Profile
    var calendar: [CalendarEntry]
    var testResults: [FitnessTestRecord]
    var revision: UInt64
}

@MainActor final class AppModel: ObservableObject {
    @Published var archive: AppArchive
    @Published var engine: WorkoutEngine?
    @Published var message = ""
    @Published var fatigue = 5
    @Published var sleepHours = 8.0
    @Published var useSleep = false
    @Published var busy = false
    @Published var activityStatus = "Тренировки Apple Health ещё не прочитаны"
    @Published var controlStatus = ""
    let health = HealthService()
    let connectivity = ConnectivityService()
    private let storage = JSONStore()
    private var subscriptions = Set<AnyCancellable>()
    private var localRevision: UInt64 = 0
    private var receivedRevision: UInt64 = 0
    private var storageReadable = true
    private var sourceID = UUID()
    private var receivedSourceID: UUID?
    private var launchRequest: WorkoutLaunchRequest?
    private var consumedLaunches = Set<UUID>()
    init() {
        archive = SeedData.archive()
        do {
            archive = try storage.load(AppArchive.self, name: "archive") ?? SeedData.archive()
            try storage.backupArchiveBeforeUpgrade()
            sourceID = try storage.load(UUID.self, name: "source-id") ?? UUID()
            try storage.save(sourceID, name: "source-id")
            receivedSourceID = try storage.load(UUID.self, name: "received-source-id")
            launchRequest = try storage.load(WorkoutLaunchRequest.self, name: "launch-request")
            consumedLaunches = try storage.load(Set<UUID>.self, name: "consumed-launches") ?? []
            engine = try storage.load(WorkoutEngine.self, name: "active-workout")
            localRevision = try storage.load(UInt64.self, name: "local-revision") ?? 0
            receivedRevision = try storage.load(UInt64.self, name: "received-revision") ?? 0
        } catch {
            storageReadable = false
            message = "Не удалось прочитать локальные данные. Сохранение отключено, чтобы не перезаписать исходные файлы. \(error.localizedDescription)"
        }
        health.objectWillChange.sink { [weak self] _ in self?.objectWillChange.send() }.store(in: &subscriptions)
        connectivity.objectWillChange.sink { [weak self] _ in self?.objectWillChange.send() }.store(in: &subscriptions)
        health.onHeartSample = { [weak self] date, bpm in
            guard let self else { return }
            self.engine?.addHeartRate(HeartRateSample(date: date, bpm: bpm))
            self.persist(); self.broadcast()
        }
        health.onInterrupted = { [weak self] text in
            guard let self else { return }; self.message = text
            #if os(watchOS)
            self.engine?.markInterrupted(); self.saveCurrentRecord()
            #endif
            self.persist(); self.broadcast()
        }
        health.onRecoveryUnavailable = { [weak self] in
            #if os(watchOS)
            guard let self, let engine = self.engine, engine.state != .finished else { return }
            self.engine?.pause(); self.persist(); self.broadcast()
            self.message = "Подходы восстановлены локально, но активной сессии HealthKit нет. Можно завершить тренировку или продолжить локальный учёт без пульса."
            #endif
        }
        connectivity.onReconnect = { [weak self] in self?.broadcast() }
        health.onStateChange = { [weak self] running, paused in
            #if os(watchOS)
            guard let self, running else { return }
            if self.engine?.state == .finished { Task { await self.stop() }; return }
            if paused { self.engine?.pause() }
            else if self.engine?.state == .paused { self.engine?.resume() }
            self.persist(); self.broadcast()
            #endif
        }
        health.onRemoteData = { [weak self] data in self?.receive(data) }
        connectivity.onSnapshot = { [weak self] data in self?.receive(data) }
        connectivity.onCommand = { [weak self] command in
            guard let self, let current = self.engine, command.matches(current) else { return }
            #if os(watchOS)
            guard !self.busy else { self.message = "Подождите завершения текущей операции и повторите команду."; return }
            if command.kind == "pause" { self.pause() }
            if command.kind == "resume" { self.resume() }
            if command.kind == "beginExercise" { self.beginExercise() }
            if command.kind == "completeExercise" {
                self.complete(reps: command.repetitions)
                if self.engine?.state == .finished { Task { await self.stop() } }
            }
            if command.kind == "next" { self.next() }
            if command.kind == "extendRest" { self.extendRest() }
            if command.kind == "discard" { self.discardWorkout() }
            if command.kind == "stop" { self.engine?.finish(); self.saveCurrentRecord(); self.persist(); Task { await self.stop() } }
            #endif
        }
        archive.plan = ExerciseLibrary.expandWarmup(in: archive.plan)
        if archive.controlSchedule == nil { archive.controlSchedule = ControlSchedule.initial(archive: archive) }
        TrainingCalendar.reconcile(&archive)
        WorkoutHistory.removeDeleted(from: &archive)
        persist()
        #if os(watchOS)
        Task { await health.recover() }
        #endif
    }
    func persist() {
        guard storageReadable else { return }
        do { try storage.save(archive, name: "archive"); if let engine { try storage.save(engine, name: "active-workout") } else { try storage.remove(name: "active-workout") } }
        catch { message = "Не удалось сохранить данные: \(error.localizedDescription)" }
    }
    func broadcast() {
        guard storageReadable else { return }
        localRevision += 1
        try? storage.save(localRevision, name: "local-revision")
        let packet = DeviceSnapshot(launchRequest: launchRequest, controlSchedule: archive.controlSchedule, sourceID: sourceID, externalWorkouts: archive.externalWorkouts, deletedWorkoutIDs: archive.deletedWorkoutIDs, engine: engine, history: archive.history, plan: archive.plan, settings: archive.settings, profile: archive.profile, calendar: archive.calendar, testResults: archive.testResults, revision: localRevision)
        guard let data = try? JSONEncoder().encode(packet) else { return }
        connectivity.sendSnapshot(data)
        health.sendMirrored(data)
    }
    private func receive(_ data: Data) {
        guard let packet = try? JSONDecoder().decode(DeviceSnapshot.self, from: data) else { return }
        if let origin = packet.sourceID, origin != receivedSourceID {
            receivedRevision = 0; receivedSourceID = origin
            try? storage.save(origin, name: "received-source-id")
        }
        guard packet.revision > receivedRevision else { return }
        receivedRevision = packet.revision
        try? storage.save(receivedRevision, name: "received-revision")
        WorkoutHistory.mergeDeleted(packet.deletedWorkoutIDs ?? [], into: &archive)
        #if os(iOS)
        engine = packet.engine.flatMap { (archive.deletedWorkoutIDs ?? []).contains($0.record.id) ? nil : $0 }
        controlStatus = engine?.state == .finished ? "Тренировка завершена на часах" : "Состояние получено с Apple Watch"
        ArchiveRestore.merge(AppArchive(plan: packet.plan, history: packet.history), into: &archive)
        for record in packet.history where !(archive.deletedWorkoutIDs ?? []).contains(record.id) {
            markCalendar(record) 
            saveControlResult(record)
        }
        #else
        if let request = packet.launchRequest, request.isFresh(), !consumedLaunches.contains(request.id) {
            launchRequest = request; try? storage.save(request, name: "launch-request")
        }
        if let schedule = packet.controlSchedule { archive.controlSchedule = schedule }
        ArchiveRestore.merge(AppArchive(plan: packet.plan, history: packet.history), into: &archive)
        if let activities = packet.externalWorkouts { archive.externalWorkouts = activities }
        archive.plan = ExerciseLibrary.expandWarmup(in: packet.plan); archive.settings = packet.settings; archive.profile = packet.profile
        archive.calendar = packet.calendar; archive.testResults = packet.testResults
        // The current engine owns an immutable copy of its starting plan.
        // Reapply watch results after phone calendar edits so an old phone copy
        // cannot erase today's locally completed session while offline.
        for record in archive.history where !record.dateOnly { markCalendar(record); saveControlResult(record) }
        WorkoutHistory.removeDeleted(from: &archive)
        if let current = engine, current.state == .finished, !busy, (archive.deletedWorkoutIDs ?? []).contains(current.record.id) { engine = nil }
        #endif
        persist()
    }
    func preparePlan() {
        let measuredFatigue = archive.history.sorted { $0.startedAt > $1.startedAt }.first.map {
            SensorLoad.assess(record: $0, history: archive.history).higherThanUsual ? 7 : 5
        } ?? 5
        let plan = CoachEngine.makePlan(archive: archive, fatigue: measuredFatigue, sleepHours: useSleep ? sleepHours : nil)
        archive.plan = DailyActivity.adapt(plan, workouts: archive.externalWorkouts ?? [])
        archive.dailyPlanDate = Date()
        persist(); broadcast()
    }
    func refreshDay() {
        TrainingCalendar.reconcile(&archive)
        if (archive.settings.dailyVariationEnabled ?? true), !(archive.dailyPlanDate.map { Calendar.current.isDateInToday($0) } ?? false) { preparePlan() }
        else { persist(); broadcast() }
    }
    func startFromPhone() async {
        #if os(watchOS)
        for _ in 0..<50 {
            if let request = launchRequest, request.isFresh(), !consumedLaunches.contains(request.id) {
                let old = engine?.record.id
                await start(controlTest: request.kind)
                if engine?.record.id != old {
                    consumedLaunches.insert(request.id); try? storage.save(consumedLaunches, name: "consumed-launches")
                }
                return
            }
            try? await Task.sleep(nanoseconds: 100_000_000)
        }
        message = "Запрос запуска ещё не доставлен. Откройте приложение на iPhone и повторите выбор тренировки или теста."
        #endif
    }
    func start(controlTest: FitnessTestKind? = nil) async {
        #if os(watchOS)
        guard storageReadable else { message = "Нельзя начать тренировку: локальное хранилище недоступно. Сначала восстановите сохранение данных."; return }
        guard !busy, engine == nil || engine?.state == .finished else { return }
        busy = true; defer { busy = false }
        refreshDay()
        for _ in 0..<20 where health.isRecovering { try? await Task.sleep(nanoseconds: 250_000_000) }
        guard !health.isRecovering else { message = "Восстановление сессии ещё идёт. Повторите запуск через несколько секунд."; return }
        do { try health.prepareForNewWorkout() }
        catch { message = "Предыдущая сессия HealthKit ещё активна. Сначала завершите её."; return }
        do { try await health.requestAuthorization() }
        catch { message = "HealthKit недоступен: \(error.localizedDescription). Учёт доступен без пульса." }
        await refreshActivities(requestPermission: false)
        let measuredFatigue = archive.history.sorted { $0.startedAt > $1.startedAt }.first.map { SensorLoad.assess(record: $0, history: archive.history).higherThanUsual ? 7 : 5 } ?? 5
        let recoveryPlan = CoachEngine.makePlan(archive: archive, fatigue: measuredFatigue, sleepHours: useSleep ? sleepHours : nil)
        let sessionPlan = controlTest?.plan() ?? DailyActivity.adapt(recoveryPlan.isLight ? recoveryPlan : archive.plan, workouts: archive.externalWorkouts ?? [])
        engine = WorkoutEngine(plan: sessionPlan); persist()
        do { try await health.start() }
        catch { message = "HealthKit недоступен: \(error.localizedDescription). Учёт упражнений доступен без пульса." }
        engine?.startExercise(); persist()
        broadcast()
        #else
        guard !busy else { return }
        if let current = engine, current.state != .finished { controlStatus = "Тренировка уже идёт на часах"; broadcast(); return }
        busy = true; defer { busy = false }
        do {
            await refreshActivities(requestPermission: false)
            refreshDay()
            launchRequest = WorkoutLaunchRequest(kind: controlTest)
            try? storage.save(launchRequest, name: "launch-request")
            broadcast()
            try await health.launchWatchWorkout()
            controlStatus = "Запуск отправлен на часы. Ожидаем подтверждение и состояние тренировки."
        } catch { message = "Не удалось запустить часы: \(error.localizedDescription). Проверьте связь, разблокируйте часы и откройте FitAI Coach." }
        #endif
    }
    private func sendControl(_ kind: String, repetitions: Int? = nil) {
        guard let engine else { return }
        connectivity.sendCommand(kind: kind, workoutID: engine.record.id, exerciseID: engine.currentExercise?.id, setNumber: engine.setNumber, expectedPhase: engine.state, repetitions: repetitions)
        controlStatus = "Команда отправлена. Ожидаем подтверждение с часов."
    }
    func beginExercise() {
        #if os(watchOS)
        engine?.startExercise(); changed()
        #else
        sendControl("beginExercise")
        #endif
    }
    func complete(reps: Int?, skipped: Bool = false) {
        #if os(watchOS)
        if !skipped, engine?.record.controlTestKind?.timedMinute == true, (engine?.phaseElapsed() ?? 0) < 60 {
            message = "Минутный тест ещё идёт. Для результата нужно 60 секунд; прервать можно кнопкой завершения тренировки."; return
        }
        engine?.finishExercise(actualRepetitions: reps, skipped: skipped); changed()
        #else
        sendControl("completeExercise", repetitions: reps)
        #endif
    }
    func next() {
        #if os(watchOS)
        engine?.startNext(); engine?.startExercise(); changed()
        #else
        sendControl("next")
        #endif
    }
    func extendRest() {
        #if os(watchOS)
        engine?.extendRest(); changed()
        #else
        sendControl("extendRest")
        #endif
    }
    var sensorSummary: String {
        if let engine, engine.state != .finished { return SensorLoad.assess(record: engine.record, history: archive.history, live: true).summary }
        guard let record = archive.history.filter({ !$0.dateOnly }).max(by: { $0.startedAt < $1.startedAt }) else { return "Начните тренировку на часах, чтобы получить реальные измерения нагрузки." }
        return SensorLoad.assess(record: record, history: archive.history).summary
    }
    func refreshActivities(requestPermission: Bool = true) async {
        do {
            if requestPermission { try await health.requestActivityAccess() }
            let own = Set(archive.history.compactMap(\.healthWorkoutID))
            archive.externalWorkouts = try await health.todayActivities().filter { !own.contains($0.id) }
            let todayCount = (archive.externalWorkouts ?? []).filter { Calendar.current.isDateInToday($0.startedAt) }.count
            activityStatus = "Прочитано тренировок сегодня: \(todayCount). Ходьба: \(DailyActivity.walkingMinutes(archive.externalWorkouts ?? [])) мин. Для календаря читаются последние 90 дней. Пустой результат также возможен без доступа к чтению."
            changed()
        } catch { activityStatus = "Не удалось прочитать тренировки Apple Health: \(error.localizedDescription)" }
    }
    func restoreArchive(from url: URL) {
        guard storageReadable, engine == nil || engine?.state == .finished else { message = "Сначала завершите текущую тренировку."; return }
        let scoped = url.startAccessingSecurityScopedResource(); defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        do {
            let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
            let restored = try decoder.decode(AppArchive.self, from: Data(contentsOf: url))
            try storage.backupArchiveBeforeUpgrade()
            ArchiveRestore.merge(restored, into: &archive); changed()
            message = "История восстановлена из JSON без удаления имеющихся тренировок."
        } catch { message = "Импорт не выполнен; история сохранена: \(error.localizedDescription)" }
    }
    func pause() {
        #if os(watchOS)
        engine?.pause(); health.pause(); changed()
        #else
        sendControl("pause")
        #endif
    }
    func resume() {
        #if os(watchOS)
        engine?.resume(); health.resume(); changed()
        #else
        sendControl("resume")
        #endif
    }
    func stop() async {
        #if os(watchOS)
        guard !busy, engine != nil else { return }; busy = true; defer { busy = false }
        engine?.finish()
        saveCurrentRecord(); persist(); broadcast()
        if engine?.record.healthWorkoutID == nil {
            do { if let id = try await health.finish() { engine?.setHealthWorkoutID(id) }; engine?.setActiveCalories(health.activeEnergy) }
            catch { message = "История сохранена локально. Apple Health: \(error.localizedDescription)" }
        }
        saveCurrentRecord(); persist(); broadcast()
        #else
        sendControl("stop")
        #endif
    }
    private func saveCurrentRecord() {
        guard let record = engine?.record, !(archive.deletedWorkoutIDs ?? []).contains(record.id) else { return }
        archive.history.removeAll { $0.id == record.id }; archive.history.append(record); markCalendar(record)
        saveControlResult(record)
    }
    private func saveControlResult(_ record: WorkoutRecord) {
        guard let result = ControlTests.result(from: record), !archive.testResults.contains(where: { $0.id == result.id }) else { return }
        archive.testResults.append(result)
        if result.kind == .pushups { archive.profile.pushUpMaximum = max(archive.profile.pushUpMaximum, result.value) }
        if result.kind == .plank { archive.profile.plankMaximumSeconds = max(archive.profile.plankMaximumSeconds, result.value) }
        let interval = archive.controlSchedule?.intervalDays ?? 7
        archive.controlSchedule = ControlSchedule(nextDate: Calendar.current.date(byAdding: .day, value: interval, to: record.startedAt) ?? Date(), intervalDays: interval)
    }
    private func markCalendar(_ record: WorkoutRecord) {
        guard record.endedAt != nil else { return }
        archive.calendar.removeAll { Calendar.current.isDate($0.date, inSameDayAs: record.startedAt) }
        archive.calendar.append(CalendarEntry(date: record.startedAt, status: record.isLight ? .light : .completed, reason: record.interrupted ? "Тренировка прервана; сохранены доступные результаты" : "", workoutID: record.id))
    }
    func deleteWorkout(_ id: UUID) {
        guard engine?.record.id != id || engine?.state == .finished else {
            message = "Для текущей тренировки выберите «Отменить без сохранения»."; return
        }
        guard !busy else { return }
        WorkoutHistory.delete(id, from: &archive)
        if engine?.record.id == id { engine = nil }
        changed()
        message = "Запись удалена из FitAI Coach. Уже сохранённую запись Apple Health можно удалить отдельно в «Здоровье»."
    }
    func discardWorkout() {
        guard !busy, let current = engine, current.state != .finished else { return }
        #if os(watchOS)
        WorkoutHistory.delete(current.record.id, from: &archive)
        engine = nil; health.discard(); changed()
        message = "Случайная тренировка отменена без сохранения."
        #else
        connectivity.sendCommand(kind: "discard", workoutID: current.record.id)
        message = "Отмена отправлена на часы. При отсутствии связи отмените тренировку на часах."
        #endif
    }
    func saveFatigueReport() { engine?.setFatigue(fatigue); saveCurrentRecord(); persist(); broadcast(); message = "Отчёт сохранён" }
    func changed() { persist(); broadcast() }
    var currentHeartRate: String {
        #if os(iOS)
        guard let sample = engine?.record.heartRate.last, Date().timeIntervalSince(sample.date) < 30 else { return "Нет данных" }
        return "\(Int(sample.bpm)) уд/мин"
        #else
        guard let value = health.currentHeartRate else { return "Нет данных" }
        return "\(Int(value)) уд/мин"
        #endif
    }
    func deleteLocalData() {
        storageReadable = true
        archive = AppArchive(plan: WorkoutPlan(name: "Новая программа", exercises: [])); archive.profile.pushUpMaximum = 0; archive.profile.plankMaximumSeconds = 0
        archive.profile.age = 0; archive.profile.heightCM = 0; archive.profile.weightKG = 0
        connectivity.clearLocalData(); try? storage.remove(name: "chat")
        for name in ["FitAI-history.json", "FitAI-exercises.csv"] {
            try? FileManager.default.removeItem(at: FileManager.default.temporaryDirectory.appendingPathComponent(name))
        }
        engine = nil; persist()
        message = "Локальная история удалена. Записи Apple Health и данные другого устройства не удалены."
    }
    func exportCSV() -> URL? {
        func cell(_ value: String) -> String { "\"" + value.replacingOccurrences(of: "\"", with: "\"\"") + "\"" }
        var rows = ["workout_id,start,exercise,set,planned_reps,actual_reps,duration_seconds,average_hr,max_hr"]
        for workout in archive.history {
            for exercise in workout.exercises {
                let statistics = exercise.statistics
                var fields: [String] = []
                fields.append(workout.id.uuidString)
                fields.append(ISO8601DateFormatter().string(from: exercise.startedAt))
                fields.append(exercise.exercise.name)
                fields.append(String(exercise.setNumber))
                fields.append(exercise.plannedRepetitions.map { String($0) } ?? "")
                fields.append(exercise.actualRepetitions.map { String($0) } ?? "")
                fields.append(String(exercise.duration))
                fields.append(statistics.average.map { String($0) } ?? "")
                fields.append(statistics.maximum.map { String($0) } ?? "")
                rows.append(fields.map(cell).joined(separator: ","))
            }
        }
        do { let url = FileManager.default.temporaryDirectory.appendingPathComponent("FitAI-exercises.csv"); try rows.joined(separator: "\n").write(to: url, atomically: true, encoding: .utf8); return url }
        catch { message = error.localizedDescription; return nil }
    }
    func exportJSON() -> URL? {
        do {
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("FitAI-history.json")
            let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]; encoder.dateEncodingStrategy = .iso8601
            try encoder.encode(archive).write(to: url, options: .atomic); return url
        } catch { message = error.localizedDescription; return nil }
    }
}
