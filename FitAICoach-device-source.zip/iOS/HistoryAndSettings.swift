import SwiftUI
import Charts
import UniformTypeIdentifiers

struct ProgressViewScreen: View {
    @EnvironmentObject var model: AppModel
    @State private var period = 30
    @State private var resultKind: FitnessTestKind = .pushups
    @State private var pendingDeletion: WorkoutRecord?
    private var records: [WorkoutRecord] {
        model.archive.history.filter { period == 0 || $0.startedAt >= Calendar.current.date(byAdding: .day, value: -period, to: Date())! }.sorted { $0.startedAt < $1.startedAt }
    }
    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                Picker("Период", selection: $period) { Text("Неделя").tag(7); Text("Месяц").tag(30); Text("Всё").tag(0) }.pickerStyle(.segmented)
                FitCard {
                    HStack { Metric(title: "Тренировки", value: "\(records.count)", symbol: "checkmark.seal"); Metric(title: "Время", value: "\(Int(records.reduce(0) { $0 + $1.duration } / 60)) мин", symbol: "clock") }
                    HStack { Metric(title: "Тест отжиманий", value: "\(model.archive.profile.pushUpMaximum)", symbol: "figure.strengthtraining.traditional"); Metric(title: "Тест планки", value: "\(model.archive.profile.plankMaximumSeconds) сек", symbol: "timer") }
                    Text("Запишите отдельные контрольные тесты в настройках. Результаты обычных подходов не считаются тестом максимума.").font(.caption).foregroundStyle(.secondary)
                    let loads = records.compactMap(\.fatigue)
                    Text("Средняя нагрузка: \(loads.isEmpty ? "Нет данных" : String(format: "%.1f/10", Double(loads.reduce(0,+))/Double(loads.count)))")
                    Text("Пропусков: \(model.archive.calendar.filter { $0.status == .missed }.count)")
                }
                FitCard {
                    Text("Повторения по подходам").font(.headline)
                    let rows = records.flatMap(\.exercises).filter { !$0.skipped && $0.actualRepetitions != nil }
                    if rows.isEmpty { Text("Нет записанных подходов. Исходная тренировка не содержит подробных данных упражнений.").foregroundStyle(.secondary) }
                    else { Chart(rows) { row in PointMark(x: .value("Дата", row.startedAt), y: .value("Повторения", row.actualRepetitions ?? 0)).foregroundStyle(by: .value("Упражнение", row.exercise.name)) }.frame(height: 190) }
                    Text("Подходы разной техники и объёма напрямую несопоставимы.").font(.caption).foregroundStyle(.secondary)
                }
                FitCard {
                    Text("Контрольные тесты").font(.headline)
                    Picker("Показатель", selection: $resultKind) { ForEach(FitnessTestKind.allCases, id: \.self) { Text($0.title).tag($0) } }.pickerStyle(.menu)
                    let tests = model.archive.testResults.filter { $0.kind == resultKind && (period == 0 || $0.date >= Calendar.current.date(byAdding: .day, value: -period, to: Date())!) }.sorted { $0.date < $1.date }
                    if tests.isEmpty { Text("Нет результатов в выбранном периоде.").foregroundStyle(.secondary) }
                    else {
                        Chart(tests) { test in
                            PointMark(x: .value("Дата", test.date), y: .value(resultKind.countsRepetitions ? "Повторения" : "Секунды", test.value)).foregroundStyle(Color.fitAccent)
                            LineMark(x: .value("Дата", test.date), y: .value(resultKind.countsRepetitions ? "Повторения" : "Секунды", test.value)).foregroundStyle(Color.fitAccent.opacity(0.5))
                        }.frame(height: 150)
                    }
                    Text("Максимальные тесты отделены от обычных подходов. Не проводите тест ежедневно.").font(.caption).foregroundStyle(.secondary)
                }
                FitCard {
                    Text("Контрольные тесты").font(.headline)
                    NavigationLink("Выбрать и сдать тест") { ControlTestsScreen() }
                    ForEach(model.archive.testResults.sorted { $0.date > $1.date }) { test in
                        Text("\(test.date.formatted(date: .abbreviated, time: .omitted)) · \(test.kind.title) · \(test.value) \(test.kind.unit)").font(.caption)
                    }
                }
                FitCard {
                    Text("Достижения").font(.headline)
                    achievement("Первая тренировка", earned: model.archive.history.count >= 1)
                    achievement("3 завершённые тренировки", earned: model.archive.history.filter { !$0.interrupted }.count >= 3)
                    let days = Set(model.archive.calendar.filter { $0.status != .missed }.map { Calendar.current.startOfDay(for: $0.date) })
                    achievement("7 дней регулярной активности", earned: hasConsecutiveDays(days, count: 7))
                    achievement("Новый рекорд отжиманий", earned: model.archive.testResults.filter { $0.kind == .pushups }.count > 1 && model.archive.profile.pushUpMaximum > (model.archive.testResults.first { $0.kind == .pushups }?.value ?? 0))
                    achievement("Новый рекорд планки", earned: model.archive.testResults.filter { $0.kind == .plank }.count > 1 && model.archive.profile.plankMaximumSeconds > (model.archive.testResults.first { $0.kind == .plank }?.value ?? 0))
                    achievement("Первый месяц активности", earned: hasConsecutiveDays(days, count: 30))
                }
                ForEach(records.reversed()) { record in
                    FitCard {
                        NavigationLink { WorkoutDetail(record: record) } label: {
                            VStack(alignment: .leading) {
                            Text(record.startedAt.formatted(date: .abbreviated, time: record.dateOnly ? .omitted : .shortened)).font(.headline)
                            Text("\(record.planName) · \(clockString(record.duration))").foregroundStyle(.secondary)
                            }
                        }
                        .buttonStyle(.plain)
                        Button("Удалить тренировку", role: .destructive) { pendingDeletion = record }.disabled(model.busy)
                    }
                }
            }.padding()
        }.navigationTitle("Мой прогресс")
        .confirmationDialog("Удалить эту тренировку из FitAI Coach?", isPresented: Binding(get: { pendingDeletion != nil }, set: { if !$0 { pendingDeletion = nil } }), titleVisibility: .visible) {
            Button("Удалить тренировку", role: .destructive) { if let record = pendingDeletion { model.deleteWorkout(record.id) }; pendingDeletion = nil }
            Button("Отмена", role: .cancel) { pendingDeletion = nil }
        } message: { Text("Запись исчезнет из истории и статистики приложения на телефоне и часах после синхронизации. Сохранённая запись Apple Health останется.") }
    }
    private func achievement(_ name: String, earned: Bool) -> some View { Label(name, systemImage: earned ? "checkmark.seal.fill" : "circle.dashed").foregroundStyle(earned ? Color.fitAccent : Color.secondary) }
    private func hasConsecutiveDays(_ days: Set<Date>, count: Int) -> Bool {
        days.contains { start in (0..<count).allSatisfy { offset in
            guard let day = Calendar.current.date(byAdding: .day, value: offset, to: start) else { return false }; return days.contains(day)
        } }
    }
}
struct WorkoutDetail: View {
    @EnvironmentObject var model: AppModel
    @Environment(\.dismiss) private var dismiss
    @State private var confirmDelete = false
    var record: WorkoutRecord
    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                FitCard {
                    Text(record.planName).font(.title2.bold())
                    Text("Время: \(clockString(record.duration))")
                    Text("Активная энергия: \(record.activeCalories.map { "\(Int($0)) ккал" } ?? "Нет данных")")
                    if let reported = record.reportedAverageHeartRate { Text("Пульс со слов пользователя: \(Int(reported)) уд/мин. Исходные измерения отсутствуют.").font(.caption).foregroundStyle(.secondary) }
                }
                HeartChart(samples: record.heartRate)
                ForEach(record.exercises) { ExerciseRecordRow(record: $0) }
                ForEach(record.rests) { rest in
                    FitCard { Text("Отдых · \(clockString(rest.duration))"); Text("Средний пульс: \(rest.statistics.average.map { String(Int($0)) } ?? "Нет данных")").font(.caption) }
                }
                Button("Удалить тренировку", role: .destructive) { confirmDelete = true }.disabled(model.busy)
            }.padding()
        }.navigationTitle("Результаты")
        .confirmationDialog("Удалить тренировку из FitAI Coach?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Удалить", role: .destructive) { model.deleteWorkout(record.id); dismiss() }
            Button("Отмена", role: .cancel) {}
        } message: { Text("Сохранённая запись Apple Health останется. Удаление синхронизируется с часами.") }
    }
}
struct ChatMessage: Identifiable, Codable { var id = UUID(); var text: String; var fromUser: Bool }
struct CoachChatView: View {
    @EnvironmentObject var model: AppModel
    @State private var messages: [ChatMessage] = []
    @State private var text = ""
    private let store = JSONStore()
    var body: some View {
        VStack {
            Text("Умный тренер на основе правил · без нейросети и сервера").font(.caption).foregroundStyle(.secondary).padding(.horizontal)
            ScrollViewReader { proxy in
                ScrollView { LazyVStack(alignment: .leading, spacing: 12) {
                    ForEach(messages) { message in
                        Text(message.text).padding().background(message.fromUser ? Color.fitAccent.opacity(0.14) : Color.fitCard, in: RoundedRectangle(cornerRadius: 16)).frame(maxWidth: .infinity, alignment: message.fromUser ? .trailing : .leading).id(message.id)
                    }
                }.padding() }.onChange(of: messages.count) { _, _ in if let id = messages.last?.id { proxy.scrollTo(id, anchor: .bottom) } }
            }
            HStack { TextField("Усталость, боль, прогресс, пропуск…", text: $text).textFieldStyle(.roundedBorder).onSubmit(send)
                Button(action: send) { Image(systemName: "arrow.up.circle.fill").font(.title) }.disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }.padding()
        }.navigationTitle("AI COACH")
        .onAppear { messages = (try? store.load([ChatMessage].self, name: "chat")) ?? [ChatMessage(text: "План важнее настроения. Укажи самочувствие и начни посильную тренировку. При боли прекращай нагрузку. Я понимаю вопросы об усталости, следующем упражнении, прогрессе и пропусках.", fromUser: false)] }
    }
    private func send() {
        let value = text.trimmingCharacters(in: .whitespacesAndNewlines); guard !value.isEmpty else { return }
        messages.append(ChatMessage(text: value, fromUser: true))
        messages.append(ChatMessage(text: CoachEngine.reply(to: value, archive: model.archive), fromUser: false))
        text = ""; try? store.save(messages, name: "chat")
    }
}
struct SettingsView: View {
    @EnvironmentObject var model: AppModel
    @State private var confirmDelete = false
    @State private var exportURL: URL?
    @State private var showImport = false
    var body: some View {
        Form {
            Section("Профиль") {
                if model.archive.profile.age == 0 {
                    Text("Профиль очищен. Заполните данные перед использованием.").font(.caption)
                    Button("Начать заполнение профиля") {
                        model.archive.profile.age = 18; model.archive.profile.heightCM = 170; model.archive.profile.weightKG = 70
                        model.changed()
                    }
                }
                Stepper("Возраст: \(model.archive.profile.age)", value: $model.archive.profile.age, in: 18...100)
                Stepper("Рост: \(model.archive.profile.heightCM) см", value: $model.archive.profile.heightCM, in: 100...230)
                Stepper("Вес: \(model.archive.profile.weightKG, specifier: "%.1f") кг", value: $model.archive.profile.weightKG, in: 30...250, step: 0.5)
            }
            Section("Контрольные тесты") {
                NavigationLink("Выбрать тест и запустить на часах") { ControlTestsScreen() }
            }
            Section("Сигналы") {
                Toggle("Разные комплексы по дням", isOn: Binding(get: { model.archive.settings.dailyVariationEnabled ?? true }, set: { model.archive.settings.dailyVariationEnabled = $0; model.preparePlan() }))
                Toggle("Вибрация на часах", isOn: $model.archive.settings.hapticsEnabled)
                Toggle("Звуки на часах", isOn: $model.archive.settings.soundsEnabled)
                Stepper("Длительность плана: \(model.archive.settings.workoutMinutes) мин", value: $model.archive.settings.workoutMinutes, in: 5...90, step: 5)
            }
            Section("Apple Health") {
                Button("Учесть другие тренировки сегодня") { Task { await model.refreshActivities(); model.preparePlan() } }
                Text(model.activityStatus).font(.caption)
                Button("Прочитать продолжительность сна") { Task {
                    do { try await model.health.requestSleepAccess(); if let hours = try await model.health.recentSleepHours() { model.sleepHours = hours; model.useSleep = true; model.message = "Доступный сон: \(String(format: "%.1f", hours)) ч. Проверьте значение на главной перед адаптацией плана." } else { model.message = "Данные сна не доступны. Можно указать продолжительность вручную." } }
                    catch { model.message = error.localizedDescription }
                } }
                Button("Запросить разрешения") { Task { do { try await model.health.requestAuthorization() } catch { model.message = error.localizedDescription } } }
                Text(model.health.status).font(.caption)
                Text("Отсутствие измерений не доказывает отказ в доступе. Пульс поступает с часов во время сессии; контакт с кожей приложение достоверно не определяет.").font(.caption)
            }
            Section("Данные") {
                Text("Перед обновлением сохраните JSON через «Поделиться экспортом» в «Файлы». Он содержит все подходы, пульс и даты. Новая версия читает старую историю и создаёт локальную копию до преобразования.").font(.caption)
                Button("Восстановить историю из JSON") { showImport = true }
                Button("Подготовить JSON") { exportURL = model.exportJSON() }
                Button("Подготовить CSV") { exportURL = model.exportCSV() }
                if let exportURL { ShareLink(item: exportURL) { Label("Поделиться экспортом", systemImage: "square.and.arrow.up") } }
                Button("Удалить локальные данные", role: .destructive) { confirmDelete = true }.disabled(model.engine != nil && model.engine?.state != .finished)
                Text("Удаление действует только на этом устройстве. Историю в Apple Health удаляют отдельно в приложении «Здоровье»; другое устройство может вернуть свою копию при синхронизации.").font(.caption)
            }
            Section { Text("FitAI Coach не является медицинским прибором. При острой боли, головокружении, тошноте или выраженной слабости прекратите нагрузку и при необходимости обратитесь за медицинской помощью.").font(.caption) }
        }.navigationTitle("Настройки").onDisappear { model.changed() }
        .fileImporter(isPresented: $showImport, allowedContentTypes: [.json]) { result in
            switch result { case .success(let url): model.restoreArchive(from: url); case .failure(let error): model.message = error.localizedDescription }
        }
        .onChange(of: model.archive.settings) { _, _ in model.changed() }
        .onChange(of: model.archive.profile) { _, _ in model.changed() }
        .confirmationDialog("Удалить локальную историю и настройки?", isPresented: $confirmDelete, titleVisibility: .visible) { Button("Удалить", role: .destructive) { model.deleteLocalData() }; Button("Отмена", role: .cancel) {} }
    }
}
