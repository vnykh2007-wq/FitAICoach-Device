"""Generate a minimal checked-in Xcode project on Windows, using only Python.

XcodeGen project.yml is the authoritative macOS/CI generator. This fallback
uses the same source directories and bundle IDs, with no signing credentials.
Run again after adding/removing Swift sources. It does not compile anything.
"""
from pathlib import Path
import hashlib
import json
import plistlib

ROOT = Path(__file__).resolve().parents[1]
objects = {}

def uid(key):
    return hashlib.sha256(key.encode()).hexdigest()[:24].upper()

def add(key, isa, **fields):
    ident = uid(key)
    objects[ident] = dict(isa=isa, **fields)
    return ident

class Ref(str):
    pass

def ref(key):
    return Ref(uid(key))

def render(value):
    if isinstance(value, Ref):
        return str(value)
    if isinstance(value, dict):
        return '{\n' + '\n'.join(f'{json.dumps(k)} = {render(v)};' for k, v in value.items()) + '\n}'
    if isinstance(value, list):
        return '(' + ', '.join(render(v) for v in value) + ')'
    if isinstance(value, int):
        return str(value)
    return json.dumps(str(value), ensure_ascii=False)

sources = sorted(ROOT.glob('Shared/*.swift')) + sorted(ROOT.glob('Platform/*.swift')) + sorted(ROOT.glob('UIShared/*.swift'))
all_files = sources + sorted(ROOT.glob('iOS/*.swift')) + sorted(ROOT.glob('Watch/*.swift'))
for file in all_files:
    rel = file.relative_to(ROOT).as_posix()
    add('file:' + rel, 'PBXFileReference', lastKnownFileType='sourcecode.swift', path=rel, sourceTree='<group>')
add('file:Watch/cue.wav', 'PBXFileReference', lastKnownFileType='audio.wav', path='Watch/cue.wav', sourceTree='<group>')
add('watch-cue-resource', 'PBXBuildFile', fileRef=ref('file:Watch/cue.wav'))
for directory in ['iOS', 'Watch']:
    add('assets:' + directory, 'PBXFileReference', lastKnownFileType='folder.assetcatalog', path=directory + '/Assets.xcassets', sourceTree='<group>')
    add('assets-resource:' + directory, 'PBXBuildFile', fileRef=ref('assets:' + directory))

common = dict(SWIFT_VERSION='5.9', CODE_SIGN_STYLE='Automatic', DEVELOPMENT_TEAM='', MARKETING_VERSION='1.2.0', CURRENT_PROJECT_VERSION='3', ASSETCATALOG_COMPILER_APPICON_NAME='AppIcon', CLANG_ENABLE_MODULES='YES', SWIFT_STRICT_CONCURRENCY='minimal')
project_configs = []
for config in ['Debug', 'Release']:
    settings = dict(common, SWIFT_OPTIMIZATION_LEVEL='-Onone' if config == 'Debug' else '-O')
    if config == 'Debug':
        settings['SWIFT_ACTIVE_COMPILATION_CONDITIONS'] = 'DEBUG'
    add('project-config:' + config, 'XCBuildConfiguration', buildSettings=settings, name=config)
    project_configs.append(ref('project-config:' + config))
add('project-configs', 'XCConfigurationList', buildConfigurations=project_configs, defaultConfigurationIsVisible=0, defaultConfigurationName='Release')

for name, platform, directory in [('FitAICoach', 'iOS', 'iOS'), ('FitAICoachWatch', 'watchOS', 'Watch')]:
    target_sources = sources + sorted(ROOT.glob(directory + '/*.swift'))
    build_files = []
    for file in target_sources:
        rel = file.relative_to(ROOT).as_posix()
        key = f'build:{name}:{rel}'
        add(key, 'PBXBuildFile', fileRef=ref('file:' + rel))
        build_files.append(ref(key))
    add('sources:' + name, 'PBXSourcesBuildPhase', buildActionMask=2147483647, files=build_files, runOnlyForDeploymentPostprocessing=0)
    add('frameworks:' + name, 'PBXFrameworksBuildPhase', buildActionMask=2147483647, files=[], runOnlyForDeploymentPostprocessing=0)
    add('resources:' + name, 'PBXResourcesBuildPhase', buildActionMask=2147483647, files=[ref('assets-resource:' + directory)] + ([ref('watch-cue-resource')] if platform == 'watchOS' else []), runOnlyForDeploymentPostprocessing=0)
    add('product:' + name, 'PBXFileReference', explicitFileType='wrapper.application', includeInIndex=0, path=name + '.app', sourceTree='BUILT_PRODUCTS_DIR')
    configs = []
    for config in ['Debug', 'Release']:
        watch = platform == 'watchOS'
        settings = dict(common,
            PRODUCT_NAME='$(TARGET_NAME)',
            PRODUCT_BUNDLE_IDENTIFIER='local.fitai.coach.watchkitapp' if watch else 'local.fitai.coach',
            INFOPLIST_FILE='Config/' + directory + '-Info.plist',
            CODE_SIGN_ENTITLEMENTS='Config/' + directory + '.entitlements',
            GENERATE_INFOPLIST_FILE='NO',
            SDKROOT='watchos' if watch else 'iphoneos',
            SUPPORTED_PLATFORMS='watchos watchsimulator' if watch else 'iphoneos iphonesimulator',
            TARGETED_DEVICE_FAMILY='4' if watch else '1',
            LD_RUNPATH_SEARCH_PATHS='$(inherited) @executable_path/Frameworks',
            SWIFT_EMIT_LOC_STRINGS='YES',
        )
        settings['WATCHOS_DEPLOYMENT_TARGET' if watch else 'IPHONEOS_DEPLOYMENT_TARGET'] = '10.0' if watch else '17.0'
        add(f'config:{name}:{config}', 'XCBuildConfiguration', buildSettings=settings, name=config)
        configs.append(ref(f'config:{name}:{config}'))
    add('configs:' + name, 'XCConfigurationList', buildConfigurations=configs, defaultConfigurationIsVisible=0, defaultConfigurationName='Release')
    phases = [ref('sources:' + name), ref('frameworks:' + name), ref('resources:' + name)]
    dependencies = []
    if platform == 'iOS':
        add('embed-watch-file', 'PBXBuildFile', fileRef=ref('product:FitAICoachWatch'), settings={'ATTRIBUTES': ['RemoveHeadersOnCopy']})
        add('embed-watch', 'PBXCopyFilesBuildPhase', buildActionMask=2147483647, dstPath='$(CONTENTS_FOLDER_PATH)/Watch', dstSubfolderSpec=16, files=[ref('embed-watch-file')], name='Embed Watch Content', runOnlyForDeploymentPostprocessing=0)
        add('watch-proxy', 'PBXContainerItemProxy', containerPortal=ref('project'), proxyType=1, remoteGlobalIDString=ref('target:FitAICoachWatch'), remoteInfo='FitAICoachWatch')
        add('watch-dependency', 'PBXTargetDependency', target=ref('target:FitAICoachWatch'), targetProxy=ref('watch-proxy'))
        phases.append(ref('embed-watch'))
        dependencies.append(ref('watch-dependency'))
    add('target:' + name, 'PBXNativeTarget', buildConfigurationList=ref('configs:' + name), buildPhases=phases, buildRules=[], dependencies=dependencies, name=name, productName=name, productReference=ref('product:' + name), productType='com.apple.product-type.application')

add('products', 'PBXGroup', children=[ref('product:FitAICoach'), ref('product:FitAICoachWatch')], name='Products', sourceTree='<group>')
add('root', 'PBXGroup', children=[ref('file:' + f.relative_to(ROOT).as_posix()) for f in all_files] + [ref('file:Watch/cue.wav'), ref('assets:iOS'), ref('assets:Watch'), ref('products')], sourceTree='<group>')
add('project', 'PBXProject', attributes={'LastUpgradeCheck': '2620', 'BuildIndependentTargetsInParallel': 'YES'}, buildConfigurationList=ref('project-configs'), compatibilityVersion='Xcode 14.0', developmentRegion='ru', hasScannedForEncodings=0, knownRegions=['ru', 'en', 'Base'], mainGroup=ref('root'), productRefGroup=ref('products'), projectDirPath='', projectRoot='', targets=[ref('target:FitAICoach'), ref('target:FitAICoachWatch')])
project = ROOT / 'FitAICoach.xcodeproj'
project.mkdir(exist_ok=True)
payload = dict(archiveVersion=1, classes={}, objectVersion=56, objects=objects, rootObject=ref('project'))
(project / 'project.pbxproj').write_text('// !$*UTF8*$!\n' + render(payload) + '\n', encoding='utf-8')
schemes = project / 'xcshareddata' / 'xcschemes'
schemes.mkdir(parents=True, exist_ok=True)
for name in ['FitAICoach', 'FitAICoachWatch']:
    build_ref = f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{uid("target:"+name)}" BuildableName="{name}.app" BlueprintName="{name}" ReferencedContainer="container:FitAICoach.xcodeproj"/>'
    (schemes / (name + '.xcscheme')).write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="2620" version="1.3">
 <BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">{build_ref}</BuildActionEntry></BuildActionEntries></BuildAction>
 <LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0">{build_ref}</BuildableProductRunnable></LaunchAction>
 <ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"><BuildableProductRunnable runnableDebuggingMode="0">{build_ref}</BuildableProductRunnable></ProfileAction>
 <AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>
''', encoding='utf-8')

config = ROOT / 'Config'
config.mkdir(exist_ok=True)
for directory in ['iOS', 'Watch']:
    info = {'CFBundleDevelopmentRegion': 'ru', 'CFBundleExecutable': '$(EXECUTABLE_NAME)', 'CFBundleIdentifier': '$(PRODUCT_BUNDLE_IDENTIFIER)', 'CFBundleInfoDictionaryVersion': '6.0', 'CFBundleName': '$(PRODUCT_NAME)', 'CFBundleDisplayName': 'FitAI Coach', 'CFBundlePackageType': 'APPL', 'CFBundleShortVersionString': '$(MARKETING_VERSION)', 'CFBundleVersion': '$(CURRENT_PROJECT_VERSION)', 'NSHealthShareUsageDescription': 'Показываем пульс и учитываем другие сегодняшние тренировки из Здоровья при подготовке плана. Сон запрашивается отдельно.', 'NSHealthUpdateUsageDescription': 'Сохраняем завершённые тренировки с часов в Здоровье.'}
    if directory == 'Watch':
        info.update(WKApplication=True, WKCompanionAppBundleIdentifier='local.fitai.coach', WKBackgroundModes=['workout-processing'])
    else:
        info.update(UILaunchScreen={}, UISupportedInterfaceOrientations=['UIInterfaceOrientationPortrait'])
    (config / (directory + '-Info.plist')).write_bytes(plistlib.dumps(info))
    (config / (directory + '.entitlements')).write_bytes(plistlib.dumps({'com.apple.developer.healthkit': True}))
print(f'Generated {project}; {len(all_files)} Swift files. No compilation performed.')
