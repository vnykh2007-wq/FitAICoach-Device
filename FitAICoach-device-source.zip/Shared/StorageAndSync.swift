import Foundation

/// Deletion markers win over stale offline copies, on either device.
public enum WorkoutHistory {
    public static func delete(_ id: UUID, from archive: inout AppArchive) {
        var deleted = archive.deletedWorkoutIDs ?? []
        deleted.insert(id); archive.deletedWorkoutIDs = deleted
        removeDeleted(from: &archive)
    }
    public static func mergeDeleted(_ ids: Set<UUID>, into archive: inout AppArchive) {
        archive.deletedWorkoutIDs = (archive.deletedWorkoutIDs ?? []).union(ids)
        removeDeleted(from: &archive)
    }
    public static func removeDeleted(from archive: inout AppArchive) {
        let deleted = archive.deletedWorkoutIDs ?? []
        archive.history.removeAll { deleted.contains($0.id) }
        let affected = archive.calendar.filter { $0.workoutID.map(deleted.contains) ?? false }
        archive.calendar.removeAll { $0.workoutID.map(deleted.contains) ?? false }
        for entry in affected {
            guard !archive.calendar.contains(where: { Calendar.current.isDate($0.date, inSameDayAs: entry.date) }),
                  let remaining = archive.history.last(where: { $0.endedAt != nil && Calendar.current.isDate($0.startedAt, inSameDayAs: entry.date) }) else { continue }
            archive.calendar.append(CalendarEntry(date: remaining.startedAt, status: remaining.isLight ? .light : .completed, workoutID: remaining.id))
        }
    }
}

/// Atomic replacement preserves the previous file if encoding fails. No network or cloud involved.
public struct JSONStore {
    public let directory: URL
    public init(directory:URL?=nil) {
        self.directory=directory ?? FileManager.default.urls(for:.applicationSupportDirectory,in:.userDomainMask)[0].appendingPathComponent("FitAICoach",isDirectory:true)
    }
    public func save<T:Encodable>(_ value:T,name:String) throws {
        try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
        let encoder=JSONEncoder(); encoder.outputFormatting=[.prettyPrinted,.sortedKeys]; encoder.dateEncodingStrategy = .iso8601
        try encoder.encode(value).write(to:file(name),options:.atomic)
    }
    public func load<T:Decodable>(_ type:T.Type,name:String) throws -> T? {
        let path=file(name)
        guard FileManager.default.fileExists(atPath:path.path) else { return nil }
        let decoder=JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode(type,from:Data(contentsOf:path))
    }
    public func remove(name:String) throws {
        let path=file(name)
        if FileManager.default.fileExists(atPath:path.path) { try FileManager.default.removeItem(at:path) }
    }
    public func backupArchiveBeforeUpgrade() throws {
        let original = file("archive"), backup = file("archive-before-v2")
        if FileManager.default.fileExists(atPath: original.path), !FileManager.default.fileExists(atPath: backup.path) {
            try FileManager.default.copyItem(at: original, to: backup)
        }
    }
    public func export(_ archive:AppArchive) throws -> URL { try save(archive,name:"history-export"); return file("history-export") }
    private func file(_ name:String) -> URL {
        // Keep all callers inside the app's own directory, even when names come from imported data.
        let safe=String(name.unicodeScalars.filter { CharacterSet.alphanumerics.contains($0) || $0 == "-" || $0 == "_" })
        return directory.appendingPathComponent(safe.isEmpty ? "data" : safe).appendingPathExtension("json")
    }
}

public struct RemoteCommand: Codable, Identifiable, Sendable {
    public let id: UUID
    public let workoutID: UUID
    public let kind: String
    public let createdAt: Date
    public var exerciseID: UUID?
    public var setNumber: Int?
    public var expectedPhase: WorkoutPhase?
    public var repetitions: Int?
    public init(id: UUID = UUID(), workoutID: UUID, kind: String, createdAt: Date = Date(), exerciseID: UUID? = nil, setNumber: Int? = nil, expectedPhase: WorkoutPhase? = nil, repetitions: Int? = nil) {
        self.id=id; self.workoutID=workoutID; self.kind=kind; self.createdAt=createdAt; self.exerciseID=exerciseID; self.setNumber=setNumber; self.expectedPhase=expectedPhase; self.repetitions=repetitions
    }
    public func matches(_ engine: WorkoutEngine) -> Bool {
        guard workoutID == engine.record.id else { return false }
        if ["beginExercise", "completeExercise", "next", "extendRest"].contains(kind) {
            return exerciseID == engine.currentExercise?.id && setNumber == engine.setNumber && expectedPhase == engine.state
        }
        return true
    }
}

public enum ArchiveRestore {
    public static func merge(_ incoming: AppArchive, into local: inout AppArchive) {
        WorkoutHistory.mergeDeleted(incoming.deletedWorkoutIDs ?? [], into: &local)
        for record in incoming.history where !(local.deletedWorkoutIDs ?? []).contains(record.id) {
            if let existing = local.history.first(where: { $0.id == record.id }) {
                if existing.exercises.count > record.exercises.count || existing.heartRate.count > record.heartRate.count { continue }
            }
            local.history.removeAll { $0.id == record.id }; local.history.append(record)
        }
        for entry in incoming.calendar where !local.calendar.contains(where: { $0.id == entry.id || Calendar.current.isDate($0.date, inSameDayAs: entry.date) }) { local.calendar.append(entry) }
        for test in incoming.testResults where !local.testResults.contains(where: { $0.id == test.id }) { local.testResults.append(test) }
        if local.profile.age == 0 { local.profile = incoming.profile }
        if local.plan.exercises.isEmpty { local.plan = ExerciseLibrary.expandWarmup(in: incoming.plan) }
        WorkoutHistory.removeDeleted(from: &local)
    }
}
public enum WorkoutCommandAction: String, Codable, Sendable { case pause, resume, finish, startExercise, finishExercise, startNext, extendRest }
public struct WorkoutCommand: Identifiable, Codable, Sendable {
    public var id: UUID
    public var workoutID: UUID
    public var action: WorkoutCommandAction
    public var repetitions: Int?
    public var issuedAt: Date
    public init(id:UUID=UUID(),workoutID:UUID,action:WorkoutCommandAction,repetitions:Int?=nil,issuedAt:Date=Date()) { self.id=id; self.workoutID=workoutID; self.action=action; self.repetitions=repetitions; self.issuedAt=issuedAt }
}
/// Persist together with authoritative engine, so replayed commands remain harmless after restart.
public struct CommandLedger: Codable, Sendable {
    public private(set) var processed: Set<UUID> = []
    public init() {}
    @discardableResult public mutating func apply(_ command:WorkoutCommand,to engine:inout WorkoutEngine,now:Date=Date()) -> Bool {
        guard command.workoutID == engine.record.id, !processed.contains(command.id), engine.state != .finished else { return false }
        processed.insert(command.id)
        switch command.action {
        case .pause: engine.pause(now:now)
        case .resume: engine.resume(now:now)
        case .finish: engine.finish(now:now)
        case .startExercise: engine.startExercise(now:now)
        case .finishExercise: engine.finishExercise(actualRepetitions:command.repetitions,now:now)
        case .startNext: engine.startNext(now:now)
        case .extendRest: engine.extendRest()
        }
        return true
    }
}
public struct WorkoutSnapshot: Codable, Sendable {
    public var revision: UInt64
    public var engine: WorkoutEngine
    public var ledger: CommandLedger
    public init(revision:UInt64,engine:WorkoutEngine,ledger:CommandLedger=CommandLedger()) { self.revision=revision; self.engine=engine; self.ledger=ledger }
}
public enum ProgressMetrics {
    public static func achievements(archive:AppArchive,now:Date=Date(),calendar:Calendar = .current) -> [String] {
        let completed=archive.history.filter { $0.endedAt != nil }
        var awards:[String]=[]
        if !completed.isEmpty { awards.append("Первая тренировка") }
        if completed.count >= 3 { awards.append("3 завершённые тренировки") }
        if archive.testResults.filter { $0.kind == .pushups }.count > 1 && archive.profile.pushUpMaximum > (archive.testResults.first { $0.kind == .pushups }?.value ?? 0) { awards.append("Новый рекорд отжиманий") }
        if archive.testResults.filter { $0.kind == .plank }.count > 1 && archive.profile.plankMaximumSeconds > (archive.testResults.first { $0.kind == .plank }?.value ?? 0) { awards.append("Новый рекорд планки") }
        let active=Set(archive.calendar.filter { [.completed,.rest,.light].contains($0.status) }.map { calendar.startOfDay(for:$0.date) })
        let today=calendar.startOfDay(for:now)
        if (0..<7).allSatisfy({ offset in calendar.date(byAdding:.day,value:-offset,to:today).map(active.contains) ?? false }) { awards.append("7 дней регулярной активности") }
        if let first=completed.map(\.startedAt).min(), let month=calendar.date(byAdding:.month,value:1,to:first), now >= month, active.count >= 20 { awards.append("Первый месяц занятий") }
        return awards
    }
}
