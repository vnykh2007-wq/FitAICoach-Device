import Foundation

public enum ExerciseLibrary {
    public static let all: [Exercise] = [
        Exercise(id:"warmup",name:"Разминка",technique:"Шагайте на месте, мягко вращайте плечами и тазом. Постепенно увеличивайте амплитуду.",muscles:["Всё тело"],mistakes:"Резкие движения и попытка растянуть холодные мышцы.",easierVariant:"Медленная ходьба на месте."),
        Exercise(id:"pushups",name:"Отжимания",technique:"Кисти немного шире плеч, тело прямое. Опускайте грудь между ладонями, локти под углом около 45°. Выдыхайте при подъёме.",muscles:["Грудь","Трицепс","Кор"],mistakes:"Провисание поясницы, разведённые локти, неполная контролируемая амплитуда.",easierVariant:"Отжимания от устойчивой стены или высокой опоры."),
        Exercise(id:"squats",name:"Приседания",technique:"Стопы удобно на ширине плеч. Отведите таз назад и вниз, колени следуют направлению носков. Вставайте без рывка.",muscles:["Ноги","Ягодицы"],mistakes:"Отрыв пяток и сведение коленей внутрь.",easierVariant:"Неглубокий присед до устойчивого стула."),
        Exercise(id:"plank",name:"Планка",technique:"Локти под плечами, живот слегка напряжён. Дышите ровно, сохраняйте прямую линию тела.",muscles:["Кор","Плечи"],mistakes:"Задержка дыхания и прогиб в пояснице.",easierVariant:"Планка с колен или с опорой на стол."),
        Exercise(id:"birdDog",name:"Птица-собака",technique:"На четвереньках вытяните противоположные руку и ногу, не поворачивая таз. Вернитесь и смените сторону.",muscles:["Спина","Кор","Ягодицы"],mistakes:"Чрезмерный прогиб и высокая скорость.",easierVariant:"Поднимайте только руку или только ногу."),
        Exercise(id:"deadBug",name:"Мёртвый жук",technique:"Лёжа на спине, согните ноги и поднимите руки. Медленно опускайте противоположные руку и ногу, сохраняя комфортное положение поясницы.",muscles:["Кор"],mistakes:"Отрыв поясницы и резкие движения.",easierVariant:"Касайтесь пола одной пяткой, руки неподвижны."),
        Exercise(id:"bridge",name:"Ягодичный мост",technique:"Лёжа на спине, согните колени. Поднимите таз до прямой линии бёдер и корпуса, затем медленно опустите.",muscles:["Ягодицы","Задняя поверхность бедра"],mistakes:"Избыточный прогиб поясницы.",easierVariant:"Уменьшите высоту подъёма."),
        Exercise(id:"walk",name:"Ходьба на месте",technique:"Шагайте в комфортном темпе, двигайте руками и сохраняйте возможность разговаривать.",muscles:["Ноги","Выносливость"],mistakes:"Слишком быстрый темп при утомлении.",easierVariant:"Медленные короткие шаги."),
        Exercise(id:"crunch",name:"Скручивания",technique:"Лёжа на спине с согнутыми коленями, на выдохе плавно приподнимите лопатки. Смотрите вверх, не тяните голову руками. Медленно опуститесь.",muscles:["Прямая мышца живота"],mistakes:"Рывок шеей, подъём всего корпуса и задержка дыхания.",easierVariant:"Небольшой подъём лопаток, руки вдоль тела."),
        Exercise(id:"reverseCrunch",name:"Обратные скручивания",technique:"Лёжа на спине, согните колени. На выдохе мягко подкрутите таз и немного приподнимите его без маха ногами. Медленно вернитесь.",muscles:["Кор","Прямая мышца живота"],mistakes:"Раскачивание ног и большая амплитуда через поясницу.",easierVariant:"Подтягивайте по одному колену без подъёма таза."),
        Exercise(id:"reverseLunge",name:"Выпады назад",technique:"Из стойки сделайте шаг назад и опуститесь до удобной глубины. Переднее колено следует направлению носка. Оттолкнитесь передней стопой и вернитесь; чередуйте стороны.",muscles:["Квадрицепс","Ягодицы"],mistakes:"Сведение колена внутрь, потеря равновесия и слишком узкая постановка стоп.",easierVariant:"Держитесь за устойчивую опору и уменьшите глубину."),
        Exercise(id:"superman",name:"Супермен",technique:"Лёжа на животе, мягко напрягите ягодицы и немного приподнимите руки и ноги. Смотрите в пол, не запрокидывайте голову; дышите свободно.",muscles:["Разгибатели спины","Ягодицы"],mistakes:"Высокий подъём с сильным прогибом и запрокидывание головы.",easierVariant:"Поднимайте только одну руку или ногу; при дискомфорте замените на птицу-собаку."),
        Exercise(id:"cooldown",name:"Заминка",technique:"Спокойно походите, затем мягко потяните грудь, плечи и ноги без боли.",muscles:["Всё тело"],mistakes:"Растяжка через боль и резкая остановка после нагрузки.",easierVariant:"Спокойная ходьба и ровное дыхание.")
    ]
    public static func named(_ id:String) -> Exercise { all.first { $0.id == id } ?? all[0] }
}
public enum SeedData {

    public static func defaultPlan() -> WorkoutPlan {
        WorkoutPlan(name:"Возвращение к ритму",exercises:[
            ExercisePlan(exercise:ExerciseLibrary.named("warmup"),repetitions:nil,durationSeconds:240),
            ExercisePlan(exercise:ExerciseLibrary.named("pushups"),repetitions:8,sets:2,restSeconds:60),
            ExercisePlan(exercise:ExerciseLibrary.named("squats"),repetitions:12,sets:2,restSeconds:45),
            ExercisePlan(exercise:ExerciseLibrary.named("birdDog"),repetitions:10,sets:2),
            ExercisePlan(exercise:ExerciseLibrary.named("plank"),repetitions:nil,durationSeconds:25,sets:2,restSeconds:45),
            ExercisePlan(exercise:ExerciseLibrary.named("bridge"),repetitions:12,sets:2),
            ExercisePlan(exercise:ExerciseLibrary.named("walk"),repetitions:nil,durationSeconds:300),
            ExercisePlan(exercise:ExerciseLibrary.named("cooldown"),repetitions:nil,durationSeconds:180)
        ])
    }
    public static func archive() -> AppArchive {
        AppArchive(plan:defaultPlan())
    }
}
public enum CoachEngine {
    public static func makePlan(archive:AppArchive,fatigue:Int=5,sleepHours:Double?=nil,now:Date=Date()) -> WorkoutPlan {
        let recent=archive.history.filter { $0.endedAt != nil && now.timeIntervalSince($0.startedAt) >= 0 && now.timeIntervalSince($0.startedAt) < 48*3600 && !$0.isLight }
        let needsRecovery=fatigue >= 7 || (sleepHours.map { $0 < 6 } ?? false) || !recent.isEmpty
        if needsRecovery {
            return WorkoutPlan(name:"Восстановление и привычка",targetMinutes:archive.settings.workoutMinutes,exercises:[ExercisePlan(exercise:ExerciseLibrary.named("warmup"),repetitions:nil,durationSeconds:180),ExercisePlan(exercise:ExerciseLibrary.named("walk"),repetitions:nil,durationSeconds:max(300,(archive.settings.workoutMinutes-6)*60)),ExercisePlan(exercise:ExerciseLibrary.named("cooldown"),repetitions:nil,durationSeconds:180)],isLight:true)
        }
        var plan=SeedData.defaultPlan(); plan.targetMinutes=archive.settings.workoutMinutes
        let previous=archive.history.sorted { $0.startedAt > $1.startedAt }.first { !$0.isLight && !$0.exercises.isEmpty }
        if let previous {
            for index in plan.exercises.indices {
                let past=previous.exercises.filter { $0.exercise.id == plan.exercises[index].exercise.id && !$0.skipped }
                guard !past.isEmpty, let goal=plan.exercises[index].repetitions else { continue }
                let completed=past.compactMap(\.actualRepetitions)
                guard completed.count == past.count else { continue }
                let previousGoal=past.compactMap(\.plannedRepetitions).min() ?? goal
                if past.contains(where: { ($0.actualRepetitions ?? 0) < ($0.plannedRepetitions ?? 0) }) || (previous.fatigue ?? 5) >= 8 {
                    plan.exercises[index].repetitions=max(3,previousGoal-2)
                } else if (previous.fatigue ?? 10) <= 5 && past.allSatisfy({ ($0.actualRepetitions ?? 0) >= ($0.plannedRepetitions ?? Int.max) }) {
                    plan.exercises[index].repetitions=min(previousGoal+1,20)
                }
            }
        }
        let scale=Double(plan.targetMinutes)/30.0
        for index in plan.exercises.indices {
            if let duration=plan.exercises[index].durationSeconds { plan.exercises[index].durationSeconds=max(10,Int(Double(duration)*scale)) }
            if plan.targetMinutes < 20 { plan.exercises[index].sets=1 }
        }
        return plan
    }
    public static func reply(to text:String,archive:AppArchive) -> String {
        let input=text.lowercased()
        if ["боль","боли","болит","головокруж","кружится","тошн","слабост"].contains(where:input.contains) { return "Прекрати нагрузку и заверши тренировку. При выраженных или сохраняющихся симптомах обратись за медицинской помощью. Не продолжай через боль." }
        if input.contains("устал") || input.contains("не высп") || input.contains("недосып") { return "Сегодня снижаем нагрузку: спокойная ходьба и мягкая подвижность по самочувствию. Запиши усталость после занятия. Восстановление — часть дисциплины." }
        if input.contains("прогресс") || input.contains("рекорд") { return "Завершено тренировок: \(archive.history.filter { $0.endedAt != nil }.count). Зафиксированный максимум отжиманий: \(archive.profile.pushUpMaximum), планка: \(archive.profile.plankMaximumSeconds) с. Максимальные тесты сравниваем отдельно от обычных подходов." }
        if input.contains("пропуск") || input.contains("пропуст") || input.contains("причин") { return "Отметь причину в календаре. Ты поставил цель заниматься регулярно: выбери конкретное время возвращения. После пропуска не нужно удваивать нагрузку." }
        if input.contains("следующ") { return "Порядок программы: " + archive.plan.exercises.map { $0.exercise.name }.joined(separator:" → ") + ". Текущее упражнение смотри на экране тренировки." }
        if input.contains("нагруз") || input.contains("отдых") { return "Оставляй запас повторений и сохраняй технику. Если не восстановился, продли отдых на 30 секунд или выбери облегчённый день. Один пульс не определяет готовность." }
        return "Я — локальный тренер на основе правил. Поддерживаю запросы: усталость, боль, прогресс, пропуск, следующее упражнение, нагрузка и отдых. После занятия укажи усталость от 0 до 10."
    }
}
