import SwiftUI

extension Color {
    static let fitAccent = Color(red: 0.72, green: 0.98, blue: 0.25)
    static let fitCard = Color(white: 0.10)
}

struct FitCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        VStack(alignment: .leading, spacing: 12) { content }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding().background(Color.fitCard, in: RoundedRectangle(cornerRadius: 22))
    }
}
struct Metric: View {
    var title: String
    var value: String
    var symbol: String
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Label(title, systemImage: symbol).font(.caption).foregroundStyle(.secondary)
            Text(value).font(.title2.bold()).monospacedDigit()
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
}
struct EmptyState: View {
    var title: String
    var detail: String
    var body: some View {
        ContentUnavailableView(title, systemImage: "heart.text.square", description: Text(detail))
    }
}
func clockString(_ duration: TimeInterval) -> String {
    let seconds = max(0, Int(duration))
    return String(format: "%02d:%02d", seconds / 60, seconds % 60)
}
func clockString(_ seconds: Int) -> String { clockString(TimeInterval(seconds)) }
